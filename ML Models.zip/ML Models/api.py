from flask import Flask, jsonify
from flask_restful import Api, Resource, reqparse
from sklearn.metrics import cluster
import pickle
import numpy as np
from typing import List
import pandas as pd
import json

app = Flask(__name__)
api = Api(app)

# Create parser for the payload data
parser = reqparse.RequestParser()
parser.add_argument('data')
selected_columns = ['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
                 'Religion', 'Education', 'School Performance', 'Birth Order',
                 'Number of Siblings', 'Relationship Status', 'Children',
                 'Employment Status', 'Employment Type\xa0', 'Military Branch',
                 'Community Involvement', 'Part I Crimes', 'Part II Crimes',
                 'Domestic Abuse Specified', 'Childhood SES',
                 'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
                 'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
                 'Leakage Specific/Nonspecific\xa0', 'Crimil Sentence']

def sim_score(vec1, vec2):
    if len(vec1) != len(vec2):
        #print(len(vec1), len(vec2))
        raise ValueError(f'vec1 & vec2 must be of similar dimensions or padded')
    x = np.sum([v1 * v2 for v1, v2 in zip(vec1, vec2)])
    y = np.linalg.norm(vec1, ord=2) * np.linalg.norm(vec2, ord=2)

    return x / y if y > 0 else 0

def predict(data,clusters, data_hashes):
  closest_idx = np.argmax([sim_score(data, point) for point in clusters[0]])
  print(f'{closest_idx}')
  closest_idx_key = hash(tuple(clusters[0][closest_idx]))
  print(f'{closest_idx_key}')
  return sim_score(data, clusters[0][closest_idx]), data_hashes[closest_idx_key]

def predict3(data, clusters, data_hashes):
  scores= []
  keys = []
  output = []
  for point in clusters[0]:
    closest_idx = sim_score(data, point)
    scores.append(closest_idx)

  res = sorted(range(len(scores)), key=lambda sub: scores[sub])[-3:]
  print(res)

  for i in res:
    keys.append(hash(tuple(clusters[0][i])))

  for  closest_idx_key in keys:
    output.append((data_hashes[closest_idx_key]).tolist())

  for i in range(len(res)):
    test =(sim_score(data, clusters[0][res[i]]))
    output[i].append(round(test, 4))

  return output

## Euclidean distance
def dst(v1, v2):
  print(f'v1: {v1}\nv2: {v2}')
  return np.sum([(xi-yi)**2 for xi, yi in zip(v1,v2)])

def compute_centroid(cluster):
  #print(f'cluster: \n{np.array(cluster).shape}')
  return np.mean(cluster, axis=1)

def getOriginalData(arr):
  selected_columns =['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
       'Religion', 'Education', 'School Performance', 'Birth Order',
       'Number of Siblings', 'Relationship Status', 'Children',
       'Employment Status', 'Employment Type\xa0', 'Military Branch',
       'Community Involvement', 'Part I Crimes', 'Part II Crimes',
       'Domestic Abuse Specified', 'Childhood SES',
       'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
       'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
       'Leakage Specific/Nonspecific\xa0', 'Crimil Sentence']
  matched_index = None
  df_original = pd.read_csv('Gun_Violence_Record_Orignal_Final (1).csv')
  df = pd.read_csv('Gun_Violence_Record_Update_Final (1).csv')
  df= df[selected_columns]
  df_original= df_original[['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
       'Religion', 'Education', 'School Performance', 'Birth Order',
       'Number of Siblings', 'Relationship Status', 'Children',
       'Employment Status', 'Employment Type\xa0', 'Military Branch',
       'Community Involvement', 'Part I Crimes', 'Part II Crimes',
       'Domestic Abuse Specified', 'Childhood SES',
       'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
       'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
       'Leakage Specific/Nonspecific ', 'Crimil Sentence']]
  df.replace(r'^\s+$', np.nan, regex=True,  inplace=True)
  df.replace([np.inf, -np.inf], np.nan, inplace=True)
  df.fillna(-9999999, inplace=True)
  arr= pd.DataFrame([arr], columns=['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
       'Religion', 'Education', 'School Performance', 'Birth Order',
       'Number of Siblings', 'Relationship Status', 'Children',
       'Employment Status', 'Employment Type\xa0', 'Military Branch',
       'Community Involvement', 'Part I Crimes', 'Part II Crimes',
       'Domestic Abuse Specified', 'Childhood SES',
       'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
       'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
       'Leakage Specific/Nonspecific\xa0', 'Crimil Sentence'])
  arr=arr.squeeze()
  for index, row in df.iterrows():
    result = row.equals(arr)
    if result:
      return df_original.iloc[index].tolist()
  return matched_index



def k_means(X, k: int):
    rnd_centers = np.random.choice(range(len(X)), k, replace=False)
    centroids = [X[p] for p in rnd_centers]

    while True:
        clusters = [[] for i in range(len(centroids))]
        for x in X:
            proximities = [dst(x, c) for c in centroids]
            closest_cen = np.argmin(proximities)
            clusters[closest_cen].append(x)

        # for i, cluster in enumerate(clusters):
        # print(f'cluster-{i} - {len(cluster)} -> {cluster}' )
        # break
        new_centroids = [compute_centroid(c) for c in clusters if len(c) > 0]
        for i, c in enumerate(new_centroids):
            print(f'centroid - {i + 1}: {c}')

        if np.array_equal(new_centroids, centroids):
            break
        centroids = new_centroids
        print(f'centroids: {len(centroids)}\n{centroids}')
    return centroids, clusters

# Define how the api will respond to the post requests
class OutlierPredictor(Resource):
    @app.route("/lof", methods=['POST'])
    def post():
        args = parser.parse_args()
        X = np.array(json.loads(args['data']))
        prediction = model.predict(X)
        return jsonify(prediction.tolist())


    @app.route("/customModel", methods=['POST'])
    def customModel():
        args = parser.parse_args()
        x = np.array(json.loads(args['data']))
        #print(f'data received {x}')
        #Preprocess Data
        df = pd.read_csv('Gun_Violence_Record_Update.csv')
        df = df[selected_columns]
        df.replace(r'^\s+$', np.nan, regex=True, inplace=True)
        # df['Kidpping or Hostage Situation'].replace('S', 1,  inplace=True)
        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.fillna(-9999999, inplace=True)
        X = df.values
        scores = []


        output = []
        for i in X:
            result = sim_score(x, i)
            scores.append(result)

        res = sorted(range(len(scores)), key=lambda sub: scores[sub])[-3:]
        for i in res:
            output.append(X[i].tolist())
        print(output)
        for i in range(len(res)):
            output[i].append(round(scores[res[i]], 4))
        #score': {np.array(round(max_score,2)).tolist()}
        return jsonify({'prediction': output}) #(np.array(np.append(prediction,max_score) )).tolist()})

    @app.route("/getOriginalDataAPI", methods=['POST'])
    def getOriginalDataAPI():
        args = parser.parse_args()
        arr = np.array(json.loads(args['data']))
        print(arr)
        matched_index = []
        df_original = pd.read_csv('Gun_Violence_Record__.csv')
        df = pd.read_csv('Gun_Violence_Record_Update.csv')
        df = df[selected_columns]
        df_original = df_original[['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
                                   'Religion', 'Education', 'School Performance', 'Birth Order',
                                   'Number of Siblings', 'Relationship Status', 'Children',
                                   'Employment Status', 'Employment Type\xa0', 'Military Branch',
                                   'Community Involvement', 'Part I Crimes', 'Part II Crimes',
                                   'Domestic Abuse Specified', 'Childhood SES',
                                   'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
                                   'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
                                   'Leakage Specific/Nonspecific ', 'Criminal Sentence']]
        df.replace(r'^\s+$', np.nan, regex=True, inplace=True)
        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.fillna(-999999, inplace=True)
        arr = pd.DataFrame([arr], columns=[selected_columns])
        arr = arr.squeeze()
        counter = 0
        for index, row in df.iterrows():

            result = row.equals(arr)
            if counter == 125:
                print(f'counter : {counter}, {result}, {row}, {arr}, {row.shape}, {arr.shape}')
            counter+=1
            if result:
                print('got here')
                matched_index = df_original.iloc[index]
                return jsonify({'original_data': matched_index.tolist()})
        return jsonify({f'original_data': matched_index})


#=======KMeans===========#
    @app.route("/kmeansModel", methods=['POST'])
    def kmeansModel():
        args = parser.parse_args()
        x = np.array(json.loads(args['data']))
        # print(f'data received {x}')

        # Preprocess Data
        '''
        df = pd.read_csv('Gun_Violence_Record_Update.csv')
        df = df[['State Code', 'Region', 'Urban/Suburban/Rural', 'Age', 'Race',
                 'Religion', 'Education', 'School Performance', 'Birth Order',
                 'Number of Siblings', 'Relationship Status', 'Children',
                 'Employment Status', 'Employment Type\xa0', 'Military Branch',
                 'Community Involvement', 'Part I Crimes', 'Part II Crimes',
                 'Domestic Abuse Specified', 'Childhood SES',
                 'Recent or Ongoing Stressor', 'Timeline of Signs of Crisis',
                 'Substance Use', 'Known Prejudices\xa0', 'Leakage How', 'Leakage Who\xa0',
                 'Leakage Specific/Nonspecific\xa0', 'Crimil Sentence']]
        df.replace(r'^\s+$', np.nan, regex=True, inplace=True)
        # df['Kidpping or Hostage Situation'].replace('S', 1,  inplace=True)
        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.fillna(-9999999, inplace=True)
        X = df.values
        '''
        #data_points = np.array(X.values.tolist())
        #data_hashes = {hash(tuple(x)): x for x in data_points}
        output = predict3(x,kmeansmodel,data_hashes)
        original_data = []
        all_data = []
        for i in output:
            # print(i)
            all_data = (getOriginalData(i[:-1]))
            all_data = [(x.split(',')) if isinstance(x, str) else x for x in all_data]
            # print(type(all_data))
            for j in range(len(all_data)):
                if isinstance(all_data[j], list):
                    all_data[j] = [float(x) for x in all_data[j]]
                else:
                    all_data[j] = float(all_data[j])
            all_data.append(round(i[-1], 4))
            original_data.append(all_data)
        return jsonify({f'prediction': original_data})
        #kmeans_model kmeansmodel

#api.add_resource(OutlierPredictor, '/lof')

if __name__ == '__main__':
    # Load model
    with open('lof_model.pickle', 'rb') as f:
        model = pickle.load(f)

    with open('kmeans_model.pickle', 'rb') as f:
        kmeansmodel = pickle.load(f)

    with open('data_hashes.pickle', 'rb') as f:
        data_hashes = pickle.load(f)

    app.run(port=5000, debug=True)