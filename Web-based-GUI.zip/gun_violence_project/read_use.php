<?php
// Include config file
require_once "db_connection.php";

if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    
    // Prepare a select statement
    $sql = "SELECT * FROM entry_data WHERE id = ?";

    $sql_train = "SELECT * FROM entry_data_train WHERE parent_id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                //$state_code = $row["state_code"];
                //$region = $row["region"];
                //$salary = $row["salary"];
            } else {
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    };
     
    // Close statement
    mysqli_stmt_close($stmt);

    $button_show_train = 'no';

    if($stmt_train = mysqli_prepare($link, $sql_train)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_train, "i", $param_id_train);
        
        // Set parameters
        $param_id_train = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_train)){
            $result_train = mysqli_stmt_get_result($stmt_train);
    
            if(mysqli_num_rows($result_train) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_train = mysqli_fetch_array($result_train, MYSQLI_ASSOC);

                //echo $row_train["retrained"];

                $check_if_trained = $row_train["retrained"];

                if ($check_if_trained == 'no'){
                    $button_show_train = 'yes';
                } else {
                    $button_show_train = 'no';
                }

            } 
/**
            else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error1.php");
                exit();
            }**/
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }

    // Close statement
    mysqli_stmt_close($stmt_train);
    
    

    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error3.php");
        exit();
};

if(isset($_POST['submit'])) {

    $stmt_train_api = "SELECT * FROM entry_data_train WHERE parent_id = ? AND retrained = ?";

    if($stmt_train_api = mysqli_prepare($link, $stmt_train_api)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_train_api, "is", $param_id_train_api, $retrained_dt);
        
        // Set parameters
        $param_id_train_api = trim($_GET["id"]);
        $retrained_dt = "no";
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_train_api)){
            $result_train_api = mysqli_stmt_get_result($stmt_train_api);
    
            if(mysqli_num_rows($result_train_api) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_train_api = mysqli_fetch_array($result_train_api, MYSQLI_ASSOC);

                $state_code_train_no = $row_train_api["state_code"];
                $region_train_no = $row_train_api["region"];
                $urban_train_no = $row_train_api["urban"];
                $age_train_no = $row_train_api["age"];
                $race_train_no = $row_train_api["race"];
                $religion_train_no = $row_train_api["religion"];
                $education_train_no = $row_train_api["education"];
                $school_perf_train_no = $row_train_api["school_perf"];
                $birth_order_train_no = $row_train_api["birth_order"];
                $no_siblings_train_no = $row_train_api["no_siblings"];
                $relationship_train_no = $row_train_api["relationship"];
                $children_train_no = $row_train_api["children"];
                $employment_status_train_no = $row_train_api["employment_status"];
                $employment_type_train_no = $row_train_api["employment_type"];
                $military_branch_train_no = $row_train_api["military_branch"];
                $community_involvement_train_no = $row_train_api["community_involvement"];
                $part_1_crimes_train_no = $row_train_api["part_1_crimes"];
                $part_2_crimes_train_no = $row_train_api["part_2_crimes"];
                $domestic_abuse_spec_train_no = $row_train_api["domestic_abuse_spec"];
                $childhood_socioeconomic_train_no = $row_train_api["childhood_socioeconomic"];
                $recent_stressor_triggering_event_train_no = $row_train_api["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_train_no = $row_train_api["timeframe_signs_crisis"];
                $substance_use_and_abuse_train_no = $row_train_api["substance_use_and_abuse"];
                $known_prejudices_train_no = $row_train_api["known_prejudices"];
                $leakage_how_train_no = $row_train_api["leakage_how"];
                $leakage_who_train_no = $row_train_api["leakage_who"];
                $leakage_specific_train_no = $row_train_api["leakage_specific"];
                $criminal_sentence_train_no = $row_train_api["criminal_sentence"];

            }
            
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }

        //******************* Pass Records to API in numbers *********************
        $new_entry = array(
            $state_code_train_no,
            $region_train_no,
            $urban_train_no,
            $age_train_no,
            $race_train_no,
            $religion_train_no,
            $education_train_no,
            $school_perf_train_no,
            $birth_order_train_no,
            $no_siblings_train_no,
            $relationship_train_no,
            $children_train_no,
            $employment_status_train_no,
            $employment_type_train_no,
            $military_branch_train_no,
            $community_involvement_train_no,
            $part_1_crimes_train_no,
            $part_2_crimes_train_no,
            $domestic_abuse_spec_train_no,
            $childhood_socioeconomic_train_no,
            $recent_stressor_triggering_event_train_no,
            $timeframe_signs_crisis_train_no,
            $substance_use_and_abuse_train_no,
            $known_prejudices_train_no,
            $leakage_how_train_no,
            $leakage_who_train_no,
            $leakage_specific_train_no,
            $criminal_sentence_train_no
        );

        $new_entry_data = implode(", ", $new_entry);

        $new_entry_convert = json_decode(json_encode('[[[' . $new_entry_data . ']]]', true));

        $data = '{'.'"'.'data'.'"'.': '.$new_entry_convert.'}';

        //echo $data;
        //exit;

        /*************************************************** MODEL 1 API **********************************************/
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, "http://127.0.0.1:5000/train");

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($curl, CURLOPT_POST, true);

        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

        //curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');

        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
     
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
          'X-RapidAPI-Host: https://127.0.0.1:5000/lof',
          //'X-RapidAPI-Key: 7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          'Content-Type: application/json'
        ]);
        
        $model_train_result = curl_exec($curl);

        //echo $model_1_result;
        //exit;

        //$model_1_result = [1];

        if ($model_train_result = 1){
                $model_train_result_text = "This is likely to be a Shooter";
        } else {
            $model_train_result_text = "Not a Shooter";
        }

        curl_close($curl);

    }

    $sql_update_train = "UPDATE entry_data_train SET retrained = ? WHERE parent_id = ? ";

    if($stmt_update = mysqli_prepare($link, $sql_update_train)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_update, "si", $retrained_update, $param_id_update);
        
        // Set parameters
        $param_id_update = trim($_GET["id"]);
        $retrained_update = "yes";
        
        if(mysqli_stmt_execute($stmt_update))
                {
                    header("Refresh:0");
                } else {
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
    }
    // Close statement
            mysqli_stmt_close($stmt_update);

    // Close connection
    mysqli_close($link);

  } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <title>Gun Violence</title>

    <!--web fonts-->
    <link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!--bootstrap styles-->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!--icon font-->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/dashlab-icon/dashlab-icon.css" rel="stylesheet">
    <link href="assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendor/weather-icons/css/weather-icons.min.css" rel="stylesheet">

    <!--top nav start-->
    <link href="assets/vendor/custom-nav/css/core-menu.css" rel="stylesheet">
    <link href="assets/vendor/custom-nav/css/responsive.css" rel="stylesheet">

    <!--jquery ui-->
    <link href="assets/vendor/jquery-ui/jquery-ui.min.css" rel="stylesheet">

    <!--iCheck-->
    <link href="assets/vendor/icheck/skins/all.css" rel="stylesheet">

    <!--custom styles-->
    <link href="assets/css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/vendor/html5shiv.js"></script>
    <script src="assets/vendor/respond.min.js"></script>
    <![endif]-->
</head>

<body class="fixed-nav top-nav header-fixed">
<!--header start-->
<header class="app-header">
    <div class="container">
        <div class="row">
            
        </div>
    </div>
</header>
<!--search modal start-->
<div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" class="form-control" placeholder="Search...">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
<!--search modal start-->
    <!--search modal start-->
    <!--header end-->

    <div class="app-body">
        
        <!--main content wrapper-->
        <div class="content-wrapper">

            <div class="container-fluid">

                <!--page title-->
                <div class="page-title mb-4 d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Gun Violence</h4>
                        <nav aria-label="breadcrumb" class="d-inline-block ">
                            <ol class="breadcrumb p-0">
                                <li class="breadcrumb-item"><a href="index.php">Add Entry</a></li>
                                <li class="breadcrumb-item"><a href="view.php">View All Entries</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Read More</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--/page title-->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-warning">
                                    <div class="custom-title">View Data

                                        <form method="post" action="">
                                        <?php
                                            if(mysqli_num_rows($result_train) == 1){
                                                if ($button_show_train == 'yes'){
                                                echo '<a href="result.php?id='. $row['id'] .'">'?><button type="submit" name="submit" style="float: right; padding: .4rem 1.5rem;" class="btn btn-success form-pill">Retrain ML Model</button></a>

                                         <?php } else { 

                                                echo '<span style="float:right; color: red;">This Model has already been retrained</span>';
                                         }; ?>
                                                
                                        <?php } else { ?>
                                            <?php
                                             echo '<a href="result.php?id='. $row['id'] .'">'?><button type="button" style="float: right; padding: .4rem 1.5rem;" class="btn btn-success form-pill">View Results</button></a>
                                        
                                        <?php
                                         }
                                     ?>
                                        </form>
                                            
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                
                                    <div>
                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="state_code" class="col-sm-4 col-form-label">State Code</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["state_code"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="region" class="col-sm-4 col-form-label">Region</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["region"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="urban" class="col-sm-4 col-form-label">Urban / Suburban</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["urban"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                 <div class="row col-sm-6 right">
                                                    <label for="leakage_how" class="col-sm-4 col-form-label col-form-label-sm">Leakage - How? *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["leakage_how"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="age" class="col-sm-4 col-form-label">Age</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["age"]; ?>" readonly>
                                                    </div>
                                                </div>
                                                
                                                <div class="row col-sm-6 right">
                                                    <label for="region" class="col-sm-4 col-form-label col-form-label-sm">Religion </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["religion"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="race" class="col-sm-4 col-form-label col-form-label-sm">Race *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["race"]; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="row col-sm-6 right">
                                                    <label for="education" class="col-sm-4 col-form-label col-form-label-sm">Education </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["education"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="birth_order" class="col-sm-4 col-form-label col-form-label-sm">Birth Order </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["birth_order"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="school" class="col-sm-4 col-form-label col-form-label-sm">School Performance</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["school_perf"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="relationship" class="col-sm-4 col-form-label col-form-label-sm">Relationship </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["relationship"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="no_of_siblings" class="col-sm-4 col-form-label col-form-label-sm">Number of Siblings </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["no_siblings"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="employment" class="col-sm-4 col-form-label col-form-label-sm">Employment Status</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["employment_status"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="children" class="col-sm-4 col-form-label col-form-label-sm">Children </label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["children"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="community_involvement" class="col-sm-4 col-form-label col-form-label-sm">Community Involvement *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["community_involvement"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="employment_type" class="col-sm-4 col-form-label col-form-label-sm">Employment Type *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["employment_type"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="leakage_who" class="col-sm-4 col-form-label col-form-label-sm">Leakage - Who? *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["leakage_who"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="military_branch" class="col-sm-4 col-form-label col-form-label-sm">Military Branch *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["military_branch"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="part_1_crimes" class="col-sm-4 col-form-label col-form-label-sm">Part 1 Crimes *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["part_1_crimes"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="part_1_crimes" class="col-sm-4 col-form-label col-form-label-sm">Part 2 Crimes *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["part_2_crimes"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="domestic_abuse_spec" class="col-sm-4 col-form-label col-form-label-sm">Domestic Abuse Specified *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["domestic_abuse_spec"]; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="row col-sm-6 right">
                                                    <label for="leakage_specific" class="col-sm-4 col-form-label col-form-label-sm">Leakage - Specific? *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["leakage_specific"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="childhood_socioeconomic" class="col-sm-4 col-form-label col-form-label-sm">Childhood Socioeconomic *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["childhood_socioeconomic"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="timeframe_signs_crisis" class="col-sm-4 col-form-label col-form-label-sm">Timeframe of when signs of crisis began *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["timeframe_signs_crisis"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="recent_stressor_triggering_event" class="col-sm-4 col-form-label">Recent stressor / triggering event *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["recent_stressor_triggering_event"]; ?>" readonly>
                                                    </div>
                                                </div>
                                                
                                                <div class="row col-sm-6 right">
                                                    <label for="signs_of_being_in_crisis" class="col-sm-4 col-form-label">Known Prejudices_b</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["known_prejudices"]; ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="substance_use_and_abuse" class="col-sm-4 col-form-label col-form-label-sm">Substance use and abuse *</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["substance_use_and_abuse"]; ?>" readonly>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="interest_in_past_mass_violence" class="col-sm-4 col-form-label col-form-label-sm">Criminal Record</label>
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" value = "<?php echo $row["criminal_sentence"]; ?>" readonly/>
                                                    </div>
                                                </div>
                                            </div>

                                        
                                        
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!--footer-->
            <footer class="sticky-footer">
                <div class="container">
                    <div class="text-center">
                        <small>Copyright &copy; Gun Violence 2022</small>
                    </div>
                </div>
            </footer>
            <!--/footer-->
        </div>
        <!--/main content wrapper-->

        
    </div>
    

</body>
</html>