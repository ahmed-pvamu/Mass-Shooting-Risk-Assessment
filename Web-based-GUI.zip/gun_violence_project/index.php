<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <title>Gun Violence</title>

    <!--web fonts-->
    <link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!--bootstrap styles-->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!--icon font-->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/dashlab-icon/dashlab-icon.css" rel="stylesheet">
    <link href="assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendor/weather-icons/css/weather-icons.min.css" rel="stylesheet">

    <!--top nav start-->
    <link href="assets/vendor/custom-nav/css/core-menu.css" rel="stylesheet">
    <link href="assets/vendor/custom-nav/css/responsive.css" rel="stylesheet">

    <!--jquery ui-->
    <link href="assets/vendor/jquery-ui/jquery-ui.min.css" rel="stylesheet">

    <!--iCheck-->
    <link href="assets/vendor/icheck/skins/all.css" rel="stylesheet">

    <!--jqery steps-->
    <link href="assets/vendor/jquery-steps/jquery.steps.css" rel="stylesheet">

    <!--select2-->
    <link href="assets/vendor/select2/css/select2.css" rel="stylesheet">

    <!--custom styles-->
    <link href="assets/css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/vendor/html5shiv.js"></script>
    <script src="assets/vendor/respond.min.js"></script>
    <![endif]-->
</head>

<body class="fixed-nav top-nav header-fixed">
<!--header start-->
<header class="app-header">
    <div class="container">
        <div class="row">

        </div>
    </div>
</header>
   <!--search modal start-->
<div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" class="form-control" placeholder="Search...">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
<!--search modal start-->
    <!--search modal start-->
    <!--header end-->

    <div class="app-body">
        
        
        
        <!--main content wrapper-->
        <div class="content-wrapper">

            <div class="container-fluid">

                <!--page title-->
                <div class="page-title mb-4 d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Gun Violence</h4>
                        <nav aria-label="breadcrumb" class="d-inline-block">
                            <ol class="breadcrumb p-0">
                                <li class="breadcrumb-item active" aria-current="page">Add Entry</li>
                                <li class="breadcrumb-item"><a href="view.php">View All Entries</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--/page title-->

                <div class="row">
<!-- START TOBA-->
                    <div class="col-xl-12">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-warning">
                                    <div class="custom-title">QUESTIONS</div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form id="wizard-validation-form" action="submit.php" method="post" class="right-text-label-form custom-wz">
                                    <div>
                                        <h3>
                                            <span class="wz-title">Step 1</span>
                                            <span class="wz-sub-header">Prompt</span>
                                        </h3>
                                        <section>
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label col-form-label-sm">Has this Individual Committed Mass Shooting?</label>
                                                <div class="col-sm-4">
                                                    <select class="required form-control" id="" name="confirmed_mass_shooter">
                                                        <option value="">
                                                            Select a value
                                                        </option>
                                                        <option value="No">
                                                            No
                                                        </option>
                                                        <option value="Yes">
                                                            Yes
                                                        </option> 
                                                    </select>
                                                </div>
                                            </div>
                                        </section>
                                        <h3>
                                            <span class="wz-title">Step 2</span>
                                            <span class="wz-sub-header">Location</span>
                                        </h3>
                                        <section>
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label col-form-label-sm">State Code *</label>
                                                <div class="col-sm-4">
                                                    <select class="required form-control" id="option_s1" name="state_code">
                                                        <option value="">
                                                            Select a value
                                                        </option>
                                                        <option value="1|Alabama">
                                                            Alabama
                                                        </option>
                                                        <option value="2|Alaska">
                                                            Alaska
                                                        </option>
                                                        <option value="3|Arizona">
                                                            Arizona
                                                        </option>
                                                        <option value="4|Arkansas">
                                                            Arkansas
                                                        </option>
                                                        <option value="5|California">
                                                            California
                                                        </option>
                                                        <option value="6|Colorado">
                                                            Colorado
                                                        </option>
                                                        <option value="7|Connecticut">
                                                            Connecticut
                                                        </option>
                                                        <option value="8|Delaware">
                                                            Delaware
                                                        </option>
                                                        <option value="9|Florida">
                                                            Florida
                                                        </option>
                                                        <option value="10|Georgia">
                                                            Georgia
                                                        </option>
                                                        <option value="11|Hawaii">
                                                            Hawaii
                                                        </option>
                                                        <option value="12|Idaho">
                                                            Idaho
                                                        </option>
                                                        <option value="13|Illinois">
                                                            Illinois
                                                        </option>
                                                        <option value="14|Indiana">
                                                            Indiana
                                                        </option>
                                                        <option value="15|Iowa">
                                                            Iowa
                                                        </option>
                                                        <option value="16|Kansas">
                                                            Alabama
                                                        </option>
                                                        <option value="17|Kentucky">
                                                            Kansas
                                                        </option>
                                                        <option value="18|Louisiana">
                                                            Louisiana
                                                        </option>
                                                        <option value="19|Maine">
                                                            Maine
                                                        </option>
                                                        <option value="20|Maryland">
                                                            Maryland
                                                        </option>
                                                        <option value="21|Massachusetts">
                                                            Massachusetts
                                                        </option>
                                                        <option value="22|Michigan">
                                                            Louisiana
                                                        </option>
                                                        <option value="23|Minnesota">
                                                            Minnesota
                                                        </option>
                                                        <option value="24|Mississippi">
                                                            Mississippi
                                                        </option>
                                                        <option value="25|Missouri">
                                                            Missouri
                                                        </option>
                                                        <option value="26|Montana">
                                                            Montana
                                                        </option>
                                                        <option value="27|Nebraska">
                                                            Nebraska
                                                        </option>
                                                        <option value="28|Nevada">
                                                            Nevada
                                                        </option>
                                                        <option value="29|New Hamphire">
                                                            New Hamphire
                                                        </option>
                                                        <option value="30|New Jersey">
                                                            New Jersey
                                                        </option>
                                                        <option value="31|New Mexico">
                                                            New Mexico
                                                        </option>
                                                        <option value="32|New York">
                                                            New York
                                                        </option>
                                                        <option value="33|North Carolina">
                                                            North Carolina
                                                        </option>
                                                        <option value="34|North Dakota">
                                                            North Dakota
                                                        </option>
                                                        <option value="35|Ohio">
                                                            Ohio
                                                        </option>
                                                        <option value="36|Oklahoma">
                                                            Oklahoma
                                                        </option>
                                                        <option value="37|Oregon">
                                                            Oregon
                                                        </option>
                                                        <option value="38|Pennsylvania">
                                                            Pennsylvania
                                                        </option>
                                                        <option value="39|Rhode Island">
                                                            Rhode Island
                                                        </option>
                                                        <option value="40|South Carolina">
                                                            South Carolina
                                                        </option>
                                                        <option value="41|South Dakota">
                                                            South Dakota
                                                        </option>
                                                        <option value="42|Tennessee">
                                                            Tennessee
                                                        </option>
                                                        <option value="43|Texas">
                                                            Texas
                                                        </option>
                                                        <option value="44|Utah">
                                                            Utah
                                                        </option>
                                                        <option value="45|Vermont">
                                                            Vermont
                                                        </option>
                                                        <option value="46|Virginia">
                                                            Virginia
                                                        </option>
                                                        <option value="47|Washington">
                                                            Washington
                                                        </option>
                                                        <option value="48|West Virginia">
                                                            West Virginia
                                                        </option>
                                                        <option value="49|Wisconsin">
                                                            Wisconsin
                                                        </option>
                                                        <option value="50|Wyoming">
                                                            Wyoming
                                                        </option>
                                                        <option value="51|Washington DC">
                                                            Washington DC
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label col-form-label-sm">Region *</label>
                                                <div class="col-sm-4">
                                                    <select class="required form-control" id="option_s2f" name="region">
                                                        <option value="">
                                                            Select a value
                                                        </option>
                                                        <option value="0|South">
                                                            South
                                                        </option>
                                                        <option value="1|Midwest">
                                                            Midwest
                                                        </option>
                                                        <option value="2|Northeast">
                                                            Northeast
                                                        </option>
                                                        <option value="3|West">
                                                            West
                                                        </option>
                                                       
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label col-form-label-sm">Urban / Suburban *</label>
                                                <div class="col-sm-4">
                                                    <select class="required form-control" id="option_s3f" name="urban">
                                                        <option value="">
                                                            Select a value
                                                        </option>
                                                        <option value="0|Urban">
                                                            Urban
                                                        </option>
                                                        <option value="1|Suburban">
                                                            Suburban
                                                        </option>
                                                        <option value="2|Rural">
                                                            Rural
                                                        </option>
                                                       
                                                    </select>
                                                </div>
                                            </div>

                                        </section>
                                        <h3>
                                            <span class="wz-title">Step 3</span>
                                            <span class="wz-sub-header">Basic Background</span>
                                        </h3>
                                        <section>
                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="age" class="col-sm-4 col-form-label">Age</label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name ="age" min="1" max="100" required>
                                                    </div>
                                                </div>
                                                
                                                <div class="row col-sm-6 right">
                                                    <label for="region" class="col-sm-4 col-form-label col-form-label-sm">Religion </label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="religion">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|None">
                                                                None
                                                            </option>
                                                            <option value="1|Christian">
                                                                Christian
                                                            </option>
                                                            <option value="2|Muslim">
                                                                Muslim
                                                            </option>
                                                            <option value="3|Buddhist">
                                                                Buddhist
                                                            </option>
                                                            <option value="4|Cultural spirituality/other">
                                                                Cultural
                                                            </option>
                                                            <option value="5|Jewish">
                                                                Jewish
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="race" class="col-sm-4 col-form-label col-form-label-sm">Race *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="race">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|White">
                                                                White
                                                            </option>
                                                            <option value="1|Black">
                                                                Black
                                                            </option>
                                                            <option value="2|Latinix">
                                                                Latinix
                                                            </option>
                                                            <option value="3|Asian">
                                                                Asian
                                                            </option>
                                                            <option value="4|Middle Eastern">
                                                                Middle
                                                            </option>
                                                            <option value="5|Native American">
                                                                Native
                                                            </option>
                                                            <option value="5|Other">
                                                                Other
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row col-sm-6 right">
                                                    <label for="education" class="col-sm-4 col-form-label col-form-label-sm">Education </label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="education">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Less than high school">
                                                                Less than high school
                                                            </option>
                                                            <option value="1|High school/GED">
                                                                High school/GED
                                                            </option>
                                                            <option value="2|Some college/trade School">
                                                                Some college/trade School
                                                            </option>
                                                            <option value="3|Bachelor's degree">
                                                                Bachelor's Degree
                                                            </option>
                                                            <option value="4|Graduate school/advanced degree">
                                                                Graduate school/advanced degree
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="birth_order" class="col-sm-4 col-form-label col-form-label-sm">Birth Order </label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="birth_order">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Only child">
                                                                Only child
                                                            </option>
                                                            <option value="1|Oldest child">
                                                                Oldest child
                                                            </option>
                                                            <option value="2|Middle child">
                                                                Middle child
                                                            </option>
                                                            <option value="3|Youngest child">
                                                                Youngest child
                                                            </option>
                                                            <option value="4|Twin">
                                                                Twin
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="school" class="col-sm-4 col-form-label col-form-label-sm">School Performance</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="school_perf">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Poor (D-F grades, under 2.0 GPA, failed classes, repeated grades)">
                                                                Poor (D-F grades, under 2.0 GPA, failed classes, repeated grades)
                                                            </option>
                                                            <option value="1|Average (C's, 2.0-3.49 GPA)">
                                                                Average (C's, 2.0-3.49 GPA)
                                                            </option>
                                                            <option value="2|Good (A-B grades, 3.5-4.0 GPA)">
                                                                Good (A-B grades, 3.5-4.0 GPA)
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="relationship" class="col-sm-4 col-form-label col-form-label-sm">Relationship Status</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="relationship">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Single">
                                                                Single
                                                            </option>
                                                            <option value="1|Boyfriend/girlfriend">
                                                                Boyfriend/Girlfriend
                                                            </option>
                                                            <option value="2|Married">
                                                                Married
                                                            </option>
                                                            <option value="3|Divorced/separated/widowed">
                                                                Divorced/separated/widowed
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="no_of_siblings" class="col-sm-4 col-form-label col-form-label-sm">Number of Siblings </label>
                                                    <div class="col-sm-7">
                                                        <input type="number" name ="no_siblings" min="1" max="100" required>
                                                    </div>
                                                </div>
                                            </div>

                                            

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="employment" class="col-sm-4 col-form-label col-form-label-sm">Employment Status</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="employment_status">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Not working">
                                                                Not working
                                                            </option>
                                                            <option value="1|Working">
                                                                Working
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="children" class="col-sm-4 col-form-label col-form-label-sm">Children </label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="children">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Yes">
                                                                Yes
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="community_involvement" class="col-sm-4 col-form-label col-form-label-sm">Community Involvement *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="community_involvement">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Somewhat involved">
                                                                Somewhat involved
                                                            </option>
                                                            <option value="2|Heavily informed">
                                                                Heavily informed
                                                            </option>
                                                            <option value="3|Formerly involved but withdrawn">
                                                                Formerly involved but withdrawn
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="employment_type" class="col-sm-4 col-form-label col-form-label-sm">Employment Type *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="employment_type">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Blue Collar">
                                                                Blue collar
                                                            </option>
                                                            <option value="1|White">
                                                                White collar
                                                            </option>
                                                            <option value="2|In Between">
                                                                In between
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="military_branch" class="col-sm-4 col-form-label col-form-label-sm">Military Branch</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="military_branch">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Army">
                                                                Army
                                                            </option>
                                                            <option value="1|Navy">
                                                                Navy
                                                            </option>
                                                            <option value="2|Air Force">
                                                                Air Force
                                                            </option>
                                                            <option value="3|Marines">
                                                                Marines
                                                            </option>
                                                            <option value="4|Coast Guard">
                                                                Coast Guard
                                                            </option>
                                                            <option value="5|National Guard">
                                                                National Guard
                                                            </option>
                                                            <option value="5|Not Applicable">
                                                                Not Applicable
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>


                                        </section>
                                        <h3>
                                            <span class="wz-title">Step 4</span>
                                            <span class="wz-sub-header">Others</span>
                                        </h3>
                                        <section>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="part_1_crimes" class="col-sm-4 col-form-label">Part 1 Crimes *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" multiple id="option_s2" name="part_1_crimes[]" style="width: 100%;">
                                                            <option value=""> 
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Homicide">
                                                                Homicide
                                                            </option>
                                                            <option value="2|Forcible rape">
                                                                Forcible rape
                                                            </option>
                                                            <option value="3|Robbery">
                                                                Robbery
                                                            </option>
                                                            <option value="4|Aggravated Assault">
                                                                Aggravated Assault
                                                            </option>
                                                            <option value="5|Burglary">
                                                                Burglary
                                                            </option>
                                                            <option value="6|Larceny-Theft">
                                                                Larceny-Theft
                                                            </option>
                                                            <option value="7|Motor Vehicle Theft">
                                                                Motor Vehicle Theft
                                                            </option>
                                                            <option value="8|Arson">
                                                                Arson
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="part_2_crimes" class="col-sm-4 col-form-label">Part 2 Crimes *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" multiple id="option_s3" name="part_2_crimes[]" style="width: 100%;">
                                                            <option value=""> 
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Simple assault">
                                                                Simple assault
                                                            </option>
                                                            <option value="2|Fraud, forgery, embezzlement">  
                                                                Fraud, forgery, embezzlement
                                                            </option>
                                                            <option value="3|Stolen property">
                                                                Stolen property
                                                            </option>
                                                            <option value="4|Vandalism">
                                                                Vandalism
                                                            </option>
                                                            <option value="5|Weapons offenses">
                                                                Weapons offenses
                                                            </option>
                                                            <option value="6|Prostitution or other non-rape sex offenses">
                                                                 Prostitution or other non-rape sex offenses
                                                            </option>
                                                            <option value="7|Drugs">
                                                                Drugs
                                                            </option>
                                                            <option value="8|Dui">
                                                                DUI
                                                            </option>
                                                            <option value="9|Other">
                                                                Other
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="domestic_abuse_spec" class="col-sm-4 col-form-label col-form-label-sm">Domestic Abuse Specified *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="domestic_abuse_spec">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|N/A">
                                                                N/A
                                                            </option> 
                                                            <option value="1|Non-sexual physical violence">
                                                                Non-sexual physical violence
                                                            </option>
                                                            <option value="2|Sexual violence">
                                                                Sexual violence
                                                            </option>
                                                            <option value="3|Threats / coercive control">
                                                                Threats / coercive control
                                                            </option>
                                                            <option value="4|Threats with deadly weapon">
                                                                Threats with a deadly weapon
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row col-sm-6 right">
                                                    

                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="childhood_socioeconomic" class="col-sm-4 col-form-label col-form-label-sm">Childhood Socioeconomic *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="childhood_socioeconomic">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Lower class">
                                                                Lower class
                                                            </option>
                                                            <option value="1|middle class">
                                                                Middle class
                                                            </option>
                                                            <option value="2|upper class">
                                                                Upper class
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="timeframe_signs_crisis" class="col-sm-4 col-form-label col-form-label-sm">Timeframe of when signs of crisis began *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="timeframe_signs_crisis">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Days before shooting">
                                                                Days before shooting
                                                            </option>
                                                            <option value="1|Weeks before shooting">
                                                                Weeks before shooting
                                                            </option>
                                                            <option value="2|Months before shooting">
                                                                Months before shooting
                                                            </option>
                                                            <option value="3|Years before shooting">
                                                                Years before shooting
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="recent_stressor_triggering_event" class="col-sm-4 col-form-label">Recent or Ongoing stressor *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" multiple id="" name="recent_stressor_triggering_event[]" style="width: 100%;">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Recent break-up">
                                                                Recent break-up
                                                            </option>
                                                            <option value="2|Employment stressor">
                                                                Employment stressor
                                                            </option>
                                                            <option value="3|Economic stressor">
                                                                Economic stressor
                                                            </option>
                                                            <option value="4|Family issue">
                                                                Family issue
                                                            </option>
                                                            <option value="5|Legal issue">
                                                                Legal issue
                                                            </option>
                                                            <option value="6|Other">
                                                                Other
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <div class="row col-sm-6 right">
                                                    <label for="signs_of_being_in_crisis" class="col-sm-4 col-form-label">known Prejudices *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" multiple id="" name="known_prejudices[]" style="width: 100%;">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Racism">
                                                                Racism
                                                            </option>
                                                            <option value="2|Misogyny">
                                                                Misogyny
                                                            </option>
                                                            <option value="3|Homophobia">
                                                                Homophobia
                                                            </option>
                                                            <option value="3|Religious hatred">
                                                                Religious hatred
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="substance_use_and_abuse" class="col-sm-4 col-form-label col-form-label-sm">Substance use and abuse *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" multiple id="" name="substance_use_and_abuse[]" style="width: 100%;">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|No evidence">
                                                                No evidence
                                                            </option>
                                                            <option value="1|Problem with alcohol">
                                                                Problem with alcohol
                                                            </option>
                                                            <option value="2|Marijuana">
                                                                Marijuana
                                                            </option>
                                                             <option value="3|Other drugs">
                                                                Other drugs
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    


                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="leakage_how" class="col-sm-4 col-form-label col-form-label-sm">Leakage - How? *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" multiple name="leakage_how[]" style="width: 100%;">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="1|In person">
                                                                In person
                                                            </option>
                                                            <option value="2|Letter">
                                                                Letter
                                                            </option>
                                                            <option value="3|Other writing">
                                                                Other writing
                                                            </option>
                                                            <option value="4|Phone / text">
                                                                Phone / text
                                                            </option>
                                                            <option value="5|Internet / scoial media">
                                                                Internet / social media
                                                            </option>
                                                            <option value="6|Other">
                                                                Other
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="leakage_who" class="col-sm-4 col-form-label col-form-label-sm">Leakage - Who? *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" multiple name="leakage_who[]" style="width: 100%;">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="1|Mental health professional">
                                                                Mental health professional
                                                            </option>
                                                            <option value="2|Immediate family">
                                                                Immediate family
                                                            </option>
                                                            <option value="3|Wife/girlfriend">
                                                                Wife/girlfriend
                                                            </option>
                                                            <option value="4|Police">
                                                                Police
                                                            </option>
                                                            <option value="5|Coworker/supervisor">
                                                                Coworker/supervisor
                                                            </option>
                                                            <option value="6|Friend/neighbor">
                                                                Friend/neighbor
                                                            </option>
                                                            <option value="7|Classmate">
                                                                Classmate
                                                            </option>
                                                            <option value="8|Teacher/school staff">
                                                                Teacher/school staff
                                                            </option>
                                                            <option value="9|Waitress/bartender/clerk">
                                                                Waitress/bartender/blerk
                                                            </option>
                                                            <option value="10|Other">
                                                                Other
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="row col-sm-6 left">
                                                    <label for="leakage_specific" class="col-sm-4 col-form-label col-form-label-sm">Leakage - Specific? *</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="leakage_specific">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|Nonspecific Threatened Voilence">
                                                                Nonspecific (threatened violence)
                                                            </option>
                                                            <option value="1|Specific Threatened shooting">
                                                                Specific (threatened shooting)
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row col-sm-6 right">
                                                    <label for="interest_in_past_mass_violence" class="col-sm-4 col-form-label col-form-label-sm">Criminal Record</label>
                                                    <div class="col-sm-7">
                                                        <select class="required form-control" id="" name="criminal_sentence">
                                                            <option value="">
                                                                Select a value
                                                            </option>
                                                            <option value="0|N/A">
                                                                N/A
                                                            </option>
                                                            <option value="1|Death Penalty">
                                                                Death Penalty
                                                            </option>
                                                            <option value="2|Life without parole">
                                                                Life without parole
                                                            </option>
                                                            <option value="3|Life imprisonment (with possibility of parole)">
                                                                Life imprisonment (with possibility of parole)
                                                            </option>
                                                            <option value="4|Hospitalization">
                                                                Hospitalization
                                                            </option>
                                                            <option value="5|Juvenile detention">
                                                                Juvenile detention
                                                            </option>
                                                           
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                        </section>
                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!--footer-->
            <footer class="sticky-footer">
                <div class="container">
                    <div class="text-center">
                        <small>Copyright &copy; Gun Violence 2022</small>
                    </div>
                </div>
            </footer>
            <!--/footer-->
        </div>
        <!--/main content wrapper-->

        
    </div>
    <!--basic scripts-->
    <script type="text/javascript">

         $('#immigrant').select2({
                placeholder: "Select Immigrant"  
            }); 

         $('#part_2_crimes').select2({
                placeholder: "Select Part 2 Crimes"  
            });
          $('#part_1_crimes').select2({
                placeholder: "Select Part 1 Crimes"  
            });
    </script>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/vendor/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/vendor/icheck/skins/icheck.min.js"></script>
    <script src="assets/vendor/jquery.nicescroll.min.js"></script>
    <!--jquery validate-->
    <script src="assets/vendor/jquery-validation/jquery.validate.min.js"></script>

    <!--jquery steps-->
    <script src="assets/vendor/jquery-steps/jquery.steps.min.js"></script>
    <!--init steps-->
    <script src="assets/vendor/js-init/init-form-wizard.js"></script>

    <!--jquery stepy-->
    <script src="assets/vendor/jquery-steps/jquery.stepy.js"></script>

    <!--select2-->
    <script src="assets/vendor/select/select2.full.min.js"></script>
   <!-- <script src="assets/vendor/select/select2.js"></script>-->

    <!--select2-->
    <script src="assets/vendor/select2/js/select2.min.js"></script>
    <!--init select2-->
    <script src="assets/vendor/js-init/init-select2.js"></script>

    <!--[if lt IE 9]>
    <script src="assets/vendor/modernizr.js"></script>
    <![endif]-->

    <!--basic scripts initialization-->
    <script src="assets/js/scripts.js"></script>
</body>
</html>

