<?php

include "db_connection.php";

$model_2 = '{ "prediction": [
        [31.0, 2343.0, 0.0, 24.0, 0.0, 1.0, 4.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 999.0, 1.0, 0.0, 0.0, 0.0, 1.0, 3.0, 2.0, 3.0, 0.0, 1.0, 7.0, 1.0, 2.0, 0.79],
        [3.0, 2.0, 0.0, 46.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 999.0, 0.0, 0.0, 0.0, 0.0, 999.0, 0.0, 3.0, 0.0, 3.0, 5.0, 10.0, 0.0, 999.0, 0.82],
        [2.0, 0.0, 1.0, 19.0, 0.0, 999.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 999.0, 3.0, 0.0, 10.0, 5.0, 2.0, 4.0, 2.0, 3.0, 8.0, 5.0, 10.0, 1.0, 999.0, 0.82]
    ]
}';

    $model_2_decoded = json_decode($model_2);


    $csv = array_map('str_getcsv', file('render.csv'));

			$model_2_decoded_percentage_2 = 100 * $model_2_decoded->prediction[1][28];
			$model_type_model2_2 = "Model 2";
			$observation_no_model2_2 = "2";

			//State_Code
			$state_code_no_model2_api_2 = (int)$model_2_decoded->prediction[1][0];
			if ( ! isset ($csv[1][$state_code_no_model2_api_2 - 1])) {
				$state_code_no_model2_2 = "NULL";
			} else {
				$state_code_no_model2_2 = $csv[1][$state_code_no_model2_api_2 - 1];
			}
			

			//Region
			$region_no_model2_api_2 = (int)$model_2_decoded->prediction[1][1];
			if ( ! isset ($csv[1][$region_no_model2_api_2])) {
				$region_no_model2_2 = "NULL";
			} else {
				$region_no_model2_2 = $csv[1][$region_no_model2_api_2];
			}
			

			//Urban
			$urban_no_model2_api_2 = (int)$model_2_decoded->prediction[1][2];
			if ( ! isset ($csv[2][$urban_no_model2_api_2])) {
				$urban_no_model2_2 = "NULL";
			} else {
				$urban_no_model2_2 = $csv[2][$urban_no_model2_api_2];
			}
			

			//Age
			$age_no_model2_2_int = (int)$model_2_decoded->prediction[1][3];
			$age_no_model2_2 = (string)$age_no_model2_2_int;


			//Race
			$race_no_model2_api_2 = (int)$model_2_decoded->prediction[1][4];
			if ( ! isset ($csv[4][$race_no_model2_api_2])) {
				$race_no_model2_2 = "NULL";
			} else {
				$race_no_model2_2 = $csv[4][$race_no_model2_api_2];
			}
			

			//Religion
			$religion_no_model2_api_2 = (int)$model_2_decoded->prediction[1][5];
			if ( ! isset ($csv[5][$religion_no_model2_api_2])) {
				$religion_no_model2_2 = "NULL";
			} else {
				$religion_no_model2_2 = $csv[5][$religion_no_model2_api_2];
			}
			

			//Education
			$education_no_model2_api_2 = (int)$model_2_decoded->prediction[1][6];
			if ( ! isset ($csv[6][$education_no_model2_api_2])) {
				$education_no_model2_2 = "NULL";
			} else {
				$education_no_model2_2 = $csv[6][$education_no_model2_api_2];
			}
			

			//School Perf
			$school_perf_no_model2_api_2 = (int)$model_2_decoded->prediction[1][7];
			if ( ! isset ($csv[7][$school_perf_no_model2_api_2])) {
				$school_perf_no_model2_2 = "NULL";
			} else {
				$school_perf_no_model2_2 = $csv[7][$school_perf_no_model2_api_2];
			}
			

			//Birth Order
			$birth_order_no_model2_api_2 = (int)$model_2_decoded->prediction[1][8];
			if ( ! isset ($csv[8][$birth_order_no_model2_api_2])) {
				$birth_order_no_model2_2 = "NULL";
			} else {
				$birth_order_no_model2_2 = $csv[8][$birth_order_no_model2_api_2];
			}


			//No of Siblings
			$no_siblings_no_model2_2_int = (int)$model_2_decoded->prediction[1][9];
			$no_siblings_no_model2_2 = (string)$no_siblings_no_model2_2_int;


			//Relationship Status
			$relationship_no_model2_api_2 = (int)$model_2_decoded->prediction[1][10];
			if ( ! isset ($csv[10][$relationship_no_model2_api_2])) {
				$relationship_no_model2_2 = "NULL";
			} else {
				$relationship_no_model2_2 = $csv[10][$relationship_no_model2_api_2];
			}
			

			//Children
			$children_no_model2_api_2 = (int)$model_2_decoded->prediction[1][11];
			if ( ! isset ($csv[11][$children_no_model2_api_2])) {
				$children_no_model2_2 = "NULL";
			} else {
				$children_no_model2_2 = $csv[11][$children_no_model2_api_2];
			}


			//Employment Status
			$employment_status_no_model2_api_2 = (int)$model_2_decoded->prediction[1][12];
			if ( ! isset ($csv[12][$employment_status_no_model2_api_2])) {
				$employment_status_no_model2_2 = "NULL";
			} else {
				$employment_status_no_model2_2 = $csv[12][$employment_status_no_model2_api_2];
			}


			//Employment Type
			$employment_type_no_model2_api_2 = (int)$model_2_decoded->prediction[1][13];
			if ( ! isset ($csv[13][$employment_type_no_model2_api_2])) {
				$employment_type_no_model2_2 = "NULL";
			} else {
				$employment_type_no_model2_2 = $csv[13][$employment_type_no_model2_api_2];
			}
			

			//Military Branch
			$military_branch_no_model2_api_2 = (int)$model_2_decoded->prediction[1][14];
			if ( ! isset ($csv[14][$military_branch_no_model2_api_2])) {
				$military_branch_no_model2_2 = "NULL";
			} else {
				$military_branch_no_model2_2 = $csv[14][$military_branch_no_model2_api_2];
			}
			

			//community_involvement_no
			$community_involvement_no_model2_api_2 = (int)$model_2_decoded->prediction[1][15];
			if ( ! isset ($csv[15][$community_involvement_no_model2_api_2])) {
				$community_involvement_no_model2_2 = "NULL";
			} else {
				$community_involvement_no_model2_2 = $csv[15][$community_involvement_no_model2_api_2];
			}
			

			//part_1_crimes_no
			$part_1_crimes_no_model2_2_int = (int)$model_2_decoded->prediction[1][16];
			$part_1_crimes_no_model2_2 = (string)$part_1_crimes_no_model2_2_int;


			//part_2_crimes_no
			$part_2_crimes_no_model2_2_int = (int)$model_2_decoded->prediction[1][17];
			$part_2_crimes_no_model2_2 = (string)$part_2_crimes_no_model2_2_int;


			//domestic_abuse_spec_no
			$domestic_abuse_spec_no_model2_api_2 = (int)$model_2_decoded->prediction[1][18];
			if ( ! isset ($csv[18][$domestic_abuse_spec_no_model2_api_2])) {
				$domestic_abuse_spec_no_model2_2 = "NULL";
			} else {
				$domestic_abuse_spec_no_model2_2 = $csv[18][$domestic_abuse_spec_no_model2_api_2];
			}
			

			//childhood_socioeconomic_no
			$childhood_socioeconomic_no_model2_api_2 = (int)$model_2_decoded->prediction[1][19];
			if ( ! isset ($csv[19][$childhood_socioeconomic_no_model2_api_2])) {
				$childhood_socioeconomic_no_model2_2 = "NULL";
			} else {
				$childhood_socioeconomic_no_model2_2 = $csv[19][$childhood_socioeconomic_no_model2_api_2];
			}
			

			//recent_stressor_triggering_event_no
			$recent_stressor_triggering_event_no_model2_api_2 = (int)$model_2_decoded->prediction[1][20];
			if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model2_api_2])) {
				$recent_stressor_triggering_event_no_model2_2 = "NULL";
			} else {
				$recent_stressor_triggering_event_no_model2_2 = $csv[20][$recent_stressor_triggering_event_no_model2_api_2];
			}
			

			//timeframe_signs_crisis_no
			$timeframe_signs_crisis_no_model2_api_2 = (int)$model_2_decoded->prediction[1][21];
			if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model2_api_2])) {
				$timeframe_signs_crisis_no_model2_2 = "NULL";
			} else {
				$timeframe_signs_crisis_no_model2_2 = $csv[21][$timeframe_signs_crisis_no_model2_api_2];
			}
			

			//substance_use_and_abuse_no
			$substance_use_and_abuse_no_model2_api_2 = (int)$model_2_decoded->prediction[1][22];
			if ( ! isset ($csv[22][$substance_use_and_abuse_no_model2_api_2])) {
				$substance_use_and_abuse_no_model2_2 = "NULL";
			} else {
				$substance_use_and_abuse_no_model2_2 = $csv[22][$substance_use_and_abuse_no_model2_api_2];
			}
			

			//known_prejudices
			$known_prejudices_no_model2_api_2 = (int)$model_2_decoded->prediction[1][23];
			if ( ! isset ($csv[23][$known_prejudices_no_model2_api_2])) {
				$known_prejudices_no_model2_2 = "NULL";
			} else {
				$known_prejudices_no_model2_2 = $csv[23][$known_prejudices_no_model2_api_2];
			}
			

			//leakage_how_no
			$leakage_how_no_model2_api_2 = (int)$model_2_decoded->prediction[1][24];
			if ( ! isset ($csv[24][$leakage_how_no_model2_api_2 - 1])) {
				$leakage_how_no_model2_2 = "NULL";
			} else {
				$leakage_how_no_model2_2 = $csv[24][$leakage_how_no_model2_api_2 - 1];
			}
			

			//leakage_who_no
			$leakage_who_no_model2_api_2 = (int)$model_2_decoded->prediction[1][25];
			if ( ! isset ($csv[25][$leakage_who_no_model2_api_2 - 1])) {
				$leakage_who_no_model2_2 = "NULL";
			} else {
				$leakage_who_no_model2_2 = $csv[25][$leakage_who_no_model2_api_2 - 1];
			}
			

			//leakage_specific_no
			$leakage_specific_no_model2_api_2 = (int)$model_2_decoded->prediction[1][26];
			if ( ! isset ($csv[26][$leakage_specific_no_model2_api_2])) {
				$leakage_specific_no_model2_2 = "NULL";
			} else {
				$leakage_specific_no_model2_2 = $csv[26][$leakage_specific_no_model2_api_2];
			}
			

			//criminal sentence
			$criminal_sentence_model2_api_2 = (int)$model_2_decoded->prediction[1][27];
			if ( ! isset ($csv[27][$criminal_sentence_model2_api_2])) {
				$criminal_sentence_model2_2 = "NULL";
			} else {
				$criminal_sentence_model2_2 = $csv[27][$criminal_sentence_model2_api_2];
			}

			/************************* Insert Model 2 - Observation 2 Result in DB ******************************/ 
			$sql_model2_1 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			if($stmt_model2_1 = mysqli_prepare($link, $sql_model2_1)){

 			mysqli_stmt_bind_param($stmt_model2_1, "ssssssssssssssssssssssssssssssss", $parent_id_model2_1, $model_type_model2_1, $observation_no_model2_1, $percentage_model2_1, $state_code_model2_1, $region_model2_1, $urban_model2_1, $age_model2_1, $religion_model2_1, $race_model2_1, $education_model2_1, $birth_order_model2_1, $relationship_model2_1, $school_perf_model2_1, $no_siblings_model2_1, $employment_status_model2_1, $children_model2_1, $community_involvement_model2_1, $employment_type_model2_1, $military_branch_model2_1, $part_1_crimes_model2_1, $part_2_crimes_model2_1, $domestic_abuse_spec_model2_1, $childhood_socioeconomic_model2_1, $timeframe_signs_crisis_model2_1, $recent_stressor_triggering_event_model2_1, $known_prejudices_model2_1, $substance_use_and_abuse_model2_1, $leakage_how_model2_1, $leakage_who_model2_1, $leakage_specific_model2_1, $criminal_sentence_model2_1);

 				$parent_id_model2_1 = "34";
 				$model_type_model2_1 = $model_type_model2_2;
 				$observation_no_model2_1 = $observation_no_model2_2;
 				$percentage_model2_1 = $model_2_decoded_percentage_2;
				$state_code_model2_1 = $state_code_no_model2_2;
				$region_model2_1 = $region_no_model2_2;
				$urban_model2_1 = $urban_no_model2_2;
				$age_model2_1 = $age_no_model2_2;
				$religion_model2_1 = $religion_no_model2_2;
				$race_model2_1 = $race_no_model2_2;
				$education_model2_1 = $education_no_model2_2;
				$birth_order_model2_1 = $birth_order_no_model2_2;
				$relationship_model2_1 = $relationship_no_model2_2;
				$school_perf_model2_1 = $school_perf_no_model2_2;
				$no_siblings_model2_1 = $no_siblings_no_model2_2;
				$employment_status_model2_1 = $employment_status_no_model2_2;
				$children_model2_1 = $children_no_model2_2;
				$community_involvement_model2_1 = $community_involvement_no_model2_2;
				$employment_type_model2_1 = $employment_type_no_model2_2;
				$military_branch_model2_1 = $military_branch_no_model2_2;
				$part_1_crimes_model2_1 = $part_1_crimes_no_model2_2;
				$part_2_crimes_model2_1 = $part_2_crimes_no_model2_2;
				$domestic_abuse_spec_model2_1 = $domestic_abuse_spec_no_model2_2;
				$childhood_socioeconomic_model2_1 = $childhood_socioeconomic_no_model2_2;
				$timeframe_signs_crisis_model2_1 = $timeframe_signs_crisis_no_model2_2;
				$recent_stressor_triggering_event_model2_1 = $recent_stressor_triggering_event_no_model2_2;
				$known_prejudices_model2_1 = $known_prejudices_no_model2_2;
				$substance_use_and_abuse_model2_1 = $substance_use_and_abuse_no_model2_2;
				$leakage_how_model2_1 = $leakage_how_no_model2_2;
				$leakage_who_model2_1 = $leakage_who_no_model2_2;
				$leakage_specific_model2_1 = $leakage_specific_no_model2_2;
				$criminal_sentence_model2_1 = $criminal_sentence_model2_2;
			}

			mysqli_stmt_execute($stmt_model2_1);

   			// Close statement
	 		mysqli_stmt_close($stmt_model2_1);

	 	?>