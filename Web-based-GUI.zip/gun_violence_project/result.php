<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "db_connection.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM entry_data WHERE id = ?";

    //Model 2
    $sql_model2_1 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";
    $sql_model2_2 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";
    $sql_model2_3 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";

    //Model 3
    $sql_model3_1 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";
    $sql_model3_2 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";
    $sql_model3_3 = "SELECT * FROM results_data WHERE parent_id = ? AND model_type = ? AND observation_no = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                //Retrieve individual field value
                //echo '<pre>';
                //print_r($row);
                //echo '</pre>';

                $model_1_result = $row["model_1_result"];
                $state_code = $row["state_code"];
                $region = $row["region"];
                $urban = $row["urban"];
                $age = $row["age"];
                $race = $row["race"];
                $religion = $row["religion"];
                $education = $row["education"];
                $school_perf = $row["school_perf"];
                $birth_order = $row["birth_order"];
                $no_siblings = $row["no_siblings"];
                $relationship = $row["relationship"];
                $children = $row["children"];
                $employment_status = $row["employment_status"];
                $employment_type = $row["employment_type"];
                $military_branch = $row["military_branch"];
                $community_involvement = $row["community_involvement"];
                $part_1_crimes = $row["part_1_crimes"];
                $part_2_crimes = $row["part_2_crimes"];
                $domestic_abuse_spec = $row["domestic_abuse_spec"];
                $childhood_socioeconomic = $row["childhood_socioeconomic"];
                $recent_stressor_triggering_event = $row["recent_stressor_triggering_event"];
                $timeframe_signs_crisis = $row["timeframe_signs_crisis"];
                $substance_use_and_abuse = $row["substance_use_and_abuse"];
                $known_prejudices = $row["known_prejudices"];
                $leakage_how = $row["leakage_how"];
                $leakage_who = $row["leakage_who"];
                $leakage_specific = $row["leakage_specific"];
                $criminal_sentence = $row["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error1.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);

    //Model 2 - 1
    if($stmt_sql_model2_1 = mysqli_prepare($link, $sql_model2_1)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model2_1, "iss", $param_id_model2_1, $model_type_model2_1, $observation_model2_1);
        
        // Set parameters
        $param_id_model2_1 = trim($_GET["id"]);
        $model_type_model2_1 = "Model 2";
        $observation_model2_1 = "1";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model2_1)){
            $result_model2_1 = mysqli_stmt_get_result($stmt_sql_model2_1);
    
            if(mysqli_num_rows($result_model2_1) >= 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model2_1 = mysqli_fetch_array($result_model2_1, MYSQLI_ASSOC);
                
                // Retrieve individual field value

                $model_type_model2_1 = $row_model2_1["model_type"];
                $observation_no_model2_1 = $row_model2_1["observation_no"];
                $percentage_model2_1 = $row_model2_1["percentage"];

                $state_code_model2_1 = $row_model2_1["state_code"];
                $region_model2_1 = $row_model2_1["region"];
                $urban_model2_1 = $row_model2_1["urban"];
                $age_model2_1 = $row_model2_1["age"];
                $race_model2_1 = $row_model2_1["race"];
                $religion_model2_1 = $row_model2_1["religion"];
                $education_model2_1 = $row_model2_1["education"];
                $school_perf_model2_1 = $row_model2_1["school_perf"];
                $birth_order_model2_1 = $row_model2_1["birth_order"];
                $no_siblings_model2_1 = $row_model2_1["no_siblings"];
                $relationship_model2_1 = $row_model2_1["relationship"];
                $children_model2_1 = $row_model2_1["children"];
                $employment_status_model2_1 = $row_model2_1["employment_status"];
                $employment_type_model2_1 = $row_model2_1["employment_type"];
                $military_branch_model2_1 = $row_model2_1["military_branch"];
                $community_involvement_model2_1 = $row_model2_1["community_involvement"];
                $part_1_crimes_model2_1 = $row_model2_1["part_1_crimes"];
                $part_2_crimes_model2_1 = $row_model2_1["part_2_crimes"];
                $domestic_abuse_spec_model2_1 = $row_model2_1["domestic_abuse_spec"];
                $childhood_socioeconomic_model2_1 = $row_model2_1["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model2_1 = $row_model2_1["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model2_1 = $row_model2_1["timeframe_signs_crisis"];
                $substance_use_and_abuse_model2_1 = $row_model2_1["substance_use_and_abuse"];
                $known_prejudices_model2_1 = $row_model2_1["known_prejudices"];
                $leakage_how_model2_1 = $row_model2_1["leakage_how"];
                $leakage_who_model2_1 = $row_model2_1["leakage_who"];
                $leakage_specific_model2_1 = $row_model2_1["leakage_specific"];
                $criminal_sentence_model2_1 = $row_model2_1["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error2.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model2_1);


    //Model 2 - 2
    if($stmt_sql_model2_2 = mysqli_prepare($link, $sql_model2_2)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model2_2, "iss", $param_id_model2_2, $model_type_model2_2, $observation_model2_2);
        
        // Set parameters
        $param_id_model2_2 = trim($_GET["id"]);
        $model_type_model2_2 = "Model 2";
        $observation_model2_2 = "2";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model2_2)){
            $result_model2_2 = mysqli_stmt_get_result($stmt_sql_model2_2);
    
            if(mysqli_num_rows($result_model2_2) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model2_2 = mysqli_fetch_array($result_model2_2, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $model_type_model2_2 = $row_model2_2["model_type"];
                $observation_no_model2_2 = $row_model2_2["observation_no"];
                $percentage_model2_2 = $row_model2_2["percentage"];

                $state_code_model2_2 = $row_model2_2["state_code"];
                $region_model2_2 = $row_model2_2["region"];
                $urban_model2_2 = $row_model2_2["urban"];
                $age_model2_2 = $row_model2_2["age"];
                $race_model2_2 = $row_model2_2["race"];
                $religion_model2_2 = $row_model2_2["religion"];
                $education_model2_2 = $row_model2_2["education"];
                $school_perf_model2_2 = $row_model2_2["school_perf"];
                $birth_order_model2_2 = $row_model2_2["birth_order"];
                $no_siblings_model2_2 = $row_model2_2["no_siblings"];
                $relationship_model2_2 = $row_model2_2["relationship"];
                $children_model2_2 = $row_model2_2["children"];
                $employment_status_model2_2 = $row_model2_2["employment_status"];
                $employment_type_model2_2 = $row_model2_2["employment_type"];
                $military_branch_model2_2 = $row_model2_2["military_branch"];
                $community_involvement_model2_2 = $row_model2_2["community_involvement"];
                $part_1_crimes_model2_2 = $row_model2_2["part_1_crimes"];
                $part_2_crimes_model2_2 = $row_model2_2["part_2_crimes"];
                $domestic_abuse_spec_model2_2 = $row_model2_2["domestic_abuse_spec"];
                $childhood_socioeconomic_model2_2 = $row_model2_2["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model2_2 = $row_model2_2["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model2_2 = $row_model2_2["timeframe_signs_crisis"];
                $substance_use_and_abuse_model2_2 = $row_model2_2["substance_use_and_abuse"];
                $known_prejudices_model2_2 = $row_model2_2["known_prejudices"];
                $leakage_how_model2_2 = $row_model2_2["leakage_how"];
                $leakage_who_model2_2 = $row_model2_2["leakage_who"];
                $leakage_specific_model2_2 = $row_model2_2["leakage_specific"];
                $criminal_sentence_model2_2 = $row_model2_2["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error3.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model2_2);


    //Model 2 - 3
    if($stmt_sql_model2_3 = mysqli_prepare($link, $sql_model2_3)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model2_3, "iss", $param_id_model2_3, $model_type_model2_3, $observation_model2_3);
        
        // Set parameters
        $param_id_model2_3 = trim($_GET["id"]);
        $model_type_model2_3 = "Model 2";
        $observation_model2_3 = "3";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model2_3)){
            $result_model2_3 = mysqli_stmt_get_result($stmt_sql_model2_3);
    
            if(mysqli_num_rows($result_model2_3) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model2_3 = mysqli_fetch_array($result_model2_3, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $model_type_model2_3 = $row_model2_3["model_type"];
                $observation_no_model2_3 = $row_model2_3["observation_no"];
                $percentage_model2_3 = $row_model2_3["percentage"];

                $state_code_model2_3 = $row_model2_3["state_code"];
                $region_model2_3 = $row_model2_3["region"];
                $urban_model2_3 = $row_model2_3["urban"];
                $age_model2_3 = $row_model2_3["age"];
                $race_model2_3 = $row_model2_3["race"];
                $religion_model2_3 = $row_model2_3["religion"];
                $education_model2_3 = $row_model2_3["education"];
                $school_perf_model2_3 = $row_model2_3["school_perf"];
                $birth_order_model2_3 = $row_model2_3["birth_order"];
                $no_siblings_model2_3 = $row_model2_3["no_siblings"];
                $relationship_model2_3 = $row_model2_3["relationship"];
                $children_model2_3 = $row_model2_3["children"];
                $employment_status_model2_3 = $row_model2_3["employment_status"];
                $employment_type_model2_3 = $row_model2_3["employment_type"];
                $military_branch_model2_3 = $row_model2_3["military_branch"];
                $community_involvement_model2_3 = $row_model2_3["community_involvement"];
                $part_1_crimes_model2_3 = $row_model2_3["part_1_crimes"];
                $part_2_crimes_model2_3 = $row_model2_3["part_2_crimes"];
                $domestic_abuse_spec_model2_3 = $row_model2_3["domestic_abuse_spec"];
                $childhood_socioeconomic_model2_3 = $row_model2_3["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model2_3 = $row_model2_3["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model2_3 = $row_model2_3["timeframe_signs_crisis"];
                $substance_use_and_abuse_model2_3 = $row_model2_3["substance_use_and_abuse"];
                $known_prejudices_model2_3 = $row_model2_3["known_prejudices"];
                $leakage_how_model2_3 = $row_model2_3["leakage_how"];
                $leakage_who_model2_3 = $row_model2_3["leakage_who"];
                $leakage_specific_model2_3 = $row_model2_3["leakage_specific"];
                $criminal_sentence_model2_3 = $row_model2_3["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error4.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model2_3);

    //Model 3 - 1
    if($stmt_sql_model3_1 = mysqli_prepare($link, $sql_model3_1)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model3_1, "iss", $param_id_model3_1, $model_type_model3_1, $observation_model3_1);
        
        // Set parameters
        $param_id_model3_1 = trim($_GET["id"]);
        $model_type_model3_1 = "Model 3";
        $observation_model3_1 = "1";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model3_1)){
            $result_model3_1 = mysqli_stmt_get_result($stmt_sql_model3_1);
    
            if(mysqli_num_rows($result_model3_1) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model3_1 = mysqli_fetch_array($result_model3_1, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $model_type_model3_1 = $row_model3_1["model_type"];
                $observation_no_model3_1 = $row_model3_1["observation_no"];
                $percentage_model3_1 = $row_model3_1["percentage"];

                $state_code_model3_1 = $row_model3_1["state_code"];
                $region_model3_1 = $row_model3_1["region"];
                $urban_model3_1 = $row_model3_1["urban"];
                $age_model3_1 = $row_model3_1["age"];
                $race_model3_1 = $row_model3_1["race"];
                $religion_model3_1 = $row_model3_1["religion"];
                $education_model3_1 = $row_model3_1["education"];
                $school_perf_model3_1 = $row_model3_1["school_perf"];
                $birth_order_model3_1 = $row_model3_1["birth_order"];
                $no_siblings_model3_1 = $row_model3_1["no_siblings"];
                $relationship_model3_1 = $row_model3_1["relationship"];
                $children_model3_1 = $row_model3_1["children"];
                $employment_status_model3_1 = $row_model3_1["employment_status"];
                $employment_type_model3_1 = $row_model3_1["employment_type"];
                $military_branch_model3_1 = $row_model3_1["military_branch"];
                $community_involvement_model3_1 = $row_model3_1["community_involvement"];
                $part_1_crimes_model3_1 = $row_model3_1["part_1_crimes"];
                $part_2_crimes_model3_1 = $row_model3_1["part_2_crimes"];
                $domestic_abuse_spec_model3_1 = $row_model3_1["domestic_abuse_spec"];
                $childhood_socioeconomic_model3_1 = $row_model3_1["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model3_1 = $row_model3_1["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model3_1 = $row_model3_1["timeframe_signs_crisis"];
                $substance_use_and_abuse_model3_1 = $row_model3_1["substance_use_and_abuse"];
                $known_prejudices_model3_1 = $row_model3_1["known_prejudices"];
                $leakage_how_model3_1 = $row_model3_1["leakage_how"];
                $leakage_who_model3_1 = $row_model3_1["leakage_who"];
                $leakage_specific_model3_1 = $row_model3_1["leakage_specific"];
                $criminal_sentence_model3_1 = $row_model3_1["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error4.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model3_1);


    //Model 3 - 2
    if($stmt_sql_model3_2 = mysqli_prepare($link, $sql_model3_2)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model3_2, "iss", $param_id_model3_2, $model_type_model3_2, $observation_model3_2);
        
        // Set parameters
        $param_id_model3_2 = trim($_GET["id"]);
        $model_type_model3_2 = "Model 3";
        $observation_model3_2 = "2";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model3_2)){
            $result_model3_2 = mysqli_stmt_get_result($stmt_sql_model3_2);
    
            if(mysqli_num_rows($result_model3_2) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model3_2 = mysqli_fetch_array($result_model3_2, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $model_type_model3_2 = $row_model3_2["model_type"];
                $observation_no_model3_2 = $row_model3_2["observation_no"];
                $percentage_model3_2 = $row_model3_2["percentage"];

                $state_code_model3_2 = $row_model3_2["state_code"];
                $region_model3_2 = $row_model3_2["region"];
                $urban_model3_2 = $row_model3_2["urban"];
                $age_model3_2 = $row_model3_2["age"];
                $race_model3_2 = $row_model3_2["race"];
                $religion_model3_2 = $row_model3_2["religion"];
                $education_model3_2 = $row_model3_2["education"];
                $school_perf_model3_2 = $row_model3_2["school_perf"];
                $birth_order_model3_2 = $row_model3_2["birth_order"];
                $no_siblings_model3_2 = $row_model3_2["no_siblings"];
                $relationship_model3_2 = $row_model3_2["relationship"];
                $children_model3_2 = $row_model3_2["children"];
                $employment_status_model3_2 = $row_model3_2["employment_status"];
                $employment_type_model3_2 = $row_model3_2["employment_type"];
                $military_branch_model3_2 = $row_model3_2["military_branch"];
                $community_involvement_model3_2 = $row_model3_2["community_involvement"];
                $part_1_crimes_model3_2 = $row_model3_2["part_1_crimes"];
                $part_2_crimes_model3_2 = $row_model3_2["part_2_crimes"];
                $domestic_abuse_spec_model3_2 = $row_model3_2["domestic_abuse_spec"];
                $childhood_socioeconomic_model3_2 = $row_model3_2["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model3_2 = $row_model3_2["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model3_2 = $row_model3_2["timeframe_signs_crisis"];
                $substance_use_and_abuse_model3_2 = $row_model3_2["substance_use_and_abuse"];
                $known_prejudices_model3_2 = $row_model3_2["known_prejudices"];
                $leakage_how_model3_2 = $row_model3_2["leakage_how"];
                $leakage_who_model3_2 = $row_model3_2["leakage_who"];
                $leakage_specific_model3_2 = $row_model3_2["leakage_specific"];
                $criminal_sentence_model3_2 = $row_model3_2["criminal_sentence"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error4.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model3_2);


    //Model 3 - 3
    if($stmt_sql_model3_3 = mysqli_prepare($link, $sql_model3_3)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt_sql_model3_3, "iss", $param_id_model3_3, $model_type_model3_3, $observation_model3_3);
        
        // Set parameters
        $param_id_model3_3 = trim($_GET["id"]);
        $model_type_model3_3 = "Model 3";
        $observation_model3_3 = "3";

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt_sql_model3_3)){
            $result_model3_3 = mysqli_stmt_get_result($stmt_sql_model3_3);
    
            if(mysqli_num_rows($result_model3_3) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row_model3_3 = mysqli_fetch_array($result_model3_3, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $model_type_model3_3 = $row_model3_3["model_type"];
                $observation_no_model3_3 = $row_model3_3["observation_no"];
                $percentage_model3_3 = $row_model3_3["percentage"];

                $state_code_model3_3 = $row_model3_3["state_code"];
                $region_model3_3 = $row_model3_3["region"];
                $urban_model3_3 = $row_model3_3["urban"];
                $age_model3_3 = $row_model3_3["age"];
                $race_model3_3 = $row_model3_3["race"];
                $religion_model3_3 = $row_model3_3["religion"];
                $education_model3_3 = $row_model3_3["education"];
                $school_perf_model3_3 = $row_model3_3["school_perf"];
                $birth_order_model3_3 = $row_model3_3["birth_order"];
                $no_siblings_model3_3 = $row_model3_3["no_siblings"];
                $relationship_model3_3 = $row_model3_3["relationship"];
                $children_model3_3 = $row_model3_3["children"];
                $employment_status_model3_3 = $row_model3_3["employment_status"];
                $employment_type_model3_3 = $row_model3_3["employment_type"];
                $military_branch_model3_3 = $row_model3_3["military_branch"];
                $community_involvement_model3_3 = $row_model3_3["community_involvement"];
                $part_1_crimes_model3_3 = $row_model3_3["part_1_crimes"];
                $part_2_crimes_model3_3 = $row_model3_3["part_2_crimes"];
                $domestic_abuse_spec_model3_3 = $row_model3_3["domestic_abuse_spec"];
                $childhood_socioeconomic_model3_3 = $row_model3_3["childhood_socioeconomic"];
                $recent_stressor_triggering_event_model3_3 = $row_model3_3["recent_stressor_triggering_event"];
                $timeframe_signs_crisis_model3_3 = $row_model3_3["timeframe_signs_crisis"];
                $substance_use_and_abuse_model3_3 = $row_model3_3["substance_use_and_abuse"];
                $known_prejudices_model3_3 = $row_model3_3["known_prejudices"];
                $leakage_how_model3_3 = $row_model3_3["leakage_how"];
                $leakage_who_model3_3 = $row_model3_3["leakage_who"];
                $leakage_specific_model3_3 = $row_model3_3["leakage_specific"];
                $criminal_sentence_model3_3 = $row_model3_3["criminal_sentence"];



            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error4.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt_sql_model3_3);

    // Close connection
    mysqli_close($link);

} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <title>Gun Violence</title>

    <!--web fonts-->
    <link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!--bootstrap styles-->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!--icon font-->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/dashlab-icon/dashlab-icon.css" rel="stylesheet">
    <link href="assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendor/weather-icons/css/weather-icons.min.css" rel="stylesheet">

    <!--top nav start-->
    <link href="assets/vendor/custom-nav/css/core-menu.css" rel="stylesheet">
    <link href="assets/vendor/custom-nav/css/responsive.css" rel="stylesheet">

    <!--jquery ui-->
    <link href="assets/vendor/jquery-ui/jquery-ui.min.css" rel="stylesheet">

    <!--iCheck-->
    <link href="assets/vendor/icheck/skins/all.css" rel="stylesheet">

    <!--jqery steps-->
    <link href="assets/vendor/jquery-steps/jquery.steps.css" rel="stylesheet">

    <!--select2-->
    <link href="assets/vendor/select2/css/select2.css" rel="stylesheet">

    <!--custom styles-->
    <link href="assets/css/main.css" rel="stylesheet">

    <!--data table-->
    <link href="assets/vendor/data-tables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/vendor/html5shiv.js"></script>
    <script src="assets/vendor/respond.min.js"></script>
    <![endif]-->
</head>

<body class="fixed-nav top-nav header-fixed">
<!--header start-->
<header class="app-header">
    <div class="container">
        <div class="row">
            
        </div>
    </div>
</header>
   <!--search modal start-->
<div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" class="form-control" placeholder="Search...">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
<!--search modal start-->
    <!--search modal start-->
    <!--header end-->

    <div class="app-body">
        
        <!--left sidebar start-->
        <div class="left-nav-wrap">
            <div class="left-sidebar">
                <nav class="sidebar-menu">
                    <ul id="nav-accordion">

                        <li class="sub-menu">
                            <a href="javascript:;"  class="active">
                                <i class=" icon-speech"></i>
                                <span>Forms</span>
                            </a>
                            <ul class="sub">
                                <li class="sub-menu">
                                    <a  href="form-wizard.html" class="active">Form Validation</a>
                                    
                                </li>
                            </ul>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </div>
        <!--left sidebar end-->
        
        <!--main content wrapper-->
        <div class="content-wrapper">

            <div class="container-fluid">

                <!--page title-->
                <div class="page-title mb-4 d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Gun Violence</h4>
                        <nav aria-label="breadcrumb" class="d-inline-block ">
                            <ol class="breadcrumb p-0">
                                <li class="breadcrumb-item"><a href="index.php">Add Entry</a></li>
                                <li class="breadcrumb-item"><a href="view.php">View All Entries</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><a href="#">View Result</a></li> 
                            </ol>
                        </nav>

                    </div>
                    <?php echo '<a href="read_use.php?id='. $row['id'] .'">'?><button type="button" style="float: right; padding: .4rem 1.5rem;" class="btn btn-primary form-pill">Go Back to User Input Details</button></a>
                </div>
                <!--/page title-->

                <!--Model 1 Results-->
                <div class="row">
                    <div class="col-xl-12 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title" style="text-align: center; font-size: 20px;">MODEL 1 - LOF RESULTS </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php echo $model_1_result; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!--Model 2 Results-->
                <div class="row">
                    <div class="col-xl-12 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title" style="text-align: center; font-size: 20px;">MODEL 2 - KMEANS RESULTS</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">
                                        <?php if($percentage_model2_1 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model2_1; ?>% 
                                    <?php
                                    }
                                    ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 1 </th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model2_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model2_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model2_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model2_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model2_1; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model2_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model2_1; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">
                                        <?php if($percentage_model2_2 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model2_2; ?>% 
                                    <?php
                                    }
                                    ?>  
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 2 </th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model2_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model2_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model2_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model2_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model2_2; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model2_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model2_2; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">
                                        <?php if($percentage_model2_3 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model2_3; ?>% 
                                    <?php
                                    }
                                    ?> 
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 3</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model2_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model2_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model2_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model2_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model2_3; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model2_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model2_3; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Model 3 Results-->
                <div class="row">
                    <div class="col-xl-12 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title" style="text-align: center; font-size: 20px;">MODEL 3 - CUSTOM  RESULTS</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">
                                        <?php if($percentage_model3_1 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model3_1; ?>% 
                                    <?php
                                    }
                                    ?>   
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 1 </th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model3_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model3_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model3_1; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model3_1; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model3_1; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model3_1){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model3_1; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">
                                        <?php if($percentage_model3_2 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model3_2; ?>% 
                                    <?php
                                    }
                                    ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 2</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model3_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model3_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model3_2; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model3_2; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model3_2; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model3_2){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model3_2; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">

                                        <?php if($percentage_model3_3 < 50){
                                            echo "This person is a not a potential mass shooter";
                                        } else {
                                            ?>
                                            Rating = <?php echo $percentage_model3_3; ?>% 
                                    <?php
                                    }
                                    ?>
                                        </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" >Questions</th>
                                        <th scope="col" >User Data Input</th>
                                        <th scope="col" >Result 3</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        if ($state_code == $state_code_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">State Code</th>
                                        <td><?php echo $state_code; ?></td>
                                        <td><?php echo $state_code_model3_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($region == $region_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Region</th>
                                        <td><?php echo $region; ?></td>
                                        <td><?php echo $region_model3_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($age == $age_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Age</th>
                                        <td><?php echo $age; ?></td>
                                        <td><?php echo $age_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($race == $race_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Race</th>
                                        <td><?php echo $race; ?></td>
                                        <td><?php echo $race_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($religion == $religion_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Religion</th>
                                        <td><?php echo $religion; ?></td>
                                        <td><?php echo $religion_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($education == $education_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Education</th>
                                        <td><?php echo $education; ?></td>
                                        <td><?php echo $education_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($school_perf == $school_perf_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">School Performance</th>
                                        <td><?php echo $school_perf; ?></td>
                                        <td><?php echo $school_perf_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($birth_order == $birth_order_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Birth Order</th>
                                        <td><?php echo $birth_order; ?></td>
                                        <td><?php echo $birth_order_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($no_siblings == $no_siblings_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Number of Siblings</th>
                                        <td><?php echo $no_siblings; ?></td>
                                        <td><?php echo $no_siblings_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($relationship == $relationship_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Relationship Status</th>
                                        <td><?php echo $relationship; ?></td>
                                        <td><?php echo $relationship_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($children == $children_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Children</th>
                                        <td><?php echo $children; ?></td>
                                        <td><?php echo $children_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_status == $employment_status_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Employment Status</th>
                                        <td><?php echo $employment_status; ?></td>
                                        <td><?php echo $employment_status_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($employment_type == $employment_type_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Employment Type</th>
                                        <td><?php echo $employment_type; ?></td>
                                        <td><?php echo $employment_type_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($military_branch == $military_branch_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Military Branch</th>
                                        <td><?php echo $military_branch; ?></td>
                                        <td><?php echo $military_branch_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($community_involvement == $community_involvement_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Community Involvement</th>
                                        <td><?php echo $community_involvement; ?></td>
                                        <td><?php echo $community_involvement_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_1_crimes == $part_1_crimes_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Part 1 Crimes</th>
                                        <td><?php echo $part_1_crimes; ?></td>
                                        <td><?php echo $part_1_crimes_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($part_2_crimes == $part_2_crimes_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Part 2 Crimes</th>
                                        <td><?php echo $part_2_crimes; ?></td>
                                        <td><?php echo $part_2_crimes_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($domestic_abuse_spec == $domestic_abuse_spec_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Domestic Abuse Specified</th>
                                        <td><?php echo $domestic_abuse_spec; ?></td>
                                        <td><?php echo $domestic_abuse_spec_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($childhood_socioeconomic == $childhood_socioeconomic_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Childhood SES</th>
                                        <td><?php echo $childhood_socioeconomic; ?></td>
                                        <td><?php echo $childhood_socioeconomic_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($recent_stressor_triggering_event == $recent_stressor_triggering_event_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Recent or Ongoing Stressor</th>
                                        <td><?php echo $recent_stressor_triggering_event; ?></td>
                                        <td><?php echo $recent_stressor_triggering_event_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($timeframe_signs_crisis == $timeframe_signs_crisis_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Timeframe of when signs of Crisis Began</th>
                                        <td><?php echo $timeframe_signs_crisis; ?></td>
                                        <td><?php echo $timeframe_signs_crisis_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($substance_use_and_abuse == $substance_use_and_abuse_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Substance Use and Abuse</th>
                                        <td><?php echo $substance_use_and_abuse; ?></td>
                                        <td><?php echo $substance_use_and_abuse_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($known_prejudices == $known_prejudices_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">known Prejudices</th>
                                        <td><?php echo $known_prejudices; ?></td>
                                        <td><?php echo $known_prejudices_model3_3; ?></td>
                                    </tr>

                                    <?php
                                        if ($leakage_how == $leakage_how_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - How?</th>
                                        <td><?php echo $leakage_how; ?></td>
                                        <td><?php echo $leakage_how_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_who == $leakage_who_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Who?</th>
                                        <td><?php echo $leakage_who; ?></td>
                                        <td><?php echo $leakage_who_model3_3; ?></td>
                                    </tr>
                                    
                                    <?php
                                        if ($leakage_specific == $leakage_specific_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr>';
                                        }
                                    ?>
                                        <th scope="row">Leakage - Specific?</th>
                                        <td><?php echo $leakage_specific; ?></td>
                                        <td><?php echo $leakage_specific_model3_3; ?></td>
                                    
                                    <?php
                                        if ($criminal_sentence == $criminal_sentence_model3_3){
                                            echo '<tr class="table-success">';
                                        }else {
                                            echo '<tr class="table-active">';
                                        }
                                    ?>
                                        <th scope="row">Criminal Record</th>
                                        <td><?php echo $criminal_sentence; ?></td>
                                        <td><?php echo $criminal_sentence_model3_3; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                

            </div>

            <!--footer-->
            <footer class="sticky-footer">
                <div class="container">
                    <div class="text-center">
                        <small>Copyright &copy; Gun Violence 2022</small>
                    </div>
                </div>
            </footer>
            <!--/footer-->
        </div>
        <!--/main content wrapper-->

        
    </div>
    <!--basic scripts-->
    <script type="text/javascript">

         $('#immigrant').select2({
                placeholder: "Select Immigrant"  
            });
    </script>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/vendor/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/vendor/icheck/skins/icheck.min.js"></script>
    <script src="assets/vendor/jquery.nicescroll.min.js"></script>
    
    <!--datatables-->
    <script src="assets/vendor/data-tables/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/data-tables/dataTables.bootstrap4.min.js"></script>
    <!--init datatable-->
    <script src="assets/vendor/js-init/init-datatable.js"></script>


    <!--[if lt IE 9]>
    <script src="assets/vendor/modernizr.js"></script>
    <![endif]-->

    <!--basic scripts initialization-->
    <script src="assets/js/scripts.js"></script>
</body>
</html>

