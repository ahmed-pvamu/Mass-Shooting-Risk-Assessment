<?php
/**
$json = '
{
    "type": "donut",
    "name": "Cake",
    "toppings": [
        { "id": "5002", "type": "Glazed" },
        { "id": "5006", "type": "Chocolate with Sprinkles" },
        { "id": "5004", "type": "Maple" }
    ]
}';

$yummy = json_decode($json);

echo $yummy->toppings[2]->id; //5004
**/



        


$json_test = '{
    "prediction": [
        [
            2.0,
            23333.343,
            0.0,
            24.0,
            0.0,
            1.0,
            4.0,
            2.0,
            1.0,
            1.0,
            0.0,
            0.0,
            0.0,
            1.0,
            999.0,
            1.0,
            0.0,
            0.0,
            0.0,
            1.0,
            3.0,
            2.0,
            3.0,
            0.0,
            1.0,
            7.0,
            1.0,
            2.0,
            0.71
        ],
        [
            38.0,
            2.0,
            0.0,
            46.0,
            0.0,
            1.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            1.0,
            0.0,
            999.0,
            0.0,
            0.0,
            0.0,
            0.0,
            999.0,
            0.0,
            3.0,
            0.0,
            7.0,
            5.0,
            10.0,
            0.0,
            999.0,
            0.83
        ],
        [
            9.0,
            0.0,
            1.0,
            19.0,
            0.0,
            999.0,
            0.0,
            0.0,
            1.0,
            1.0,
            0.0,
            0.0,
            1.0,
            0.0,
            999.0,
            3.0,
            0.0,
            10.0,
            5.0,
            2.0,
            4.0,
            2.0,
            3.0,
            8.0,
            5.0,
            10.0,
            19899.0,
            9919.0,
            0.84
        ]
    ]
}';

$yummy_test = json_decode($json_test);

//var_dump($yummy_test->prediction[0][1]); 

$from_api = (int)$yummy_test->prediction[0][1];

$csv = array_map('str_getcsv', file('render.csv'));


//print_r($csv);
echo '<pre>';
print_r($csv);
echo '</pre>';


//echo $csv[0][$from_api];

if ( ! isset($csv[0][$from_api - 1])) {
    echo "It does not";
} else {
    echo "It exits well";
}

//$var = 100 * $yummy_test->prediction[0][28];

//echo $var;




?>