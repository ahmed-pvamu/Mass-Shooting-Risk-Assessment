<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <title>Gun Violence</title>

    <!--web fonts-->
    <link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!--bootstrap styles-->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!--icon font-->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/dashlab-icon/dashlab-icon.css" rel="stylesheet">
    <link href="assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendor/weather-icons/css/weather-icons.min.css" rel="stylesheet">

    <!--top nav start-->
    <link href="assets/vendor/custom-nav/css/core-menu.css" rel="stylesheet">
    <link href="assets/vendor/custom-nav/css/responsive.css" rel="stylesheet">

    <!--jquery ui-->
    <link href="assets/vendor/jquery-ui/jquery-ui.min.css" rel="stylesheet">

    <!--iCheck-->
    <link href="assets/vendor/icheck/skins/all.css" rel="stylesheet">

    <!--jqery steps-->
    <link href="assets/vendor/jquery-steps/jquery.steps.css" rel="stylesheet">

    <!--select2-->
    <link href="assets/vendor/select2/css/select2.css" rel="stylesheet">

    <!--custom styles-->
    <link href="assets/css/main.css" rel="stylesheet">

    <!--data table-->
    <link href="assets/vendor/data-tables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/vendor/html5shiv.js"></script>
    <script src="assets/vendor/respond.min.js"></script>
    <![endif]-->
</head>

<body class="fixed-nav top-nav header-fixed">
<!--header start-->
<header class="app-header">
    <div class="container">
        <div class="row">
            
        </div>
    </div>
</header>
   <!--search modal start-->
<div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" class="form-control" placeholder="Search...">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
<!--search modal start-->
    <!--search modal start-->
    <!--header end-->

    <div class="app-body">
        
        <!--left sidebar start-->
        <div class="left-nav-wrap">
            <div class="left-sidebar">
                <nav class="sidebar-menu">
                    <ul id="nav-accordion">

                        <li class="sub-menu">
                            <a href="javascript:;"  class="active">
                                <i class=" icon-speech"></i>
                                <span>Forms</span>
                            </a>
                            <ul class="sub">
                                <li class="sub-menu">
                                    <a  href="form-wizard.html" class="active">Form Validation</a>
                                    
                                </li>
                            </ul>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </div>
        <!--left sidebar end-->
        
        <!--main content wrapper-->
        <div class="content-wrapper">

            <div class="container-fluid">

                <!--page title-->
                <div class="page-title mb-4 d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Gun Violence</h4>
                        <nav aria-label="breadcrumb" class="d-inline-block ">
                            <ol class="breadcrumb p-0">
                                <li class="breadcrumb-item"><a href="index.php">Add Entry</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><a href="view.php">View All Entries</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--/page title-->
                
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card card-shadow mb-4">
                            <div class="card-header border-0">
                                <div class="custom-title-wrap bar-primary">
                                    <div class="custom-title">Data</div>
                                </div>
                            </div>
                            <div class="card-body- pt-3 pb-4">
                                <div class="table-responsive">
                                    <table id="data_table" class="table table-bordered table-striped" cellspacing="0">
                                        <thead>
                                        <tr>
                                            <th>State Code</th>
                                            <th>Region</th>
                                            <th>Urban</th>
                                            <th>Age</th>
                                            <th>Religion</th>
                                            <th>Race</th>
                                            <th width="10%">View More Details</th>
                                            <!--<th width="10%">View Result</th>-->
                                        </tr>
                                        </thead>
                                        <tfoot>
                                        <tr>
                                            <th>State Code</th>
                                            <th>Region</th>
                                            <th>Urban</th>
                                            <th>Age</th>
                                            <th>Religion</th>
                                            <th>Race</th>
                                            <th width="10%">View More Details</th>
                                            <!--<th width="10%">View Result</th>-->
                                        </tr>
                                        </tfoot>
                                        <tbody>
                    <?php
                    // Include config file
                    include "db_connection.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM entry_data";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_array($result)){
                                ?>
                                        <tr>
                                            <td><?php echo $row['state_code'] ?></td>
                                            <td><?php echo $row['region'] ?></td>
                                            <td><?php echo $row['urban'] ?></td>
                                            <td><?php echo $row['age'] ?></td>
                                            <td><?php echo $row['religion'] ?></td>
                                            <td><?php echo $row['race'] ?></td>
                                            <td><?php echo '<a href="read_use.php?id='. $row['id'] .'">'?><button type="button" style="float: right; padding: .4rem 1.5rem;" class="btn btn-primary form-pill">More Details</button></a> </td>

                                            <!--<td><?php //echo '<a href="result.php?id='. $row['id'] .'">'?><button type="button" style="float: right; padding: .4rem 1.5rem;" class="btn btn-success form-pill">View Results</button></a></td>-->
                                        </tr>
                                <?php 
                                    }
                                    mysqli_free_result($result);
                                }
                            }
                            mysqli_close($link);
                                ?>        
                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                

            </div>

            <!--footer-->
            <footer class="sticky-footer">
                <div class="container">
                    <div class="text-center">
                        <small>Copyright &copy; Gun Violence 2022</small>
                    </div>
                </div>
            </footer>
            <!--/footer-->
        </div>
        <!--/main content wrapper-->

        
    </div>
    <!--basic scripts-->
    <script type="text/javascript">

         $('#immigrant').select2({
                placeholder: "Select Immigrant"  
            });
    </script>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/vendor/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/vendor/icheck/skins/icheck.min.js"></script>
    <script src="assets/vendor/jquery.nicescroll.min.js"></script>
    
    <!--datatables-->
    <script src="assets/vendor/data-tables/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/data-tables/dataTables.bootstrap4.min.js"></script>
    <!--init datatable-->
    <script src="assets/vendor/js-init/init-datatable.js"></script>


    <!--[if lt IE 9]>
    <script src="assets/vendor/modernizr.js"></script>
    <![endif]-->

    <!--basic scripts initialization-->
    <script src="assets/js/scripts.js"></script>
</body>
</html>

