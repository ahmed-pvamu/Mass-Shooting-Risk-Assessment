<?php

include "db_connection.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){ 

	//Confirmed Mass Shooter
	$confirmed_mass_shooter = $_POST["confirmed_mass_shooter"];

	//State Code
	$state_code = $_POST["state_code"];
	[$state_code_no, $state_code_text] = explode('|', $state_code);

	//Region
	$region = $_POST["region"];
	[$region_no, $region_text] = explode('|', $region);

	//Urban
	$urban = $_POST["urban"];
	[$urban_no, $urban_text] = explode('|', $urban);

	//Age
	$age_no = $_POST["age"];
	$age_text = $age_no;
	//[$age_no, $age_text] = explode('|', $age);

	//Religion
	$religion = $_POST["religion"];
	[$religion_no, $religion_text] = explode('|', $religion);

	//Race
	$race = $_POST["race"];
	[$race_no, $race_text] = explode('|', $race);

	//Education
	$education = $_POST["education"];
	[$education_no, $education_text] = explode('|', $education);

	//Birth Order
	$birth_order = $_POST["birth_order"];
	[$birth_order_no, $birth_order_text] = explode('|', $birth_order);

	//School Perf
	$school_perf = $_POST["school_perf"];
	[$school_perf_no, $school_perf_text] = explode('|', $school_perf);

	//Relationship
	$relationship = $_POST["relationship"];
	[$relationship_no, $relationship_text] = explode('|', $relationship);

	//no of siblings
	$no_siblings_no = $_POST["no_siblings"];
	$no_siblings_text = $no_siblings_no;
	//[$no_siblings_no, $no_siblings_text] = explode('|', $no_siblings);

	//Employment Status
	$employment_status = $_POST["employment_status"];
	[$employment_status_no, $employment_status_text] = explode('|', $employment_status);

	//Children
	$children = $_POST["children"];
	[$children_no, $children_text] = explode('|', $children);

	//Community Involvement
	$community_involvement = $_POST["community_involvement"];
	[$community_involvement_no, $community_involvement_text] = explode('|', $community_involvement);

	//Employment type
	$employment_type = $_POST["employment_type"];
	[$employment_type_no, $employment_type_text] = explode('|', $employment_type);

	//Military Branch
	$military_branch = $_POST["military_branch"];
	[$military_branch_no, $military_branch_text] = explode('|', $military_branch);

	//Part 1 CRimes
	$part_1_crimes = $_POST["part_1_crimes"];

	$part_1_crimes_no = 0;
	$part_1_crimes_text = '';

	foreach ($part_1_crimes as $part_1_crime){
		[$part_1_crimes_no_a, $part_1_crimes_text_a] = explode('|', $part_1_crime);

		$part_1_crimes_no += $part_1_crimes_no_a;
		$part_1_crimes_text .= $part_1_crimes_text_a . ', ';
	}

	//Part 2 Crimes
	$part_2_crimes = $_POST["part_2_crimes"];

	$part_2_crimes_no = 0;
	$part_2_crimes_text = '';

	foreach ($part_2_crimes as $part_2_crime){
		[$part_2_crimes_no_a, $part_2_crimes_text_a] = explode('|', $part_2_crime);

		$part_2_crimes_no += $part_2_crimes_no_a;
		$part_2_crimes_text .= $part_2_crimes_text_a . ', ';
	}

	//Domestic Abuse Spec
	$domestic_abuse_spec = $_POST["domestic_abuse_spec"];
	[$domestic_abuse_spec_no, $domestic_abuse_spec_text] = explode('|', $domestic_abuse_spec);

	//Childhood SES
	$childhood_socioeconomic = $_POST["childhood_socioeconomic"];
	[$childhood_socioeconomic_no, $childhood_socioeconomic_text] = explode('|', $childhood_socioeconomic);

	//Timefram Signs CRisis
	$timeframe_signs_crisis = $_POST["timeframe_signs_crisis"];
	[$timeframe_signs_crisis_no, $timeframe_signs_crisis_text] = explode('|', $timeframe_signs_crisis);


	//Rcent Stresstor
	$recent_stressor_triggering_events = $_POST["recent_stressor_triggering_event"];

	$recent_stressor_triggering_event_no = 0;
	$recent_stressor_triggering_event_text = '';

	foreach ($recent_stressor_triggering_events as $recent_stressor_triggering_event){
		[$recent_stressor_triggering_event_no_a, $recent_stressor_triggering_event_text_a] = explode('|', $recent_stressor_triggering_event);

		$recent_stressor_triggering_event_no += $recent_stressor_triggering_event_no_a;
		$recent_stressor_triggering_event_text .= $recent_stressor_triggering_event_text_a . ', ';
	}


	//Known Prejudices
	$known_prejudices = $_POST["known_prejudices"];

	$known_prejudices_no = 0;
	$known_prejudices_text = '';

	foreach ($known_prejudices as $known_prejudice){
		[$known_prejudices_no_a, $known_prejudices_text_a] = explode('|', $known_prejudice);

		$known_prejudices_no += $known_prejudices_no_a;
		$known_prejudices_text .= $known_prejudices_text_a . ', ';
	}

	//Substance Use and Abuse
	$substance_use_and_abuses = $_POST["substance_use_and_abuse"];

	$substance_use_and_abuse_no = 0;
	$substance_use_and_abuse_text = '';

	foreach ($substance_use_and_abuses as $substance_use_and_abuse){
		[$substance_use_and_abuse_no_a, $substance_use_and_abuse_text_a] = explode('|', $substance_use_and_abuse);

		$substance_use_and_abuse_no += $substance_use_and_abuse_no_a;
		$substance_use_and_abuse_text .= $substance_use_and_abuse_text_a . ', ';
	}

	//Leakage How
	$leakage_hows = $_POST["leakage_how"];

	$leakage_how_no = 0;
	$leakage_how_text = '';

	foreach ($leakage_hows as $leakage_how){
		[$leakage_how_no_a, $leakage_how_text_a] = explode('|', $leakage_how);

		$leakage_how_no += $leakage_how_no_a;
		$leakage_how_text .= $leakage_how_text_a . ', ';
	}

	//Leakage Who
	$leakage_whos = $_POST["leakage_who"];

	$leakage_who_no = 0;
	$leakage_who_text = '';

	foreach ($leakage_whos as $leakage_who){
		[$leakage_who_no_a, $leakage_who_text_a] = explode('|', $leakage_who);

		$leakage_who_no += $leakage_who_no_a;
		$leakage_who_text .= $leakage_who_text_a . ', ';
	}


	//Leakage Specific
	$leakage_specific = $_POST["leakage_specific"];
	[$leakage_specific_no, $leakage_specific_text] = explode('|', $leakage_specific);


	//Criminal Sentence
	$criminal_sentence = $_POST["criminal_sentence"];
	[$criminal_sentence_no, $criminal_sentence_text] = explode('|', $criminal_sentence);


	//******************* Pass Records to API in numbers *********************
	$new_entry = array(
		$state_code_no,
		$region_no,
		$urban_no,
		$age_no,
		$race_no,
		$religion_no,
		$education_no,
		$school_perf_no,
		$birth_order_no,
		$no_siblings_no,
		$relationship_no,
		$children_no,
		$employment_status_no,
		$employment_type_no,
		$military_branch_no,
		$community_involvement_no,
		$part_1_crimes_no,
		$part_2_crimes_no,
		$domestic_abuse_spec_no,
		$childhood_socioeconomic_no,
		$recent_stressor_triggering_event_no,
		$timeframe_signs_crisis_no,
		$substance_use_and_abuse_no,
		$known_prejudices_no,
		$leakage_how_no,
		$leakage_who_no,
		$leakage_specific_no,
		$criminal_sentence_no
	);

	$new_entry_data = implode(", ", $new_entry);

	$new_entry_convert = json_decode(json_encode('[[[' . $new_entry_data . ']]]', true));

	$data = '{'.'"'.'data'.'"'.': '.$new_entry_convert.'}';

	//echo $data;
	//exit;

	/*************************************************** MODEL 1 API **********************************************/
	$curl = curl_init();

	curl_setopt($curl, CURLOPT_URL, "http://127.0.0.1:5000/lof");

	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($curl, CURLOPT_POST, true);

	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

	//curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');

	curl_setopt($curl, CURLINFO_HEADER_OUT, true);
 
	curl_setopt($curl, CURLOPT_HTTPHEADER, [
	  'X-RapidAPI-Host: https://127.0.0.1:5000/lof',
	  //'X-RapidAPI-Key: 7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
	  'Content-Type: application/json'
	]);
	
	$model_1_result = curl_exec($curl);

	//echo $model_1_result;
	//exit;

	//$model_1_result = [1];

	if ($model_1_result = 1){
			$model_1_result_text = "This is likely to be a Shooter";
	} else {
		$model_1_result_text = "Not a Shooter";
	}

	curl_close($curl);


			/************************* Insert User Input from Front End to DB - And - Include Model 1 text result******************************/ 

			$sql = "INSERT INTO entry_data (confirmed_mass_shooter, model_1_result, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			if($stmt = mysqli_prepare($link, $sql)){

	 			mysqli_stmt_bind_param($stmt, "ssssssssssssssssssssssssssssss", $confirmed_mass_shooter, $model_1_result_b, $state_code_b, $region_b, $urban_b, $age_b, $religion_b, $race_b, $education_b, $birth_order_b, $relationship_b, $school_perf_b, $no_siblings_b, $employment_status_b, $children_b, $community_involvement_b, $employment_type_b, $military_branch_b, $part_1_crimes_b, $part_2_crimes_b, $domestic_abuse_spec_b, $childhood_socioeconomic_b, $timeframe_signs_crisis_b, $recent_stressor_triggering_event_b, $known_prejudices_b, $substance_use_and_abuse_b, $leakage_how_b, $leakage_who_b, $leakage_specific_b, $criminal_sentence_b);

	 				$confirmed_mass_shooter = $confirmed_mass_shooter;
	 				$model_1_result_b = $model_1_result_text;
					$state_code_b = $state_code_text;
					$region_b = $region_text;
					$urban_b = $urban_text;
					$age_b = $age_text;
					$religion_b = $religion_text;
					$race_b = $race_text;
					$education_b = $education_text;
					$birth_order_b = $birth_order_text;
					$relationship_b = $relationship_text;
					$school_perf_b = $school_perf_text;
					$no_siblings_b = $no_siblings_text;
					$employment_status_b = $employment_status_text;
					$children_b = $children_text;
					$community_involvement_b = $community_involvement_text;
					$employment_type_b = $employment_type_text;
					$military_branch_b = $military_branch_text;
					$part_1_crimes_b = $part_1_crimes_text;
					$part_2_crimes_b = $part_2_crimes_text;
					$domestic_abuse_spec_b = $domestic_abuse_spec_text;
					$childhood_socioeconomic_b = $childhood_socioeconomic_text;
					$timeframe_signs_crisis_b = $timeframe_signs_crisis_text;
					$recent_stressor_triggering_event_b = $recent_stressor_triggering_event_text;
					$known_prejudices_b = $known_prejudices_text;
					$substance_use_and_abuse_b = $substance_use_and_abuse_text;
					$leakage_how_b = $leakage_how_text;
					$leakage_who_b = $leakage_who_text;
					$leakage_specific_b = $leakage_specific_text;
					$criminal_sentence_b = $criminal_sentence_text;

			}

			mysqli_stmt_execute($stmt);

			$parent_id = mysqli_insert_id($link);

   			// Close statement
	 		mysqli_stmt_close($stmt);
    
    		// Close connection
    		//mysqli_close($link);
         

			/************************* End of Insert User Input from Front End to DB - And - Include Model 1 text result******************************/ 
	/******************************************************* END OF MODEL 1 API *******************************************/

		if ($_POST["confirmed_mass_shooter"] == 'Yes'){

			/************************* Insert User Input from Front End to DB - And - Include Model 1 text result******************************/ 

			$sql_train = "INSERT INTO entry_data_train (parent_id, confirmed_mass_shooter, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence, retrained) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			if($stmt_train = mysqli_prepare($link, $sql_train)){

	 			mysqli_stmt_bind_param($stmt_train, "sssssssssssssssssssssssssssssss", $parent_id_train, $confirmed_mass_shooter_train, $state_code_train, $region_train, $urban_train, $age_train, $religion_train, $race_train, $education_train, $birth_order_train, $relationship_train, $school_perf_train, $no_siblings_train, $employment_status_train, $children_train, $community_involvement_train, $employment_type_train, $military_branch_train, $part_1_crimes_train, $part_2_crimes_train, $domestic_abuse_spec_train, $childhood_socioeconomic_train, $timeframe_signs_crisis_train, $recent_stressor_triggering_event_train, $known_prejudices_train, $substance_use_and_abuse_train, $leakage_how_train, $leakage_who_train, $leakage_specific_train, $criminal_sentence_train, $retrained);

	 				$parent_id_train = $parent_id;
	 				$confirmed_mass_shooter_train = $confirmed_mass_shooter;
					$state_code_train = $state_code_no;
					$region_train = $region_no;
					$urban_train = $urban_no;
					$age_train = $age_no;
					$religion_train = $religion_no;
					$race_train = $race_no;
					$education_train = $education_no;
					$birth_order_train = $birth_order_no;
					$relationship_train = $relationship_no;
					$school_perf_train = $school_perf_no;
					$no_siblings_train = $no_siblings_no;
					$employment_status_train = $employment_status_no;
					$children_train = $children_no;
					$community_involvement_train = $community_involvement_no;
					$employment_type_train = $employment_type_no;
					$military_branch_train = $military_branch_no;
					$part_1_crimes_train = $part_1_crimes_no;
					$part_2_crimes_train = $part_2_crimes_no;
					$domestic_abuse_spec_train = $domestic_abuse_spec_no;
					$childhood_socioeconomic_train = $childhood_socioeconomic_no;
					$timeframe_signs_crisis_train = $timeframe_signs_crisis_no;
					$recent_stressor_triggering_event_train = $recent_stressor_triggering_event_no;
					$known_prejudices_train = $known_prejudices_no;
					$substance_use_and_abuse_train = $substance_use_and_abuse_no;
					$leakage_how_train = $leakage_how_no;
					$leakage_who_train = $leakage_who_no;
					$leakage_specific_train = $leakage_specific_no;
					$criminal_sentence_train = $criminal_sentence_no;
					$retrained = "no";

			}

			if(mysqli_stmt_execute($stmt_train))
				{
					header("location: read_use.php?id=".$parent_id);
				} else {
					echo "Oops! Something went wrong. Please try again later.";
				}

			

   			// Close statement
	 		mysqli_stmt_close($stmt_train);

		 	} else {


			/******************************************************* MODEL 2 API ********************************************/
			$new_entry_convert_model23 = json_decode(json_encode('[[' . $new_entry_data . ']]', true));

			$data_model23 = '{'.'"'.'data'.'"'.': '.$new_entry_convert_model23.'}';


			$curl_2 = curl_init();

			curl_setopt($curl_2, CURLOPT_URL, "http://127.0.0.1:5000/kmeansModel");

			curl_setopt($curl_2, CURLOPT_RETURNTRANSFER, true);

			curl_setopt($curl_2, CURLOPT_POST, true);

			curl_setopt($curl_2, CURLOPT_POSTFIELDS, $data_model23);

			//curl_setopt($curl_2, CURLOPT_CUSTOMREQUEST, 'PUT');

			curl_setopt($curl_2, CURLINFO_HEADER_OUT, true);
		 
			curl_setopt($curl_2, CURLOPT_HTTPHEADER, [
			  'X-RapidAPI-Host: https://127.0.0.1:5000/kmeansModel',
			  //'X-RapidAPI-Key: 7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
			  'Content-Type: application/json'
			]);


			$model_2 = curl_exec($curl_2);

			$model_2_decoded = json_decode($model_2);

			//echo '<pre>';
			//print_r($model_2_decoded);
			//echo '</pre>';

			//exit;

			curl_close($curl_2);

			/**$model_2 = '{ "prediction": [
		        [31.0, 3.0, 0.0, 4.0, 0.0, 1.0, 4.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 999.0, 1.0, 0.0, 0.0, 0.0, 1.0, 3.0, 2.0, 3.0, 0.0, 1.0, 7.0, 1.0, 2.0, 0.79],
		        [3.0, 2.0, 0.0, 46.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 999.0, 0.0, 0.0, 0.0, 0.0, 999.0, 0.0, 3.0, 0.0, 7.0, 5.0, 10.0, 0.0, 999.0, 0.82],
		        [2.0, 0.0, 1.0, 19.0, 0.0, 999.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 999.0, 3.0, 0.0, 10.0, 5.0, 2.0, 4.0, 2.0, 3.0, 8.0, 5.0, 10.0, 1.0, 999.0, 0.82]
		    ]
		}';**/
		//$model_2_decoded = json_decode($model_2);

		    $csv = array_map('str_getcsv', file('render.csv'));

		            /***************************************************** First Observation of Model 2 **********************************************************/
		            $model_2_decoded_percentage_1 = 100 * $model_2_decoded->prediction[0][28];
		            //$model_2_decoded_percentage_1 = (string)$model_2_decoded_percentage_1_int;

		            $model_type_model2 = "Model 2";
		            $observation_no_model2 = "1";
		            
		            //State_Code 
		            $state_code_no_model2_api = (int)$model_2_decoded->prediction[0][0];
		            if ( ! isset ($csv[0][$state_code_no_model2_api - 1])) {
		                $state_code_no_model2 = "NULL";
		            } else {
		                $state_code_no_model2 = $csv[0][$state_code_no_model2_api - 1];
		            }


		            //Region
		            $region_no_model2_api = (int)$model_2_decoded->prediction[0][1];
		            if ( ! isset ($csv[1][$region_no_model2_api])) {
		                $region_no_model2 = "NULL";
		            } else {
		                $region_no_model2 = $csv[1][$region_no_model2_api];
		            }
		            

		            //Urban
		            $urban_no_model2_api = (int)$model_2_decoded->prediction[0][2];
		            if ( ! isset ($csv[2][$urban_no_model2_api])) {
		                $urban_no_model2 = "NULL";
		            } else {
		                $urban_no_model2 = $csv[2][$urban_no_model2_api];
		            }
		            

		            //Age
		            $age_no_model2_int = (int)$model_2_decoded->prediction[0][3];
		            $age_no_model2 = (string)$age_no_model2_int;


		            //Race
		            $race_no_model2_api = (int)$model_2_decoded->prediction[0][4];
		            if ( ! isset ($csv[4][$race_no_model2_api])) {
		                $race_no_model2 = "NULL";
		            } else {
		                $race_no_model2 = $csv[4][$race_no_model2_api];
		            }
		            

		            //Religion
		            $religion_no_model2_api = (int)$model_2_decoded->prediction[0][5];
		            if ( ! isset ($csv[5][$religion_no_model2_api])) {
		                $religion_no_model2 = "NULL";
		            } else {
		                $religion_no_model2 = $csv[5][$religion_no_model2_api];
		            }
		            

		            //Education
		            $education_no_model2_api = (int)$model_2_decoded->prediction[0][6];
		            if ( ! isset ($csv[6][$education_no_model2_api])) {
		                $education_no_model2 = "NULL";
		            } else {
		                $education_no_model2 = $csv[6][$education_no_model2_api];
		            }
		            

		            //School Perf
		            $school_perf_no_model2_api = (int)$model_2_decoded->prediction[0][7];
		            if ( ! isset ($csv[7][$school_perf_no_model2_api])) {
		                $school_perf_no_model2 = "NULL";
		            } else {
		                $school_perf_no_model2 = $csv[7][$school_perf_no_model2_api];
		            }
		            

		            //Birth Order
		            $birth_order_no_model2_api = (int)$model_2_decoded->prediction[0][8];
		            if ( ! isset ($csv[8][$birth_order_no_model2_api])) {
		                $birth_order_no_model2 = "NULL";
		            } else {
		                $birth_order_no_model2 = $csv[8][$birth_order_no_model2_api];
		            }


		            //No of Siblings
		            $no_siblings_no_model2_int = (int)$model_2_decoded->prediction[0][9];
		            $no_siblings_no_model2 = (string)$no_siblings_no_model2_int;


		            //Relationship Status
		            $relationship_no_model2_api = (int)$model_2_decoded->prediction[0][10];
		            if ( ! isset ($csv[10][$relationship_no_model2_api])) {
		                $relationship_no_model2 = "NULL";
		            } else {
		                $relationship_no_model2 = $csv[10][$relationship_no_model2_api];
		            }
		            

		            //Children
		            $children_no_model2_api = (int)$model_2_decoded->prediction[0][11];
		            if ( ! isset ($csv[11][$children_no_model2_api])) {
		                $children_no_model2 = "NULL";
		            } else {
		                $children_no_model2 = $csv[11][$children_no_model2_api];
		            }


		            //Employment Status
		            $employment_status_no_model2_api = (int)$model_2_decoded->prediction[0][12];
		            if ( ! isset ($csv[12][$employment_status_no_model2_api])) {
		                $employment_status_no_model2 = "NULL";
		            } else {
		                $employment_status_no_model2 = $csv[12][$employment_status_no_model2_api];
		            }


		            //Employment Type
		            $employment_type_no_model2_api = (int)$model_2_decoded->prediction[0][13];
		            if ( ! isset ($csv[13][$employment_type_no_model2_api])) {
		                $employment_type_no_model2 = "NULL";
		            } else {
		                $employment_type_no_model2 = $csv[13][$employment_type_no_model2_api];
		            }
		            

		            //Military Branch
		            $military_branch_no_model2_api = (int)$model_2_decoded->prediction[0][14];
		            if ( ! isset ($csv[14][$military_branch_no_model2_api])) {
		                $military_branch_no_model2 = "NULL";
		            } else {
		                $military_branch_no_model2 = $csv[14][$military_branch_no_model2_api];
		            }
		            

		            //community_involvement_no
		            $community_involvement_no_model2_api = (int)$model_2_decoded->prediction[0][15];
		            if ( ! isset ($csv[15][$community_involvement_no_model2_api])) {
		                $community_involvement_no_model2 = "NULL";
		            } else {
		                $community_involvement_no_model2 = $csv[15][$community_involvement_no_model2_api];
		            }
		            

		            //part_1_crimes_no
		            $part_1_crimes_no_model2_int = (int)$model_2_decoded->prediction[0][16];
		            $part_1_crimes_no_model2 = (string)$part_1_crimes_no_model2_int;


		            //part_2_crimes_no
		            $part_2_crimes_no_model2_int = (int)$model_2_decoded->prediction[0][17];
		            $part_2_crimes_no_model2 = (string)$part_2_crimes_no_model2_int;


		            //domestic_abuse_spec_no
		            $domestic_abuse_spec_no_model2_api = (int)$model_2_decoded->prediction[0][18];
		            if ( ! isset ($csv[18][$domestic_abuse_spec_no_model2_api])) {
		                $domestic_abuse_spec_no_model2 = "NULL";
		            } else {
		                $domestic_abuse_spec_no_model2 = $csv[18][$domestic_abuse_spec_no_model2_api];
		            }
		            

		            //childhood_socioeconomic_no
		            $childhood_socioeconomic_no_model2_api = (int)$model_2_decoded->prediction[0][19];
		            if ( ! isset ($csv[19][$childhood_socioeconomic_no_model2_api])) {
		                $childhood_socioeconomic_no_model2 = "NULL";
		            } else {
		                $childhood_socioeconomic_no_model2 = $csv[19][$childhood_socioeconomic_no_model2_api];
		            }
		            

		            //recent_stressor_triggering_event_no
		            $recent_stressor_triggering_event_no_model2_api = (int)$model_2_decoded->prediction[0][20];
		            if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model2_api])) {
		                $recent_stressor_triggering_event_no_model2 = "NULL";
		            } else {
		                $recent_stressor_triggering_event_no_model2 = $csv[20][$recent_stressor_triggering_event_no_model2_api];
		            }
		            

		            //timeframe_signs_crisis_no
		            $timeframe_signs_crisis_no_model2_api = (int)$model_2_decoded->prediction[0][21];
		            if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model2_api])) {
		                $timeframe_signs_crisis_no_model2 = "NULL";
		            } else {
		                $timeframe_signs_crisis_no_model2 = $csv[21][$timeframe_signs_crisis_no_model2_api];
		            }
		            

		            //substance_use_and_abuse_no
		            $substance_use_and_abuse_no_model2_api = (int)$model_2_decoded->prediction[0][22];
		            if ( ! isset ($csv[22][$substance_use_and_abuse_no_model2_api])) {
		                $substance_use_and_abuse_no_model2 = "NULL";
		            } else {
		                $substance_use_and_abuse_no_model2 = $csv[22][$substance_use_and_abuse_no_model2_api];
		            }
		            

		            //known_prejudices
		            $known_prejudices_no_model2_api = (int)$model_2_decoded->prediction[0][23];
		            if ( ! isset ($csv[23][$known_prejudices_no_model2_api])) {
		                $known_prejudices_no_model2 = "NULL";
		            } else {
		                $known_prejudices_no_model2 = $csv[23][$known_prejudices_no_model2_api];
		            }
		            

		            //leakage_how_no
		            $leakage_how_no_model2_api = (int)$model_2_decoded->prediction[0][24];
		            if ( ! isset ($csv[24][$leakage_how_no_model2_api - 1])) {
		                $leakage_how_no_model2 = "NULL";
		            } else {
		                $leakage_how_no_model2 = $csv[24][$leakage_how_no_model2_api - 1];
		            }
		            

		            //leakage_who_no
		            $leakage_who_no_model2_api = (int)$model_2_decoded->prediction[0][25];
		            if ( ! isset ($csv[25][$leakage_who_no_model2_api - 1])) {
		                $leakage_who_no_model2 = "NULL";
		            } else {
		                $leakage_who_no_model2 = $csv[25][$leakage_who_no_model2_api - 1];
		            }
		            

		            //leakage_specific_no
		            $leakage_specific_no_model2_api = (int)$model_2_decoded->prediction[0][26];
		            if ( ! isset ($csv[26][$leakage_specific_no_model2_api])) {
		                $leakage_specific_no_model2 = "NULL";
		            } else {
		                $leakage_specific_no_model2 = $csv[26][$leakage_specific_no_model2_api];
		            }
		            

		            //criminal sentence
		            $criminal_sentence_model2_api = (int)$model_2_decoded->prediction[0][27];
		            if ( ! isset ($csv[27][$criminal_sentence_model2_api])) {
		                $criminal_sentence_model2 = "NULL";
		            } else {
		                $criminal_sentence_model2 = $csv[27][$criminal_sentence_model2_api];
		            }


		            /************************* Insert Model 2 - Observation 1 Result in DB ******************************/ 

		            $sql_model2_0 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		            if($stmt_model2_0 = mysqli_prepare($link, $sql_model2_0)){

		            mysqli_stmt_bind_param($stmt_model2_0, "ssssssssssssssssssssssssssssssss", $parent_id_model2_0, $model_type_model2_0, $observation_no_model2_0, $percentage_model2_0, $state_code_model2_0, $region_model2_0, $urban_model2_0, $age_model2_0, $religion_model2_0, $race_model2_0, $education_model2_0, $birth_order_model2_0, $relationship_model2_0, $school_perf_model2_0, $no_siblings_model2_0, $employment_status_model2_0, $children_model2_0, $community_involvement_model2_0, $employment_type_model2_0, $military_branch_model2_0, $part_1_crimes_model2_0, $part_2_crimes_model2_0, $domestic_abuse_spec_model2_0, $childhood_socioeconomic_model2_0, $timeframe_signs_crisis_model2_0, $recent_stressor_triggering_event_model2_0, $known_prejudices_model2_0, $substance_use_and_abuse_model2_0, $leakage_how_model2_0, $leakage_who_model2_0, $leakage_specific_model2_0, $criminal_sentence_model2_0);

		                $parent_id_model2_0 = $parent_id;
		                $model_type_model2_0 = $model_type_model2;
		                $observation_no_model2_0 = $observation_no_model2; 
		                $percentage_model2_0 = $model_2_decoded_percentage_1;
		                $state_code_model2_0 = $state_code_no_model2;
		                $region_model2_0 = $region_no_model2;
		                $urban_model2_0 = $urban_no_model2;
		                $age_model2_0 = $age_no_model2;
		                $religion_model2_0 = $religion_no_model2;
		                $race_model2_0 = $race_no_model2;
		                $education_model2_0 = $education_no_model2;
		                $birth_order_model2_0 = $birth_order_no_model2;
		                $relationship_model2_0 = $relationship_no_model2;
		                $school_perf_model2_0 = $school_perf_no_model2;
		                $no_siblings_model2_0 = $no_siblings_no_model2;
		                $employment_status_model2_0 = $employment_status_no_model2;
		                $children_model2_0 = $children_no_model2;
		                $community_involvement_model2_0 = $community_involvement_no_model2;
		                $employment_type_model2_0 = $employment_type_no_model2;
		                $military_branch_model2_0 = $military_branch_no_model2;
		                $part_1_crimes_model2_0 = $part_1_crimes_no_model2;
		                $part_2_crimes_model2_0 = $part_2_crimes_no_model2;
		                $domestic_abuse_spec_model2_0 = $domestic_abuse_spec_no_model2;
		                $childhood_socioeconomic_model2_0 = $childhood_socioeconomic_no_model2;
		                $timeframe_signs_crisis_model2_0 = $timeframe_signs_crisis_no_model2;
		                $recent_stressor_triggering_event_model2_0 = $recent_stressor_triggering_event_no_model2;
		                $known_prejudices_model2_0 = $known_prejudices_no_model2;
		                $substance_use_and_abuse_model2_0 = $substance_use_and_abuse_no_model2;
		                $leakage_how_model2_0 = $leakage_how_no_model2;
		                $leakage_who_model2_0 = $leakage_who_no_model2;
		                $leakage_specific_model2_0 = $leakage_specific_no_model2;
		                $criminal_sentence_model2_0 = $criminal_sentence_model2;
		            }

		            mysqli_stmt_execute($stmt_model2_0);
		                //do nothing

		            // Close statement
		            mysqli_stmt_close($stmt_model2_0);

		            //exit;

					/************************* End of Insert Model 2 - Observation 1 Result in DB ******************************/ 
					/***************************************************** End of First Observation of Model 2 **********************************************************/




					/*********************************************** Second Observation of Model 2 **************************************************/
					$model_2_decoded_percentage_2 = 100 * $model_2_decoded->prediction[1][28];
					$model_type_model2_2 = "Model 2";
					$observation_no_model2_2 = "2";

					//State_Code
					$state_code_no_model2_api_2 = (int)$model_2_decoded->prediction[1][0];
					if ( ! isset ($csv[0][$state_code_no_model2_api_2 - 1])) {
						$state_code_no_model2_2 = "NULL";
					} else {
						$state_code_no_model2_2 = $csv[0][$state_code_no_model2_api_2 - 1];
					}
					

					//Region
					$region_no_model2_api_2 = (int)$model_2_decoded->prediction[1][1];
					if ( ! isset ($csv[1][$region_no_model2_api_2])) {
						$region_no_model2_2 = "NULL";
					} else {
						$region_no_model2_2 = $csv[1][$region_no_model2_api_2];
					}
					

					//Urban
					$urban_no_model2_api_2 = (int)$model_2_decoded->prediction[1][2];
					if ( ! isset ($csv[2][$urban_no_model2_api_2])) {
						$urban_no_model2_2 = "NULL";
					} else {
						$urban_no_model2_2 = $csv[2][$urban_no_model2_api_2];
					}
					

					//Age
					$age_no_model2_2_int = (int)$model_2_decoded->prediction[1][3];
					$age_no_model2_2 = (string)$age_no_model2_2_int;


					//Race
					$race_no_model2_api_2 = (int)$model_2_decoded->prediction[1][4];
					if ( ! isset ($csv[4][$race_no_model2_api_2])) {
						$race_no_model2_2 = "NULL";
					} else {
						$race_no_model2_2 = $csv[4][$race_no_model2_api_2];
					}
					

					//Religion
					$religion_no_model2_api_2 = (int)$model_2_decoded->prediction[1][5];
					if ( ! isset ($csv[5][$religion_no_model2_api_2])) {
						$religion_no_model2_2 = "NULL";
					} else {
						$religion_no_model2_2 = $csv[5][$religion_no_model2_api_2];
					}
					

					//Education
					$education_no_model2_api_2 = (int)$model_2_decoded->prediction[1][6];
					if ( ! isset ($csv[6][$education_no_model2_api_2])) {
						$education_no_model2_2 = "NULL";
					} else {
						$education_no_model2_2 = $csv[6][$education_no_model2_api_2];
					}
					

					//School Perf
					$school_perf_no_model2_api_2 = (int)$model_2_decoded->prediction[1][7];
					if ( ! isset ($csv[7][$school_perf_no_model2_api_2])) {
						$school_perf_no_model2_2 = "NULL";
					} else {
						$school_perf_no_model2_2 = $csv[7][$school_perf_no_model2_api_2];
					}
					

					//Birth Order
					$birth_order_no_model2_api_2 = (int)$model_2_decoded->prediction[1][8];
					if ( ! isset ($csv[8][$birth_order_no_model2_api_2])) {
						$birth_order_no_model2_2 = "NULL";
					} else {
						$birth_order_no_model2_2 = $csv[8][$birth_order_no_model2_api_2];
					}


					//No of Siblings
					$no_siblings_no_model2_2_int = (int)$model_2_decoded->prediction[1][9];
					$no_siblings_no_model2_2 = (string)$no_siblings_no_model2_2_int;


					//Relationship Status
					$relationship_no_model2_api_2 = (int)$model_2_decoded->prediction[1][10];
					if ( ! isset ($csv[10][$relationship_no_model2_api_2])) {
						$relationship_no_model2_2 = "NULL";
					} else {
						$relationship_no_model2_2 = $csv[10][$relationship_no_model2_api_2];
					}
					

					//Children
					$children_no_model2_api_2 = (int)$model_2_decoded->prediction[1][11];
					if ( ! isset ($csv[11][$children_no_model2_api_2])) {
						$children_no_model2_2 = "NULL";
					} else {
						$children_no_model2_2 = $csv[11][$children_no_model2_api_2];
					}


					//Employment Status
					$employment_status_no_model2_api_2 = (int)$model_2_decoded->prediction[1][12];
					if ( ! isset ($csv[12][$employment_status_no_model2_api_2])) {
						$employment_status_no_model2_2 = "NULL";
					} else {
						$employment_status_no_model2_2 = $csv[12][$employment_status_no_model2_api_2];
					}


					//Employment Type
					$employment_type_no_model2_api_2 = (int)$model_2_decoded->prediction[1][13];
					if ( ! isset ($csv[13][$employment_type_no_model2_api_2])) {
						$employment_type_no_model2_2 = "NULL";
					} else {
						$employment_type_no_model2_2 = $csv[13][$employment_type_no_model2_api_2];
					}
					

					//Military Branch
					$military_branch_no_model2_api_2 = (int)$model_2_decoded->prediction[1][14];
					if ( ! isset ($csv[14][$military_branch_no_model2_api_2])) {
						$military_branch_no_model2_2 = "NULL";
					} else {
						$military_branch_no_model2_2 = $csv[14][$military_branch_no_model2_api_2];
					}
					

					//community_involvement_no
					$community_involvement_no_model2_api_2 = (int)$model_2_decoded->prediction[1][15];
					if ( ! isset ($csv[15][$community_involvement_no_model2_api_2])) {
						$community_involvement_no_model2_2 = "NULL";
					} else {
						$community_involvement_no_model2_2 = $csv[15][$community_involvement_no_model2_api_2];
					}
					

					//part_1_crimes_no
					$part_1_crimes_no_model2_2_int = (int)$model_2_decoded->prediction[1][16];
					$part_1_crimes_no_model2_2 = (string)$part_1_crimes_no_model2_2_int;


					//part_2_crimes_no
					$part_2_crimes_no_model2_2_int = (int)$model_2_decoded->prediction[1][17];
					$part_2_crimes_no_model2_2 = (string)$part_2_crimes_no_model2_2_int;


					//domestic_abuse_spec_no
					$domestic_abuse_spec_no_model2_api_2 = (int)$model_2_decoded->prediction[1][18];
					if ( ! isset ($csv[18][$domestic_abuse_spec_no_model2_api_2])) {
						$domestic_abuse_spec_no_model2_2 = "NULL";
					} else {
						$domestic_abuse_spec_no_model2_2 = $csv[18][$domestic_abuse_spec_no_model2_api_2];
					}
					

					//childhood_socioeconomic_no
					$childhood_socioeconomic_no_model2_api_2 = (int)$model_2_decoded->prediction[1][19];
					if ( ! isset ($csv[19][$childhood_socioeconomic_no_model2_api_2])) {
						$childhood_socioeconomic_no_model2_2 = "NULL";
					} else {
						$childhood_socioeconomic_no_model2_2 = $csv[19][$childhood_socioeconomic_no_model2_api_2];
					}
					

					//recent_stressor_triggering_event_no
					$recent_stressor_triggering_event_no_model2_api_2 = (int)$model_2_decoded->prediction[1][20];
					if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model2_api_2])) {
						$recent_stressor_triggering_event_no_model2_2 = "NULL";
					} else {
						$recent_stressor_triggering_event_no_model2_2 = $csv[20][$recent_stressor_triggering_event_no_model2_api_2];
					}
					

					//timeframe_signs_crisis_no
					$timeframe_signs_crisis_no_model2_api_2 = (int)$model_2_decoded->prediction[1][21];
					if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model2_api_2])) {
						$timeframe_signs_crisis_no_model2_2 = "NULL";
					} else {
						$timeframe_signs_crisis_no_model2_2 = $csv[21][$timeframe_signs_crisis_no_model2_api_2];
					}
					

					//substance_use_and_abuse_no
					$substance_use_and_abuse_no_model2_api_2 = (int)$model_2_decoded->prediction[1][22];
					if ( ! isset ($csv[22][$substance_use_and_abuse_no_model2_api_2])) {
						$substance_use_and_abuse_no_model2_2 = "NULL";
					} else {
						$substance_use_and_abuse_no_model2_2 = $csv[22][$substance_use_and_abuse_no_model2_api_2];
					}
					

					//known_prejudices
					$known_prejudices_no_model2_api_2 = (int)$model_2_decoded->prediction[1][23];
					if ( ! isset ($csv[23][$known_prejudices_no_model2_api_2])) {
						$known_prejudices_no_model2_2 = "NULL";
					} else {
						$known_prejudices_no_model2_2 = $csv[23][$known_prejudices_no_model2_api_2];
					}
					

					//leakage_how_no
					$leakage_how_no_model2_api_2 = (int)$model_2_decoded->prediction[1][24];
					if ( ! isset ($csv[24][$leakage_how_no_model2_api_2 - 1])) {
						$leakage_how_no_model2_2 = "NULL";
					} else {
						$leakage_how_no_model2_2 = $csv[24][$leakage_how_no_model2_api_2 - 1];
					}
					

					//leakage_who_no
					$leakage_who_no_model2_api_2 = (int)$model_2_decoded->prediction[1][25];
					if ( ! isset ($csv[25][$leakage_who_no_model2_api_2 - 1])) {
						$leakage_who_no_model2_2 = "NULL";
					} else {
						$leakage_who_no_model2_2 = $csv[25][$leakage_who_no_model2_api_2 - 1];
					}
					

					//leakage_specific_no
					$leakage_specific_no_model2_api_2 = (int)$model_2_decoded->prediction[1][26];
					if ( ! isset ($csv[26][$leakage_specific_no_model2_api_2])) {
						$leakage_specific_no_model2_2 = "NULL";
					} else {
						$leakage_specific_no_model2_2 = $csv[26][$leakage_specific_no_model2_api_2];
					}
					

					//criminal sentence
					$criminal_sentence_model2_api_2 = (int)$model_2_decoded->prediction[1][27];
					if ( ! isset ($csv[27][$criminal_sentence_model2_api_2])) {
						$criminal_sentence_model2_2 = "NULL";
					} else {
						$criminal_sentence_model2_2 = $csv[27][$criminal_sentence_model2_api_2];
					}

					/************************* Insert Model 2 - Observation 2 Result in DB ******************************/ 
					$sql_model2_1 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					if($stmt_model2_1 = mysqli_prepare($link, $sql_model2_1)){

		 			mysqli_stmt_bind_param($stmt_model2_1, "ssssssssssssssssssssssssssssssss", $parent_id_model2_1, $model_type_model2_1, $observation_no_model2_1, $percentage_model2_1, $state_code_model2_1, $region_model2_1, $urban_model2_1, $age_model2_1, $religion_model2_1, $race_model2_1, $education_model2_1, $birth_order_model2_1, $relationship_model2_1, $school_perf_model2_1, $no_siblings_model2_1, $employment_status_model2_1, $children_model2_1, $community_involvement_model2_1, $employment_type_model2_1, $military_branch_model2_1, $part_1_crimes_model2_1, $part_2_crimes_model2_1, $domestic_abuse_spec_model2_1, $childhood_socioeconomic_model2_1, $timeframe_signs_crisis_model2_1, $recent_stressor_triggering_event_model2_1, $known_prejudices_model2_1, $substance_use_and_abuse_model2_1, $leakage_how_model2_1, $leakage_who_model2_1, $leakage_specific_model2_1, $criminal_sentence_model2_1);

		 				$parent_id_model2_1 = $parent_id;
		 				$model_type_model2_1 = $model_type_model2_2;
		 				$observation_no_model2_1 = $observation_no_model2_2;
		 				$percentage_model2_1 = $model_2_decoded_percentage_2;
						$state_code_model2_1 = $state_code_no_model2_2;
						$region_model2_1 = $region_no_model2_2;
						$urban_model2_1 = $urban_no_model2_2;
						$age_model2_1 = $age_no_model2_2;
						$religion_model2_1 = $religion_no_model2_2;
						$race_model2_1 = $race_no_model2_2;
						$education_model2_1 = $education_no_model2_2;
						$birth_order_model2_1 = $birth_order_no_model2_2;
						$relationship_model2_1 = $relationship_no_model2_2;
						$school_perf_model2_1 = $school_perf_no_model2_2;
						$no_siblings_model2_1 = $no_siblings_no_model2_2;
						$employment_status_model2_1 = $employment_status_no_model2_2;
						$children_model2_1 = $children_no_model2_2;
						$community_involvement_model2_1 = $community_involvement_no_model2_2;
						$employment_type_model2_1 = $employment_type_no_model2_2;
						$military_branch_model2_1 = $military_branch_no_model2_2;
						$part_1_crimes_model2_1 = $part_1_crimes_no_model2_2;
						$part_2_crimes_model2_1 = $part_2_crimes_no_model2_2;
						$domestic_abuse_spec_model2_1 = $domestic_abuse_spec_no_model2_2;
						$childhood_socioeconomic_model2_1 = $childhood_socioeconomic_no_model2_2;
						$timeframe_signs_crisis_model2_1 = $timeframe_signs_crisis_no_model2_2;
						$recent_stressor_triggering_event_model2_1 = $recent_stressor_triggering_event_no_model2_2;
						$known_prejudices_model2_1 = $known_prejudices_no_model2_2;
						$substance_use_and_abuse_model2_1 = $substance_use_and_abuse_no_model2_2;
						$leakage_how_model2_1 = $leakage_how_no_model2_2;
						$leakage_who_model2_1 = $leakage_who_no_model2_2;
						$leakage_specific_model2_1 = $leakage_specific_no_model2_2;
						$criminal_sentence_model2_1 = $criminal_sentence_model2_2;
					}

					mysqli_stmt_execute($stmt_model2_1);

		   			// Close statement
			 		mysqli_stmt_close($stmt_model2_1);

					/************************* End of Insert Model 2 - Observation 2 Result in DB ******************************/ 
					/***************************************************** End of Second Observation of Model 2 **********************************************************/




					
					/************************************************ Third Observation of Model 2 ***********************************************/
					$model_2_decoded_percentage_3 = 100 * $model_2_decoded->prediction[2][28];
					$model_type_model2_3 = "Model 2";
					$observation_no_model2_3 = "3";

					//State_Code
					$state_code_no_model2_api_3 = (int)$model_2_decoded->prediction[2][0];
					if ( ! isset ($csv[0][$state_code_no_model2_api_3 - 1])){
						$state_code_no_model2_3 = "NULL";
					} else {
						$state_code_no_model2_3 = $csv[0][$state_code_no_model2_api_3 - 1];
					}
					

					//Region
					$region_no_model2_api_3 = (int)$model_2_decoded->prediction[2][1];
					if ( ! isset ($csv[1][$region_no_model2_api_3])){
						$region_no_model2_3 = "NULL";
					} else {
						$region_no_model2_3 = $csv[1][$region_no_model2_api_3];
					}
					

					//Urban
					$urban_no_model2_api_3 = (int)$model_2_decoded->prediction[2][2];
					if ( ! isset ($csv[2][$urban_no_model2_api_3])){
						$urban_no_model2_3 = "NULL";
					} else {
						$urban_no_model2_3 = $csv[2][$urban_no_model2_api_3];
					}
					

					//Age
					$age_no_model2_3_int = (int)$model_2_decoded->prediction[2][3];
					$age_no_model2_3 = (string)$age_no_model2_3_int;


					//Race
					$race_no_model2_api_3 = (int)$model_2_decoded->prediction[2][4];
					if ( ! isset ($csv[4][$race_no_model2_api_3])){
						$race_no_model2_3 = "NULL";
					} else {
						$race_no_model2_3 = $csv[4][$race_no_model2_api_3];
					}
					

					//Religion
					$religion_no_model2_api_3 = (int)$model_2_decoded->prediction[2][5];
					if ( ! isset ($csv[5][$religion_no_model2_api_3])){
						$religion_no_model2_3 = "NULL";
					} else {
						$religion_no_model2_3 = $csv[5][$religion_no_model2_api_3];
					}
					

					//Education
					$education_no_model2_api_3 = (int)$model_2_decoded->prediction[2][6];
					if ( ! isset ($csv[6][$education_no_model2_api_3])){
						$education_no_model2_3 = "NULL";
					} else {
						$education_no_model2_3 = $csv[6][$education_no_model2_api_3];
					}
					

					//School Perf
					$school_perf_no_model2_api_3 = (int)$model_2_decoded->prediction[2][7];
					if ( ! isset ($csv[7][$school_perf_no_model2_api_3])){
						$school_perf_no_model2_3 = "NULL";
					} else {
						$school_perf_no_model2_3 = $csv[7][$school_perf_no_model2_api_3];
					}
					

					//Birth Order
					$birth_order_no_model2_api_3 = (int)$model_2_decoded->prediction[2][8];
					if ( ! isset ($csv[8][$birth_order_no_model2_api_3])){
						$birth_order_no_model2_3 = "NULL";
					} else {
						$birth_order_no_model2_3 = $csv[8][$birth_order_no_model2_api_3];
					}


					//No of Siblings
					$no_siblings_no_model2_3_int = (int)$model_2_decoded->prediction[2][9];
					$no_siblings_no_model2_3 = (string)$no_siblings_no_model2_3_int;


					//Relationship Status
					$relationship_no_model2_api_3 = (int)$model_2_decoded->prediction[2][10];
					if ( ! isset ($csv[10][$relationship_no_model2_api_3])){
						$relationship_no_model2_3 = "NULL";
					} else {
						$relationship_no_model2_3 = $csv[10][$relationship_no_model2_api_3];
					}
					

					//Children
					$children_no_model2_api_3 = (int)$model_2_decoded->prediction[2][11];
					if ( ! isset ($csv[11][$children_no_model2_api_3])){
						$children_no_model2_3 = "NULL";
					} else {
						$children_no_model2_3 = $csv[11][$children_no_model2_api_3];
					}


					//Employment Status
					$employment_status_no_model2_api_3 = (int)$model_2_decoded->prediction[2][12];
					if ( ! isset ($csv[12][$employment_status_no_model2_api_3])){
						$employment_status_no_model2_3 = "NULL";
					} else {
						$employment_status_no_model2_3 = $csv[12][$employment_status_no_model2_api_3];
					}


					//Employment Type
					$employment_type_no_model2_api_3 = (int)$model_2_decoded->prediction[2][13];
					if ( ! isset ($csv[13][$employment_type_no_model2_api_3])){
						$employment_type_no_model2_3 = "NULL";
					} else {
						$employment_type_no_model2_3 = $csv[13][$employment_type_no_model2_api_3];
					}
					

					//Military Branch
					$military_branch_no_model2_api_3 = (int)$model_2_decoded->prediction[2][14];
					if ( ! isset ($csv[14][$military_branch_no_model2_api_3])){
						$military_branch_no_model2_3 = "NULL";
					} else {
						$military_branch_no_model2_3 = $csv[14][$military_branch_no_model2_api_3];
					}
					

					//community_involvement_no
					$community_involvement_no_model2_api_3 = (int)$model_2_decoded->prediction[2][15];
					if ( ! isset ($csv[15][$community_involvement_no_model2_api_3])){
						$community_involvement_no_model2_3 = "NULL";
					} else {
						$community_involvement_no_model2_3 = $csv[15][$community_involvement_no_model2_api_3];
					}
					

					//part_1_crimes_no
					$part_1_crimes_no_model2_3_int = (int)$model_2_decoded->prediction[2][16];
					$part_1_crimes_no_model2_3 = (string)$part_1_crimes_no_model2_3_int;

					//part_2_crimes_no
					$part_2_crimes_no_model2_3_int = (int)$model_2_decoded->prediction[2][17];
					$part_2_crimes_no_model2_3 = (string)$part_2_crimes_no_model2_3_int;


					//domestic_abuse_spec_no
					$domestic_abuse_spec_no_model2_api_3 = (int)$model_2_decoded->prediction[2][18];
					if ( ! isset ($csv[18][$domestic_abuse_spec_no_model2_api_3])){
						$domestic_abuse_spec_no_model2_3 = "NULL";
					} else {
						$domestic_abuse_spec_no_model2_3 = $csv[18][$domestic_abuse_spec_no_model2_api_3];
					}
					

					//childhood_socioeconomic_no
					$childhood_socioeconomic_no_model2_api_3 = (int)$model_2_decoded->prediction[2][19];
					if ( ! isset ($csv[19][$childhood_socioeconomic_no_model2_api_3])){
						$childhood_socioeconomic_no_model2_3 = "NULL";
					} else {
						$childhood_socioeconomic_no_model2_3 = $csv[19][$childhood_socioeconomic_no_model2_api_3];
					}
					

					//recent_stressor_triggering_event_no
					$recent_stressor_triggering_event_no_model2_api_3 = (int)$model_2_decoded->prediction[2][20];
					if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model2_api_3])){
						$recent_stressor_triggering_event_no_model2_3 = "NULL";
					} else {
						$recent_stressor_triggering_event_no_model2_3 = $csv[20][$recent_stressor_triggering_event_no_model2_api_3];
					}
					

					//timeframe_signs_crisis_no
					$timeframe_signs_crisis_no_model2_api_3 = (int)$model_2_decoded->prediction[2][21];
					if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model2_api_3])){
						$timeframe_signs_crisis_no_model2_3 = "NULL";
					} else {
						$timeframe_signs_crisis_no_model2_3 = $csv[21][$timeframe_signs_crisis_no_model2_api_3];
					}
					

					//substance_use_and_abuse_no
					$substance_use_and_abuse_no_model2_api_3 = (int)$model_2_decoded->prediction[2][22];
					if ( ! isset ($csv[22][$substance_use_and_abuse_no_model2_api_3])){
						$substance_use_and_abuse_no_model2_3 = "NULL";
					} else {
						$substance_use_and_abuse_no_model2_3 = $csv[22][$substance_use_and_abuse_no_model2_api_3];
					}
					

					//known_prejudices
					$known_prejudices_no_model2_api_3 = (int)$model_2_decoded->prediction[2][23];
					if ( ! isset ($csv[23][$known_prejudices_no_model2_api_3])){
						$known_prejudices_no_model2_3 = "NULL";
					} else {
						$known_prejudices_no_model2_3 = $csv[23][$known_prejudices_no_model2_api_3];
					}
					

					//leakage_how_no
					$leakage_how_no_model2_api_3 = (int)$model_2_decoded->prediction[2][24];
					if ( ! isset ($csv[24][$leakage_how_no_model2_api_3 - 1])){
						$leakage_how_no_model2_3 = "NULL";
					} else {
						$leakage_how_no_model2_3 = $csv[24][$leakage_how_no_model2_api_3 - 1];
					}
					

					//leakage_who_no
					$leakage_who_no_model2_api_3 = (int)$model_2_decoded->prediction[2][25];
					if ( ! isset ($csv[25][$leakage_who_no_model2_api_3 - 1])){
						$leakage_who_no_model2_3 = "NULL";
					} else {
						$leakage_who_no_model2_3 = $csv[25][$leakage_who_no_model2_api_3 - 1];
					}
					

					//leakage_specific_no
					$leakage_specific_no_model2_api_3 = (int)$model_2_decoded->prediction[2][26];
					if ( ! isset ($csv[26][$leakage_specific_no_model2_api_3])){
						$leakage_specific_no_model2_3 = "NULL";
					} else {
						$leakage_specific_no_model2_3 = $csv[26][$leakage_specific_no_model2_api_3];
					}
					

					//criminal sentence
					$criminal_sentence_model2_api_3 = (int)$model_2_decoded->prediction[2][27];
					if ( ! isset ($csv[27][$criminal_sentence_model2_api_3])){
						$criminal_sentence_model2_3 = "NULL";
					} else {
						$criminal_sentence_model2_3 = $csv[27][$criminal_sentence_model2_api_3];
					}



					/************************* Insert Model 2 - Observation 3 Result in DB ******************************/
					$sql_model2_2 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					if($stmt_model2_3b = mysqli_prepare($link, $sql_model2_2)){

		 			mysqli_stmt_bind_param($stmt_model2_3b, "ssssssssssssssssssssssssssssssss", $parent_id_model2_3b, $model_type_model2_3b, $observation_no_model2_3b, $percentage_model2_3b, $state_code_model2_3b, $region_model2_3b, $urban_model2_3b, $age_model2_3b, $religion_model2_3b, $race_model2_3b, $education_model2_3b, $birth_order_model2_3b, $relationship_model2_3b, $school_perf_model2_3b, $no_siblings_model2_3b, $employment_status_model2_3b, $children_model2_3b, $community_involvement_model2_3b, $employment_type_model2_3b, $military_branch_model2_3b, $part_1_crimes_model2_3b, $part_2_crimes_model2_3b, $domestic_abuse_spec_model2_3b, $childhood_socioeconomic_model2_3b, $timeframe_signs_crisis_model2_3b, $recent_stressor_triggering_event_model2_3b, $known_prejudices_model2_3b, $substance_use_and_abuse_model2_3b, $leakage_how_model2_3b, $leakage_who_model2_3b, $leakage_specific_model2_3b, $criminal_sentence_model2_3b);

		 				$parent_id_model2_3b = $parent_id;
		 				$model_type_model2_3b = $model_type_model2_3;
		 				$observation_no_model2_3b = $observation_no_model2_3;
		 				$percentage_model2_3b = $model_2_decoded_percentage_3;
						$state_code_model2_3b = $state_code_no_model2_3;
						$region_model2_3b = $region_no_model2_3;
						$urban_model2_3b = $urban_no_model2_3;
						$age_model2_3b = $age_no_model2_3;
						$religion_model2_3b = $religion_no_model2_3;
						$race_model2_3b = $race_no_model2_3;
						$education_model2_3b = $education_no_model2_3;
						$birth_order_model2_3b = $birth_order_no_model2_3;
						$relationship_model2_3b = $relationship_no_model2_3;
						$school_perf_model2_3b = $school_perf_no_model2_3;
						$no_siblings_model2_3b = $no_siblings_no_model2_3;
						$employment_status_model2_3b = $employment_status_no_model2_3;
						$children_model2_3b = $children_no_model2_3;
						$community_involvement_model2_3b = $community_involvement_no_model2_3;
						$employment_type_model2_3b = $employment_type_no_model2_3;
						$military_branch_model2_3b = $military_branch_no_model2_3;
						$part_1_crimes_model2_3b = $part_1_crimes_no_model2_3;
						$part_2_crimes_model2_3b = $part_2_crimes_no_model2_3;
						$domestic_abuse_spec_model2_3b = $domestic_abuse_spec_no_model2_3;
						$childhood_socioeconomic_model2_3b = $childhood_socioeconomic_no_model2_3;
						$timeframe_signs_crisis_model2_3b = $timeframe_signs_crisis_no_model2_3;
						$recent_stressor_triggering_event_model2_3b = $recent_stressor_triggering_event_no_model2_3;
						$known_prejudices_model2_3b = $known_prejudices_no_model2_3;
						$substance_use_and_abuse_model2_3b = $substance_use_and_abuse_no_model2_3;
						$leakage_how_model2_3b = $leakage_how_no_model2_3;
						$leakage_who_model2_3b = $leakage_who_no_model2_3;
						$leakage_specific_model2_3b = $leakage_specific_no_model2_3;
						$criminal_sentence_model2_3b = $criminal_sentence_model2_3;
					}

					mysqli_stmt_execute($stmt_model2_3b);

		   			// Close statement
			 		mysqli_stmt_close($stmt_model2_3b);

					/************************* End of Insert Model 2 - Observation 3 Result in DB ******************************/ 
					/***************************************************** End of third Observation of Model 2 **********************************************************/
			/********************************************** FUll END OF MODEL 2 API ************************************************/ 



			/******************************************************* MODEL 3 API *****************************************/
			
			$curl_3 = curl_init();

			curl_setopt($curl_3, CURLOPT_URL, "http://127.0.0.1:5000/customModel");

			curl_setopt($curl_3, CURLOPT_RETURNTRANSFER, true);

			curl_setopt($curl_3, CURLOPT_POST, true);

			curl_setopt($curl_3, CURLOPT_POSTFIELDS, $data_model23);

			//curl_setopt($curl_3, CURLOPT_CUSTOMREQUEST, 'PUT');

			curl_setopt($curl_3, CURLINFO_HEADER_OUT, true);
		 
			curl_setopt($curl_3, CURLOPT_HTTPHEADER, [
			  'X-RapidAPI-Host: https://127.0.0.1:5000/customModel',
			  //'X-RapidAPI-Key: 7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
			  'Content-Type: application/json'
			]);

			$model_3 = curl_exec($curl_3);

			$model_3_decoded = json_decode($model_3);

			curl_close($curl_3);

			/**$model_3 = '{ "prediction": [
		        [6.0, 3.0, 0.0, 24.0, 0.0, 1.0, 4.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 999.0, 1.0, 0.0, 0.0, 0.0, 1.0, 3.0, 2.0, 3.0, 0.0, 1.0, 7.0, 1.0, 2.0,0.71],
		        [38.0, 2.0, 0.0, 46.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 999.0, 0.0, 0.0, 0.0, 0.0, 999.0, 0.0, 3.0, 0.0, 7.0, 5.0, 10.0, 0.0, 999.0, 0.82],
		        [9.0, 0.0, 1.0, 19.0, 0.0, 999.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 999.0, 3.0, 0.0, 10.0, 5.0, 2.0, 4.0, 2.0, 3.0, 8.0, 5.0, 10.0, 1.0, 999.0, 0.82]
		    ]
		}';**/

		//$model_3_decoded = json_decode($model_3);

			//$csv = array_map('str_getcsv', file('render.csv'));
			

					/************************************************ First Observation of Model 3 *************************************************/
					$model_3_decoded_percentage_3 = 100 * $model_3_decoded->prediction[0][28];
					$model_type_model3 = "Model 3";
					$observation_no_model3 = "1";
					
					//State_Code
					$state_code_no_model3_api = (int)$model_2_decoded->prediction[0][0];
					if ( ! isset ($csv[0][$state_code_no_model3_api - 1])){
						$state_code_no_model3 = "NULL";
					} else {
						$state_code_no_model3 = $csv[0][$state_code_no_model3_api - 1];
					}
					

					//Region
					$region_no_model3_api = (int)$model_2_decoded->prediction[0][1];
					if ( ! isset ($csv[1][$region_no_model3_api])) {
						$region_no_model3 = "NULL";
					} else {
						$region_no_model3 = $csv[1][$region_no_model3_api];
					}
					

					//Urban
					$urban_no_model3_api = (int)$model_2_decoded->prediction[0][2];
					if ( ! isset ($csv[2][$urban_no_model3_api])) {
						$urban_no_model3 = "NULL";
					} else {
						$urban_no_model3 = $csv[2][$urban_no_model3_api];
					}
					

					//Age
					$age_no_model3_int = (int)$model_2_decoded->prediction[0][3];
					$age_no_model3 = (string)$age_no_model3_int;


					//Race
					$race_no_model3_api = (int)$model_2_decoded->prediction[0][4];
					if ( ! isset ($csv[4][$race_no_model3_api])) {
						$race_no_model3 = "NULL";
					} else {
						$race_no_model3 = $csv[4][$race_no_model3_api];
					}
					

					//Religion
					$religion_no_model3_api = (int)$model_2_decoded->prediction[0][5];
					if ( ! isset ($csv[5][$religion_no_model3_api])) {
						$religion_no_model3 = "NULL";
					} else {
						$religion_no_model3 = $csv[5][$religion_no_model3_api];
					}
					

					//Education
					$education_no_model3_api = (int)$model_2_decoded->prediction[0][6];
					if ( ! isset ($csv[6][$education_no_model3_api])) {
						$education_no_model3 = "NULL";
					} else {
						$education_no_model3 = $csv[6][$education_no_model3_api];
					}
					

					//School Perf
					$school_perf_no_model3_api = (int)$model_2_decoded->prediction[0][7];
					if ( ! isset ($csv[7][$school_perf_no_model3_api])) {
						$school_perf_no_model3 = "NULL";
					} else {
						$school_perf_no_model3 = $csv[7][$school_perf_no_model3_api];
					}
					

					//Birth Order
					$birth_order_no_model3_api = (int)$model_2_decoded->prediction[0][8];
					if ( ! isset ($csv[8][$birth_order_no_model3_api])) {
						$birth_order_no_model3 = "NULL";
					} else {
						$birth_order_no_model3 = $csv[8][$birth_order_no_model3_api];
					}


					//No of Siblings
					$no_siblings_no_model3_int = (int)$model_2_decoded->prediction[0][9];
					$no_siblings_no_model3 = (string)$no_siblings_no_model3_int;


					//Relationship Status
					$relationship_no_model3_api = (int)$model_2_decoded->prediction[0][10];
					if ( ! isset ($csv[10][$relationship_no_model3_api])) {
						$relationship_no_model3 = "NULL";
					} else {
						$relationship_no_model3 = $csv[10][$relationship_no_model3_api];
					}
					

					//Children
					$children_no_model3_api = (int)$model_2_decoded->prediction[0][11];
					if ( ! isset ($csv[11][$children_no_model3_api])) {
						$children_no_model3 = "NULL";
					} else {
						$children_no_model3 = $csv[11][$children_no_model3_api];
					}


					//Employment Status
					$employment_status_no_model3_api = (int)$model_2_decoded->prediction[0][12];
					if ( ! isset ($csv[12][$employment_status_no_model3_api])) {
						$employment_status_no_model3 = "NULL";
					} else {
						$employment_status_no_model3 = $csv[12][$employment_status_no_model3_api];
					}


					//Employment Type
					$employment_type_no_model3_api = (int)$model_2_decoded->prediction[0][13];
					if ( ! isset ($csv[13][$employment_type_no_model3_api])) {
						$employment_type_no_model3 = "NULL";
					} else {
						$employment_type_no_model3 = $csv[13][$employment_type_no_model3_api];
					}
					

					//Military Branch
					$military_branch_no_model3_api = (int)$model_2_decoded->prediction[0][14];
					if ( ! isset ($csv[14][$military_branch_no_model3_api])) {
						$military_branch_no_model3 = "NULL";
					} else {
						$military_branch_no_model3 = $csv[14][$military_branch_no_model3_api];
					}
					

					//community_involvement_no
					$community_involvement_no_model3_api = (int)$model_2_decoded->prediction[0][15];
					if ( ! isset ($csv[15][$community_involvement_no_model3_api])) {
						$community_involvement_no_model3 = "NULL";
					} else {
						$community_involvement_no_model3 = $csv[15][$community_involvement_no_model3_api];
					}
					

					//part_1_crimes_no
					$part_1_crimes_no_model3_int = (int)$model_2_decoded->prediction[0][16];
					$part_1_crimes_no_model3 = (string)$part_1_crimes_no_model3_int;


					//part_2_crimes_no
					$part_2_crimes_no_model3_int = (int)$model_2_decoded->prediction[0][17];
					$part_2_crimes_no_model3 = (string)$part_2_crimes_no_model3_int;


					//domestic_abuse_spec_no
					$domestic_abuse_spec_no_model3_api = (int)$model_2_decoded->prediction[0][18];
					if ( ! isset ($csv[18][$domestic_abuse_spec_no_model3_api])) {
						$domestic_abuse_spec_no_model3 = "NULL";
					} else {
						$domestic_abuse_spec_no_model3 = $csv[18][$domestic_abuse_spec_no_model3_api];
					}
					

					//childhood_socioeconomic_no
					$childhood_socioeconomic_no_model3_api = (int)$model_2_decoded->prediction[0][19];
					if ( ! isset ($csv[19][$childhood_socioeconomic_no_model3_api])) {
						$childhood_socioeconomic_no_model3 = "NULL";
					} else {
						$childhood_socioeconomic_no_model3 = $csv[19][$childhood_socioeconomic_no_model3_api];
					}
					

					//recent_stressor_triggering_event_no
					$recent_stressor_triggering_event_no_model3_api = (int)$model_2_decoded->prediction[0][20];
					if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model3_api])) {
						$recent_stressor_triggering_event_no_model3 = "NULL";
					} else {
						$recent_stressor_triggering_event_no_model3 = $csv[20][$recent_stressor_triggering_event_no_model3_api];
					}
					

					//timeframe_signs_crisis_no
					$timeframe_signs_crisis_no_model3_api = (int)$model_2_decoded->prediction[0][21];
					if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model3_api])) {
						$timeframe_signs_crisis_no_model3 = "NULL";
					} else {
						$timeframe_signs_crisis_no_model3 = $csv[21][$timeframe_signs_crisis_no_model3_api];
					}
					

					//substance_use_and_abuse_no
					$substance_use_and_abuse_no_model3_api = (int)$model_2_decoded->prediction[0][22];
					if ( ! isset ($csv[22][$substance_use_and_abuse_no_model3_api])) {
						$substance_use_and_abuse_no_model3 = "NULL";
					} else {
						$substance_use_and_abuse_no_model3 = $csv[22][$substance_use_and_abuse_no_model3_api];
					}
					

					//known_prejudices
					$known_prejudices_no_model3_api = (int)$model_2_decoded->prediction[0][23];
					if ( ! isset ($csv[23][$known_prejudices_no_model3_api])) {
						$known_prejudices_no_model3 = "NULL";
					} else {
						$known_prejudices_no_model3 = $csv[23][$known_prejudices_no_model3_api];
					}
					

					//leakage_how_no
					$leakage_how_no_model3_api = (int)$model_2_decoded->prediction[0][24];
					if ( ! isset ($csv[24][$leakage_how_no_model3_api - 1])) {
						$leakage_how_no_model3 = "NULL";
					} else {
						$leakage_how_no_model3 = $csv[24][$leakage_how_no_model3_api - 1];
					}
					

					//leakage_who_no
					$leakage_who_no_model3_api = (int)$model_2_decoded->prediction[0][25];
					if ( ! isset ($csv[25][$leakage_who_no_model3_api - 1])) {
						$leakage_who_no_model3 = "NULL";
					} else {
						$leakage_who_no_model3 = $csv[25][$leakage_who_no_model3_api - 1];
					}
					

					//leakage_specific_no
					$leakage_specific_no_model3_api = (int)$model_2_decoded->prediction[0][26];
					if ( ! isset ($csv[26][$leakage_specific_no_model3_api])) {
						$leakage_specific_no_model3 = "NULL";
					} else {
						$leakage_specific_no_model3 = $csv[26][$leakage_specific_no_model3_api];
					}
					

					//criminal sentence
					$criminal_sentence_model3_api = (int)$model_2_decoded->prediction[0][27];
					if ( ! isset ($csv[27][$criminal_sentence_model3_api])) {
						$criminal_sentence_model3 = "NULL";
					} else {
						$criminal_sentence_model3 = $csv[27][$criminal_sentence_model3_api];
					}


					/************************* Insert Model 3 - Observation 1 Result in DB ******************************/
					$sql_model3_0 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					if($stmt_model3_0 = mysqli_prepare($link, $sql_model3_0)){

		 			mysqli_stmt_bind_param($stmt_model3_0, "ssssssssssssssssssssssssssssssss", $parent_id_model3_0, $model_type_model3_0, $observation_no_model3_0, $percentage_model3_0, $state_code_model3_0, $region_model3_0, $urban_model3_0, $age_model3_0, $religion_model3_0, $race_model3_0, $education_model3_0, $birth_order_model3_0, $relationship_model3_0, $school_perf_model3_0, $no_siblings_model3_0, $employment_status_model3_0, $children_model3_0, $community_involvement_model3_0, $employment_type_model3_0, $military_branch_model3_0, $part_1_crimes_model3_0, $part_2_crimes_model3_0, $domestic_abuse_spec_model3_0, $childhood_socioeconomic_model3_0, $timeframe_signs_crisis_model3_0, $recent_stressor_triggering_event_model3_0, $known_prejudices_model3_0, $substance_use_and_abuse_model3_0, $leakage_how_model3_0, $leakage_who_model3_0, $leakage_specific_model3_0, $criminal_sentence_model3_0);

		 				$parent_id_model3_0 = $parent_id;
		 				$model_type_model3_0 = $model_type_model3;
		 				$observation_no_model3_0 = $observation_no_model3;
		 				$percentage_model3_0 = $model_3_decoded_percentage_3;
						$state_code_model3_0 = $state_code_no_model3;
						$region_model3_0 = $region_no_model3;
						$urban_model3_0 = $urban_no_model3;
						$age_model3_0 = $age_no_model3;
						$religion_model3_0 = $religion_no_model3;
						$race_model3_0 = $race_no_model3;
						$education_model3_0 = $education_no_model3;
						$birth_order_model3_0 = $birth_order_no_model3;
						$relationship_model3_0 = $relationship_no_model3;
						$school_perf_model3_0 = $school_perf_no_model3;
						$no_siblings_model3_0 = $no_siblings_no_model3;
						$employment_status_model3_0 = $employment_status_no_model3;
						$children_model3_0 = $children_no_model3;
						$community_involvement_model3_0 = $community_involvement_no_model3;
						$employment_type_model3_0 = $employment_type_no_model3;
						$military_branch_model3_0 = $military_branch_no_model3;
						$part_1_crimes_model3_0 = $part_1_crimes_no_model3;
						$part_2_crimes_model3_0 = $part_2_crimes_no_model3;
						$domestic_abuse_spec_model3_0 = $domestic_abuse_spec_no_model3;
						$childhood_socioeconomic_model3_0 = $childhood_socioeconomic_no_model3;
						$timeframe_signs_crisis_model3_0 = $timeframe_signs_crisis_no_model3;
						$recent_stressor_triggering_event_model3_0 = $recent_stressor_triggering_event_no_model3;
						$known_prejudices_model3_0 = $known_prejudices_no_model3;
						$substance_use_and_abuse_model3_0 = $substance_use_and_abuse_no_model3;
						$leakage_how_model3_0 = $leakage_how_no_model3;
						$leakage_who_model3_0 = $leakage_who_no_model3;
						$leakage_specific_model3_0 = $leakage_specific_no_model3;
						$criminal_sentence_model3_0 = $criminal_sentence_model3;
					}

					mysqli_stmt_execute($stmt_model3_0);

		   			// Close statement
			 		mysqli_stmt_close($stmt_model3_0);
		    
		    		// Close connection
		    		//mysqli_close($link);

					/************************* End of Insert Model 3 - Observation 1 Result in DB ******************************/ 
					/***************************************************** End of first Observation of Model 3 **********************************************************/




					/*********************************************** Second Observation of Model 3 **************************************************/
					$model_3_decoded_percentage_2 = 100 * $model_3_decoded->prediction[1][28];
					$model_type_model3_2 = "Model 3";
					$observation_no_model3_2 = 2;

					//State_Code
					$state_code_no_model3_api_2 = (int)$model_2_decoded->prediction[1][0];
					if ( ! isset ($csv[0][$state_code_no_model3_api_2 - 1])){
						$state_code_no_model3_2 = "NULL";
					} else {
						$state_code_no_model3_2 = $csv[0][$state_code_no_model3_api_2 - 1];
					}
					

					//Region
					$region_no_model3_api_2 = (int)$model_2_decoded->prediction[1][1];
					if ( ! isset ($csv[1][$region_no_model3_api_2])) {
						$region_no_model3_2 = "NULL";
					} else {
						$region_no_model3_2 = $csv[1][$region_no_model3_api_2];
					}
					

					//Urban
					$urban_no_model3_api_2 = (int)$model_2_decoded->prediction[1][2];
					if ( ! isset ($csv[2][$urban_no_model3_api_2])) {
						$urban_no_model3_2 = "NULL";
					} else {
						$urban_no_model3_2 = $csv[2][$urban_no_model3_api_2];
					}
					

					//Age
					$age_no_model3_2_int = (int)$model_2_decoded->prediction[1][3];
					$age_no_model3_2 = (string)$age_no_model3_2_int;


					//Race
					$race_no_model3_api_2 = (int)$model_2_decoded->prediction[1][4];
					if ( ! isset ($csv[4][$race_no_model3_api_2])) {
						$race_no_model3_2 = "NULL";
					} else {
						$race_no_model3_2 = $csv[4][$race_no_model3_api_2];
					}
					

					//Religion
					$religion_no_model3_api_2 = (int)$model_2_decoded->prediction[1][5];
					if ( ! isset ($csv[5][$religion_no_model3_api_2])) {
						$religion_no_model3_2 = "NULL";
					} else {
						$religion_no_model3_2 = $csv[5][$religion_no_model3_api_2];
					}
					

					//Education
					$education_no_model3_api_2 = (int)$model_2_decoded->prediction[1][6];
					if ( ! isset ($csv[6][$education_no_model3_api_2])) {
						$education_no_model3_2 = "NULL";
					} else {
						$education_no_model3_2 = $csv[6][$education_no_model3_api_2];
					}
					

					//School Perf
					$school_perf_no_model3_api_2 = (int)$model_2_decoded->prediction[1][7];
					if ( ! isset ($csv[7][$school_perf_no_model3_api_2])) {
						$school_perf_no_model3_2 = "NULL";
					} else {
						$school_perf_no_model3_2 = $csv[7][$school_perf_no_model3_api_2];
					}
					

					//Birth Order
					$birth_order_no_model3_api_2 = (int)$model_2_decoded->prediction[1][8];
					if ( ! isset ($csv[8][$birth_order_no_model3_api_2])) {
						$birth_order_no_model3_2 = "NULL";
					} else {
						$birth_order_no_model3_2 = $csv[8][$birth_order_no_model3_api_2];
					}


					//No of Siblings
					$no_siblings_no_model3_2_int = (int)$model_2_decoded->prediction[1][9];
					$no_siblings_no_model3_2 = (string)$no_siblings_no_model3_2_int;


					//Relationship Status
					$relationship_no_model3_api_2 = (int)$model_2_decoded->prediction[1][10];
					if ( ! isset ($csv[10][$relationship_no_model3_api_2])) {
						$relationship_no_model3_2 = "NULL";
					} else {
						$relationship_no_model3_2 = $csv[10][$relationship_no_model3_api_2];
					}
					

					//Children
					$children_no_model3_api_2 = (int)$model_2_decoded->prediction[1][11];
					if ( ! isset ($csv[11][$children_no_model3_api_2])) {
						$children_no_model3_2 = "NULL";
					} else {
						$children_no_model3_2 = $csv[11][$children_no_model3_api_2];
					}


					//Employment Status
					$employment_status_no_model3_api_2 = (int)$model_2_decoded->prediction[1][12];
					if ( ! isset ($csv[12][$employment_status_no_model3_api_2])) {
						$employment_status_no_model3_2 = "NULL";
					} else {
						$employment_status_no_model3_2 = $csv[12][$employment_status_no_model3_api_2];
					}


					//Employment Type
					$employment_type_no_model3_api_2 = (int)$model_2_decoded->prediction[1][13];
					if ( ! isset ($csv[13][$employment_type_no_model3_api_2])) {
						$employment_type_no_model3_2 = "NULL";
					} else {
						$employment_type_no_model3_2 = $csv[13][$employment_type_no_model3_api_2];
					}
					

					//Military Branch
					$military_branch_no_model3_api_2 = (int)$model_2_decoded->prediction[1][14];
					if ( ! isset ($csv[14][$military_branch_no_model3_api_2])) {
						$military_branch_no_model3_2 = "NULL";
					} else {
						$military_branch_no_model3_2 = $csv[14][$military_branch_no_model3_api_2];
					}
					

					//community_involvement_no
					$community_involvement_no_model3_api_2 = (int)$model_2_decoded->prediction[1][15];
					if ( ! isset ($csv[15][$community_involvement_no_model3_api_2])) {
						$community_involvement_no_model3_2 = "NULL";
					} else {
						$community_involvement_no_model3_2 = $csv[15][$community_involvement_no_model3_api_2];
					}
					

					//part_1_crimes_no
					$part_1_crimes_no_model3_2_int = (int)$model_2_decoded->prediction[1][16];
					$part_1_crimes_no_model3_2 = (string)$part_1_crimes_no_model3_2_int;

					//part_2_crimes_no
					$part_2_crimes_no_model3_2_int = (int)$model_2_decoded->prediction[1][17];
					$part_2_crimes_no_model3_2 = (string)$part_2_crimes_no_model3_2_int;

					//domestic_abuse_spec_no
					$domestic_abuse_spec_no_model3_api_2 = (int)$model_2_decoded->prediction[1][18];
					if ( ! isset ($csv[18][$domestic_abuse_spec_no_model3_api_2])) {
						$domestic_abuse_spec_no_model3_2 = "NULL";
					} else {
						$domestic_abuse_spec_no_model3_2 = $csv[18][$domestic_abuse_spec_no_model3_api_2];
					}
					

					//childhood_socioeconomic_no
					$childhood_socioeconomic_no_model3_api_2 = (int)$model_2_decoded->prediction[1][19];
					if ( ! isset ($csv[19][$childhood_socioeconomic_no_model3_api_2])) {
						$childhood_socioeconomic_no_model3_2 = "NULL";
					} else {
						$childhood_socioeconomic_no_model3_2 = $csv[19][$childhood_socioeconomic_no_model3_api_2];
					}
					

					//recent_stressor_triggering_event_no
					$recent_stressor_triggering_event_no_model3_api_2 = (int)$model_2_decoded->prediction[1][20];
					if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model3_api_2])) {
						$recent_stressor_triggering_event_no_model3_2 = "NULL";
					} else {
						$recent_stressor_triggering_event_no_model3_2 = $csv[20][$recent_stressor_triggering_event_no_model3_api_2];
					}
					

					//timeframe_signs_crisis_no
					$timeframe_signs_crisis_no_model3_api_2 = (int)$model_2_decoded->prediction[1][21];
					if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model3_api_2])) {
						$timeframe_signs_crisis_no_model3_2 = "NULL";
					} else {
						$timeframe_signs_crisis_no_model3_2 = $csv[21][$timeframe_signs_crisis_no_model3_api_2];
					}
					

					//substance_use_and_abuse_no
					$substance_use_and_abuse_no_model3_api_2 = (int)$model_2_decoded->prediction[1][22];
					if ( ! isset ($csv[22][$substance_use_and_abuse_no_model3_api_2])) {
						$substance_use_and_abuse_no_model3_2 = "NULL";
					} else {
						$substance_use_and_abuse_no_model3_2 = $csv[22][$substance_use_and_abuse_no_model3_api_2];
					}
					

					//known_prejudices
					$known_prejudices_no_model3_api_2 = (int)$model_2_decoded->prediction[1][23];
					if ( ! isset ($csv[23][$known_prejudices_no_model3_api_2])) {
						$known_prejudices_no_model3_2 = "NULL";
					} else {
						$known_prejudices_no_model3_2 = $csv[23][$known_prejudices_no_model3_api_2];
					}
					

					//leakage_how_no
					$leakage_how_no_model3_api_2 = (int)$model_2_decoded->prediction[1][24];
					if ( ! isset ($csv[24][$leakage_how_no_model3_api_2 - 1])) {
						$leakage_how_no_model3_2 = "NULL";
					} else {
						$leakage_how_no_model3_2 = $csv[24][$leakage_how_no_model3_api_2 - 1];
					}
					

					//leakage_who_no
					$leakage_who_no_model3_api_2 = (int)$model_2_decoded->prediction[1][25];
					if ( ! isset ($csv[25][$leakage_who_no_model3_api_2 - 1])) {
						$leakage_who_no_model3_2 = "NULL";
					} else {
						$leakage_who_no_model3_2 = $csv[25][$leakage_who_no_model3_api_2 - 1];
					}
					

					//leakage_specific_no
					$leakage_specific_no_model3_api_2 = (int)$model_2_decoded->prediction[1][26];
					if ( ! isset ($csv[26][$leakage_specific_no_model3_api_2])) {
						$leakage_specific_no_model3_2 = "NULL";
					} else {
						$leakage_specific_no_model3_2 = $csv[26][$leakage_specific_no_model3_api_2];
					}
					

					//criminal sentence
					$criminal_sentence_model3_api_2 = (int)$model_2_decoded->prediction[1][27];
					if ( ! isset ($csv[27][$criminal_sentence_model3_api_2])) {
						$criminal_sentence_model3_2 = "NULL";
					} else {
						$criminal_sentence_model3_2 = $csv[27][$criminal_sentence_model3_api_2];
					}


					/************************* Insert Model 3 - Observation 2 Result in DB ******************************/
					$sql_model3_1 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					if($stmt_model3_1 = mysqli_prepare($link, $sql_model3_1)){

		 			mysqli_stmt_bind_param($stmt_model3_1, "ssssssssssssssssssssssssssssssss", $parent_id_model3_1, $model_type_model3_1, $observation_no_model3_1, $percentage_model3_1, $state_code_model3_1, $region_model3_1, $urban_model3_1, $age_model3_1, $religion_model3_1, $race_model3_1, $education_model3_1, $birth_order_model3_1, $relationship_model3_1, $school_perf_model3_1, $no_siblings_model3_1, $employment_status_model3_1, $children_model3_1, $community_involvement_model3_1, $employment_type_model3_1, $military_branch_model3_1, $part_1_crimes_model3_1, $part_2_crimes_model3_1, $domestic_abuse_spec_model3_1, $childhood_socioeconomic_model3_1, $timeframe_signs_crisis_model3_1, $recent_stressor_triggering_event_model3_1, $known_prejudices_model3_1, $substance_use_and_abuse_model3_1, $leakage_how_model3_1, $leakage_who_model3_1, $leakage_specific_model3_1, $criminal_sentence_model3_1);

		 				$parent_id_model3_1 = $parent_id;
		 				$model_type_model3_1 = $model_type_model3_2;
		 				$observation_no_model3_1 = $observation_no_model3_2;
		 				$percentage_model3_1 = $model_2_decoded_percentage_3;
						$state_code_model3_1 = $state_code_no_model3_2;
						$region_model3_1 = $region_no_model3_2;
						$urban_model3_1 = $urban_no_model3_2;
						$age_model3_1 = $age_no_model3_2;
						$religion_model3_1 = $religion_no_model3_2;
						$race_model3_1 = $race_no_model3_2;
						$education_model3_1 = $education_no_model3_2;
						$birth_order_model3_1 = $birth_order_no_model3_2;
						$relationship_model3_1 = $relationship_no_model3_2;
						$school_perf_model3_1 = $school_perf_no_model3_2;
						$no_siblings_model3_1 = $no_siblings_no_model3_2;
						$employment_status_model3_1 = $employment_status_no_model3_2;
						$children_model3_1 = $children_no_model3_2;
						$community_involvement_model3_1 = $community_involvement_no_model3_2;
						$employment_type_model3_1 = $employment_type_no_model3_2;
						$military_branch_model3_1 = $military_branch_no_model3_2;
						$part_1_crimes_model3_1 = $part_1_crimes_no_model3_2;
						$part_2_crimes_model3_1 = $part_2_crimes_no_model3_2;
						$domestic_abuse_spec_model3_1 = $domestic_abuse_spec_no_model3_2;
						$childhood_socioeconomic_model3_1 = $childhood_socioeconomic_no_model3_2;
						$timeframe_signs_crisis_model3_1 = $timeframe_signs_crisis_no_model3_2;
						$recent_stressor_triggering_event_model3_1 = $recent_stressor_triggering_event_no_model3_2;
						$known_prejudices_model3_1 = $known_prejudices_no_model3_2;
						$substance_use_and_abuse_model3_1 = $substance_use_and_abuse_no_model3_2;
						$leakage_how_model3_1 = $leakage_how_no_model3_2;
						$leakage_who_model3_1 = $leakage_who_no_model3_2;
						$leakage_specific_model3_1 = $leakage_specific_no_model3_2;
						$criminal_sentence_model3_1 = $criminal_sentence_model3_2;
					}

					mysqli_stmt_execute($stmt_model3_1);

		   			// Close statement
			 		mysqli_stmt_close($stmt_model3_1);
		    
		    		// Close connection
		    		//mysqli_close($link);
					/************************* End of Insert Model 3 - Observation 2 Result in DB ******************************/ 
					/***************************************************** End of second Observation of Model 3 **********************************************************/


					
					/************************************************ Third Observation of Model 3 ***********************************************/
					$model_3_decoded_percentage_3 = 100 * $model_3_decoded->prediction[2][28];
					$model_type_model3_3 = "Model 3";
					$observation_no_model3_3 = 3;

					//State_Code
					$state_code_no_model3_api_3 = (int)$model_2_decoded->prediction[2][0];
					if ( ! isset ($csv[0][$state_code_no_model3_api_3 - 1])){
						$state_code_no_model3_3 = "NULL";
					} else {
						$state_code_no_model3_3 = $csv[0][$state_code_no_model3_api_3 - 1];
					}
					

					//Region
					$region_no_model3_api_3 = (int)$model_2_decoded->prediction[2][1];
					if ( ! isset ($csv[1][$region_no_model3_api_3])){
						$region_no_model3_3 = "NULL";
					} else {
						$region_no_model3_3 = $csv[1][$region_no_model3_api_3];
					}
					

					//Urban
					$urban_no_model3_api_3 = (int)$model_2_decoded->prediction[2][2];
					if ( ! isset ($csv[2][$urban_no_model3_api_3])){
						$urban_no_model3_3 = "NULL";
					} else {
						$urban_no_model3_3 = $csv[2][$urban_no_model3_api_3];
					}
					

					//Age
					$age_no_model3_3_int = (int)$model_2_decoded->prediction[2][3];
					$age_no_model3_3 = (string)$age_no_model3_3_int;


					//Race
					$race_no_model3_api_3 = (int)$model_2_decoded->prediction[2][4];
					if ( ! isset ($csv[4][$race_no_model3_api_3])){
						$race_no_model3_3 = "NULL";
					} else {
						$race_no_model3_3 = $csv[4][$race_no_model3_api_3];
					}
					

					//Religion
					$religion_no_model3_api_3 = (int)$model_2_decoded->prediction[2][5];
					if ( ! isset ($csv[5][$religion_no_model3_api_3])){
						$religion_no_model3_3 = "NULL";
					} else {
						$religion_no_model3_3 = $csv[5][$religion_no_model3_api_3];
					}
					

					//Education
					$education_no_model3_api_3 = (int)$model_2_decoded->prediction[2][6];
					if ( ! isset ($csv[6][$education_no_model3_api_3])){
						$education_no_model3_3 = "NULL";
					} else {
						$education_no_model3_3 = $csv[6][$education_no_model3_api_3];
					}
					

					//School Perf
					$school_perf_no_model3_api_3 = (int)$model_2_decoded->prediction[2][7];
					if ( ! isset ($csv[7][$school_perf_no_model3_api_3])){
						$school_perf_no_model3_3 = "NULL";
					} else {
						$school_perf_no_model3_3 = $csv[7][$school_perf_no_model3_api_3];
					}
					

					//Birth Order
					$birth_order_no_model3_api_3 = (int)$model_2_decoded->prediction[2][8];
					if ( ! isset ($csv[8][$birth_order_no_model3_api_3])){
						$birth_order_no_model3_3 = "NULL";
					} else {
						$birth_order_no_model3_3 = $csv[8][$birth_order_no_model3_api_3];
					}


					//No of Siblings
					$no_siblings_no_model3_3_int = (int)$model_2_decoded->prediction[2][9];
					$no_siblings_no_model3_3 = (string)$no_siblings_no_model3_3_int;


					//Relationship Status
					$relationship_no_model3_api_3 = (int)$model_2_decoded->prediction[2][10];
					if ( ! isset ($csv[10][$relationship_no_model3_api_3])){
						$relationship_no_model3_3 = "NULL";
					} else {
						$relationship_no_model3_3 = $csv[10][$relationship_no_model3_api_3];
					}
					

					//Children
					$children_no_model3_api_3 = (int)$model_2_decoded->prediction[2][11];
					if ( ! isset ($csv[11][$children_no_model3_api_3])){
						$children_no_model3_3 = "NULL";
					} else {
						$children_no_model3_3 = $csv[11][$children_no_model3_api_3];
					}


					//Employment Status
					$employment_status_no_model3_api_3 = (int)$model_2_decoded->prediction[2][12];
					if ( ! isset ($csv[12][$employment_status_no_model3_api_3])){
						$employment_status_no_model3_3 = "NULL";
					} else {
						$employment_status_no_model3_3 = $csv[12][$employment_status_no_model3_api_3];
					}


					//Employment Type
					$employment_type_no_model3_api_3 = (int)$model_2_decoded->prediction[2][13];
					if ( ! isset ($csv[13][$employment_type_no_model3_api_3])){
						$employment_type_no_model3_3 = "NULL";
					} else {
						$employment_type_no_model3_3 = $csv[13][$employment_type_no_model3_api_3];
					}
					

					//Military Branch
					$military_branch_no_model3_api_3 = (int)$model_2_decoded->prediction[2][14];
					if ( ! isset ($csv[14][$military_branch_no_model3_api_3])){
						$military_branch_no_model3_3 = "NULL";
					} else {
						$military_branch_no_model3_3 = $csv[14][$military_branch_no_model3_api_3];
					}
					

					//community_involvement_no
					$community_involvement_no_model3_api_3 = (int)$model_2_decoded->prediction[2][15];
					if ( ! isset ($csv[15][$community_involvement_no_model3_api_3])){
						$community_involvement_no_model3_3 = "NULL";
					} else {
						$community_involvement_no_model3_3 = $csv[15][$community_involvement_no_model3_api_3];
					}
					

					//part_1_crimes_no
					$part_1_crimes_no_model3_3_int = (int)$model_2_decoded->prediction[2][16];
					$part_1_crimes_no_model3_3 = (string)$part_1_crimes_no_model3_3_int;

					//part_2_crimes_no
					$part_2_crimes_no_model3_3_int = (int)$model_2_decoded->prediction[2][17];
					$part_2_crimes_no_model3_3 = (string)$part_2_crimes_no_model3_3_int;


					//domestic_abuse_spec_no
					$domestic_abuse_spec_no_model3_api_3 = (int)$model_2_decoded->prediction[2][18];
					if ( ! isset ($csv[18][$domestic_abuse_spec_no_model3_api_3])){
						$domestic_abuse_spec_no_model3_3 = "NULL";
					} else {
						$domestic_abuse_spec_no_model3_3 = $csv[18][$domestic_abuse_spec_no_model3_api_3];
					}
					

					//childhood_socioeconomic_no
					$childhood_socioeconomic_no_model3_api_3 = (int)$model_2_decoded->prediction[2][19];
					if ( ! isset ($csv[19][$childhood_socioeconomic_no_model3_api_3])){
						$childhood_socioeconomic_no_model3_3 = "NULL";
					} else {
						$childhood_socioeconomic_no_model3_3 = $csv[19][$childhood_socioeconomic_no_model3_api_3];
					}
					

					//recent_stressor_triggering_event_no
					$recent_stressor_triggering_event_no_model3_api_3 = (int)$model_2_decoded->prediction[2][20];
					if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model3_api_3])){
						$recent_stressor_triggering_event_no_model3_3 = "NULL";
					} else {
						$recent_stressor_triggering_event_no_model3_3 = $csv[20][$recent_stressor_triggering_event_no_model3_api_3];
					}
					

					//timeframe_signs_crisis_no
					$timeframe_signs_crisis_no_model3_api_3 = (int)$model_2_decoded->prediction[2][21];
					if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model3_api_3])){
						$timeframe_signs_crisis_no_model3_3 = "NULL";
					} else {
						$timeframe_signs_crisis_no_model3_3 = $csv[21][$timeframe_signs_crisis_no_model3_api_3];
					}
					

					//substance_use_and_abuse_no
					$substance_use_and_abuse_no_model3_api_3 = (int)$model_2_decoded->prediction[2][22];
					if ( ! isset ($csv[22][$substance_use_and_abuse_no_model3_api_3])){
						$substance_use_and_abuse_no_model3_3 = "NULL";
					} else {
						$substance_use_and_abuse_no_model3_3 = $csv[22][$substance_use_and_abuse_no_model3_api_3];
					}
					

					//known_prejudices
					$known_prejudices_no_model3_api_3 = (int)$model_2_decoded->prediction[2][23];
					if ( ! isset ($csv[23][$known_prejudices_no_model3_api_3])){
						$known_prejudices_no_model3_3 = "NULL";
					} else {
						$known_prejudices_no_model3_3 = $csv[23][$known_prejudices_no_model3_api_3];
					}
					

					//leakage_how_no
					$leakage_how_no_model3_api_3 = (int)$model_2_decoded->prediction[2][24];
					if ( ! isset ($csv[24][$leakage_how_no_model3_api_3 - 1])){
						$leakage_how_no_model3_3 = "NULL";
					} else {
						$leakage_how_no_model3_3 = $csv[24][$leakage_how_no_model3_api_3 - 1];
					}
					

					//leakage_who_no
					$leakage_who_no_model3_api_3 = (int)$model_2_decoded->prediction[2][25];
					if ( ! isset ($csv[25][$leakage_who_no_model3_api_3 - 1])){
						$leakage_who_no_model3_3 = "NULL";
					} else {
						$leakage_who_no_model3_3 = $csv[25][$leakage_who_no_model3_api_3 - 1];
					}
					

					//leakage_specific_no
					$leakage_specific_no_model3_api_3 = (int)$model_2_decoded->prediction[2][26];
					if ( ! isset ($csv[26][$leakage_specific_no_model3_api_3])){
						$leakage_specific_no_model3_3 = "NULL";
					} else {
						$leakage_specific_no_model3_3 = $csv[26][$leakage_specific_no_model3_api_3];
					}
					

					//criminal sentence
					$criminal_sentence_model3_api_3 = (int)$model_2_decoded->prediction[2][27];
					if ( ! isset ($csv[27][$criminal_sentence_model3_api_3])){
						$criminal_sentence_model3_3 = "NULL";
					} else {
						$criminal_sentence_model3_3 = $csv[27][$criminal_sentence_model3_api_3];
					}


					/************************* Insert Model 3 - Observation 3 Result in DB ******************************/
					$sql_model3_2 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					if($stmt_model3_3b = mysqli_prepare($link, $sql_model3_2)){

		 			mysqli_stmt_bind_param($stmt_model3_3b, "ssssssssssssssssssssssssssssssss", $parent_id_model3_3b, $model_type_model3_3b, $observation_no_model3_3b, $percentage_model3_3b, $state_code_model3_3b, $region_model3_3b, $urban_model3_3b, $age_model3_3b, $religion_model3_3b, $race_model3_3b, $education_model3_3b, $birth_order_model3_3b, $relationship_model3_3b, $school_perf_model3_3b, $no_siblings_model3_3b, $employment_status_model3_3b, $children_model3_3b, $community_involvement_model3_3b, $employment_type_model3_3b, $military_branch_model3_3b, $part_1_crimes_model3_3b, $part_2_crimes_model3_3b, $domestic_abuse_spec_model3_3b, $childhood_socioeconomic_model3_3b, $timeframe_signs_crisis_model3_3b, $recent_stressor_triggering_event_model3_3b, $known_prejudices_model3_3b, $substance_use_and_abuse_model3_3b, $leakage_how_model3_3b, $leakage_who_model3_3b, $leakage_specific_model3_3b, $criminal_sentence_model3_3b);

		 				$parent_id_model3_3b = $parent_id;
		 				$model_type_model3_3b = $model_type_model3_3;
		 				$observation_no_model3_3b = $observation_no_model3_3;
		 				$percentage_model3_3b = $model_2_decoded_percentage_3;
						$state_code_model3_3b = $state_code_no_model3_3;
						$region_model3_3b = $region_no_model3_3;
						$urban_model3_3b = $urban_no_model3_3;
						$age_model3_3b = $age_no_model3_3;
						$religion_model3_3b = $religion_no_model3_3;
						$race_model3_3b = $race_no_model3_3;
						$education_model3_3b = $education_no_model3_3;
						$birth_order_model3_3b = $birth_order_no_model3_3;
						$relationship_model3_3b = $relationship_no_model3_3;
						$school_perf_model3_3b = $school_perf_no_model3_3;
						$no_siblings_model3_3b = $no_siblings_no_model3_3;
						$employment_status_model3_3b = $employment_status_no_model3_3;
						$children_model3_3b = $children_no_model3_3;
						$community_involvement_model3_3b = $community_involvement_no_model3_3;
						$employment_type_model3_3b = $employment_type_no_model3_3;
						$military_branch_model3_3b = $military_branch_no_model3_3;
						$part_1_crimes_model3_3b = $part_1_crimes_no_model3_3;
						$part_2_crimes_model3_3b = $part_2_crimes_no_model3_3;
						$domestic_abuse_spec_model3_3b = $domestic_abuse_spec_no_model3_3;
						$childhood_socioeconomic_model3_3b = $childhood_socioeconomic_no_model3_3;
						$timeframe_signs_crisis_model3_3b = $timeframe_signs_crisis_no_model3_3;
						$recent_stressor_triggering_event_model3_3b = $recent_stressor_triggering_event_no_model3_3;
						$known_prejudices_model3_3b = $known_prejudices_no_model3_3;
						$substance_use_and_abuse_model3_3b = $substance_use_and_abuse_no_model3_3;
						$leakage_how_model3_3b = $leakage_how_no_model3_3;
						$leakage_who_model3_3b = $leakage_who_no_model3_3;
						$leakage_specific_model3_3b = $leakage_specific_no_model3_3;
						$criminal_sentence_model3_3b = $criminal_sentence_model3_3;
					}

					if(mysqli_stmt_execute($stmt_model3_3b))
					{
						header('location: result.php?id='.$parent_id );
					} else {
						echo "Oops! Something went wrong. Please try again later.";
					}

		   			// Close statement
			 		mysqli_stmt_close($stmt_model3_3b);
		    
		    		// Close connection
		    		mysqli_close($link);

					/************************* End of Insert Model 3 - Observation 3 Result in DB ******************************/ 
					/***************************************************** End of third Observation of Model 3 **********************************************************/


			/********************************************** END OF MODEL 3 API ************************************************/ 

		}
}
?>
