<?php

include "db_connection.php";

$model_2 = '{ "prediction": [
        [31.0, 2343.0, 0.0, 24.0, 0.0, 1.0, 4.0, 2.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 999.0, 1.0, 0.0, 0.0, 0.0, 1.0, 3.0, 2.0, 3.0, 0.0, 1.0, 7.0, 1.0, 2.0, 0.79],
        [3.0, 2.0, 0.0, 46.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 999.0, 0.0, 0.0, 0.0, 0.0, 999.0, 0.0, 3.0, 0.0, 7.0, 5.0, 10.0, 0.0, 999.0, 0.82],
        [2.0, 0.0, 1.0, 19.0, 0.0, 999.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 999.0, 3.0, 0.0, 10.0, 5.0, 2.0, 4.0, 2.0, 3.0, 8.0, 5.0, 10.0, 1.0, 999.0, 0.82]
    ]
}';

    $model_2_decoded = json_decode($model_2);


    $csv = array_map('str_getcsv', file('render.csv'));

    
    

            /***************************************************** First Observation of Model 2 **********************************************************/
            $model_2_decoded_percentage_1 = 100 * $model_2_decoded->prediction[0][28];
            //$model_2_decoded_percentage_1 = (string)$model_2_decoded_percentage_1_int;

            $model_type_model2 = "Model 2";
            $observation_no_model2 = "1";
            
            //State_Code 
            $state_code_no_model2_api = (int)$model_2_decoded->prediction[0][0];
            if ( ! isset ($csv[0][$state_code_no_model2_api - 1])) {
                $state_code_no_model2 = "not_found";
            } else {
                $state_code_no_model2 = $csv[0][$state_code_no_model2_api - 1];
            }


            //Region
            $region_no_model2_api = (int)$model_2_decoded->prediction[0][1];
            if ( ! isset ($csv[1][$region_no_model2_api])) {
                $region_no_model2 = "not_found";
            } else {
                $region_no_model2 = $csv[1][$region_no_model2_api];
            }
            

            //Urban
            $urban_no_model2_api = (int)$model_2_decoded->prediction[0][2];
            if ( ! isset ($csv[2][$urban_no_model2_api])) {
                $urban_no_model2 = "not_found";
            } else {
                $urban_no_model2 = $csv[2][$urban_no_model2_api];
            }
            

            //Age
            $age_no_model2_int = (int)$model_2_decoded->prediction[0][3];
            $age_no_model2 = (string)$age_no_model2_int;


            //Race
            $race_no_model2_api = (int)$model_2_decoded->prediction[0][4];
            if ( ! isset ($csv[4][$race_no_model2_api])) {
                $race_no_model2 = "not_found";
            } else {
                $race_no_model2 = $csv[4][$race_no_model2_api];
            }
            

            //Religion
            $religion_no_model2_api = (int)$model_2_decoded->prediction[0][5];
            if ( ! isset ($csv[5][$religion_no_model2_api])) {
                $religion_no_model2 = "not_found";
            } else {
                $religion_no_model2 = $csv[5][$religion_no_model2_api];
            }
            

            //Education
            $education_no_model2_api = (int)$model_2_decoded->prediction[0][6];
            if ( ! isset ($csv[6][$education_no_model2_api])) {
                $education_no_model2 = "not_found";
            } else {
                $education_no_model2 = $csv[6][$education_no_model2_api];
            }
            

            //School Perf
            $school_perf_no_model2_api = (int)$model_2_decoded->prediction[0][7];
            if ( ! isset ($csv[7][$school_perf_no_model2_api])) {
                $school_perf_no_model2 = "not_found";
            } else {
                $school_perf_no_model2 = $csv[7][$school_perf_no_model2_api];
            }
            

            //Birth Order
            $birth_order_no_model2_api = (int)$model_2_decoded->prediction[0][8];
            if ( ! isset ($csv[8][$birth_order_no_model2_api])) {
                $birth_order_no_model2 = "not_found";
            } else {
                $birth_order_no_model2 = $csv[8][$birth_order_no_model2_api];
            }


            //No of Siblings
            $no_siblings_no_model2_int = (int)$model_2_decoded->prediction[0][9];
            $no_siblings_no_model2 = (string)$no_siblings_no_model2_int;


            //Relationship Status
            $relationship_no_model2_api = (int)$model_2_decoded->prediction[0][10];
            if ( ! isset ($csv[10][$relationship_no_model2_api])) {
                $relationship_no_model2 = "not_found";
            } else {
                $relationship_no_model2 = $csv[10][$relationship_no_model2_api];
            }
            

            //Children
            $children_no_model2_api = (int)$model_2_decoded->prediction[0][11];
            if ( ! isset ($csv[11][$children_no_model2_api])) {
                $children_no_model2 = "not_found";
            } else {
                $children_no_model2 = $csv[11][$children_no_model2_api];
            }


            //Employment Status
            $employment_status_no_model2_api = (int)$model_2_decoded->prediction[0][12];
            if ( ! isset ($csv[12][$employment_status_no_model2_api])) {
                $employment_status_no_model2 = "not_found";
            } else {
                $employment_status_no_model2 = $csv[12][$employment_status_no_model2_api];
            }


            //Employment Type
            $employment_type_no_model2_api = (int)$model_2_decoded->prediction[0][13];
            if ( ! isset ($csv[13][$employment_type_no_model2_api])) {
                $employment_type_no_model2 = "not_found";
            } else {
                $employment_type_no_model2 = $csv[13][$employment_type_no_model2_api];
            }
            

            //Military Branch
            $military_branch_no_model2_api = (int)$model_2_decoded->prediction[0][14];
            if ( ! isset ($csv[14][$military_branch_no_model2_api])) {
                $military_branch_no_model2 = "not_found";
            } else {
                $military_branch_no_model2 = $csv[14][$military_branch_no_model2_api];
            }
            

            //community_involvement_no
            $community_involvement_no_model2_api = (int)$model_2_decoded->prediction[0][15];
            if ( ! isset ($csv[15][$community_involvement_no_model2_api])) {
                $community_involvement_no_model2 = "not_found";
            } else {
                $community_involvement_no_model2 = $csv[15][$community_involvement_no_model2_api];
            }
            

            //part_1_crimes_no
            $part_1_crimes_no_model2_int = (int)$model_2_decoded->prediction[0][16];
            $part_1_crimes_no_model2 = (string)$part_1_crimes_no_model2_int;


            //part_2_crimes_no
            $part_2_crimes_no_model2_int = (int)$model_2_decoded->prediction[0][17];
            $part_2_crimes_no_model2 = (string)$part_2_crimes_no_model2_int;


            //domestic_abuse_spec_no
            $domestic_abuse_spec_no_model2_api = (int)$model_2_decoded->prediction[0][18];
            if ( ! isset ($csv[18][$domestic_abuse_spec_no_model2_api])) {
                $domestic_abuse_spec_no_model2 = "not_found";
            } else {
                $domestic_abuse_spec_no_model2 = $csv[18][$domestic_abuse_spec_no_model2_api];
            }
            

            //childhood_socioeconomic_no
            $childhood_socioeconomic_no_model2_api = (int)$model_2_decoded->prediction[0][19];
            if ( ! isset ($csv[19][$childhood_socioeconomic_no_model2_api])) {
                $childhood_socioeconomic_no_model2 = "not_found";
            } else {
                $childhood_socioeconomic_no_model2 = $csv[19][$childhood_socioeconomic_no_model2_api];
            }
            

            //recent_stressor_triggering_event_no
            $recent_stressor_triggering_event_no_model2_api = (int)$model_2_decoded->prediction[0][20];
            if ( ! isset ($csv[20][$recent_stressor_triggering_event_no_model2_api])) {
                $recent_stressor_triggering_event_no_model2 = "not_found";
            } else {
                $recent_stressor_triggering_event_no_model2 = $csv[20][$recent_stressor_triggering_event_no_model2_api];
            }
            

            //timeframe_signs_crisis_no
            $timeframe_signs_crisis_no_model2_api = (int)$model_2_decoded->prediction[0][21];
            if ( ! isset ($csv[21][$timeframe_signs_crisis_no_model2_api])) {
                $timeframe_signs_crisis_no_model2 = "not_found";
            } else {
                $timeframe_signs_crisis_no_model2 = $csv[21][$timeframe_signs_crisis_no_model2_api];
            }
            

            //substance_use_and_abuse_no
            $substance_use_and_abuse_no_model2_api = (int)$model_2_decoded->prediction[0][22];
            if ( ! isset ($csv[22][$substance_use_and_abuse_no_model2_api])) {
                $substance_use_and_abuse_no_model2 = "not_found";
            } else {
                $substance_use_and_abuse_no_model2 = $csv[22][$substance_use_and_abuse_no_model2_api];
            }
            

            //known_prejudices
            $known_prejudices_no_model2_api = (int)$model_2_decoded->prediction[0][23];
            if ( ! isset ($csv[23][$known_prejudices_no_model2_api])) {
                $known_prejudices_no_model2 = "not_found";
            } else {
                $known_prejudices_no_model2 = $csv[23][$known_prejudices_no_model2_api];
            }
            

            //leakage_how_no
            $leakage_how_no_model2_api = (int)$model_2_decoded->prediction[0][24];
            if ( ! isset ($csv[24][$leakage_how_no_model2_api])) {
                $leakage_how_no_model2 = "not_found";
            } else {
                $leakage_how_no_model2 = $csv[24][$leakage_how_no_model2_api];
            }
            

            //leakage_who_no
            $leakage_who_no_model2_api = (int)$model_2_decoded->prediction[0][25];
            if ( ! isset ($csv[25][$leakage_who_no_model2_api])) {
                $leakage_who_no_model2 = "not_found";
            } else {
                $leakage_who_no_model2 = $csv[25][$leakage_who_no_model2_api];
            }
            

            //leakage_specific_no
            $leakage_specific_no_model2_api = (int)$model_2_decoded->prediction[0][26];
            if ( ! isset ($csv[26][$leakage_specific_no_model2_api])) {
                $leakage_specific_no_model2 = "not_found";
            } else {
                $leakage_specific_no_model2 = $csv[26][$leakage_specific_no_model2_api];
            }
            

            //criminal sentence
            $criminal_sentence_model2_api = (int)$model_2_decoded->prediction[0][27];
            if ( ! isset ($csv[27][$criminal_sentence_model2_api])) {
                $criminal_sentence_model2 = "not_found";
            } else {
                $criminal_sentence_model2 = $csv[27][$criminal_sentence_model2_api];
            }


            /************************* Insert Model 2 - Observation 1 Result in DB ******************************/ 

            $sql_model2_0 = "INSERT INTO results_data (parent_id, model_type, observation_no, percentage, state_code, region, urban, age, religion, race, education, birth_order, relationship, school_perf, no_siblings, employment_status, children, community_involvement, employment_type, military_branch, part_1_crimes, part_2_crimes, domestic_abuse_spec, childhood_socioeconomic, timeframe_signs_crisis, recent_stressor_triggering_event, known_prejudices, substance_use_and_abuse, leakage_how, leakage_who, leakage_specific, criminal_sentence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            if($stmt_model2_0 = mysqli_prepare($link, $sql_model2_0)){

            mysqli_stmt_bind_param($stmt_model2_0, "ssssssssssssssssssssssssssssssss", $parent_id_model2_0, $model_type_model2_0, $observation_no_model2_0, $percentage_model2_0, $state_code_model2_0, $region_model2_0, $urban_model2_0, $age_model2_0, $religion_model2_0, $race_model2_0, $education_model2_0, $birth_order_model2_0, $relationship_model2_0, $school_perf_model2_0, $no_siblings_model2_0, $employment_status_model2_0, $children_model2_0, $community_involvement_model2_0, $employment_type_model2_0, $military_branch_model2_0, $part_1_crimes_model2_0, $part_2_crimes_model2_0, $domestic_abuse_spec_model2_0, $childhood_socioeconomic_model2_0, $timeframe_signs_crisis_model2_0, $recent_stressor_triggering_event_model2_0, $known_prejudices_model2_0, $substance_use_and_abuse_model2_0, $leakage_how_model2_0, $leakage_who_model2_0, $leakage_specific_model2_0, $criminal_sentence_model2_0);

                $parent_id_model2_0 = $parent_id;
                $model_type_model2_0 = $model_type_model2;
                $observation_no_model2_0 = $observation_no_model2; 
                $percentage_model2_0 = $model_2_decoded_percentage_1;
                $state_code_model2_0 = $state_code_no_model2;
                $region_model2_0 = $region_no_model2;
                $urban_model2_0 = $urban_no_model2;
                $age_model2_0 = $age_no_model2;
                $religion_model2_0 = $religion_no_model2;
                $race_model2_0 = $race_no_model2;
                $education_model2_0 = $education_no_model2;
                $birth_order_model2_0 = $birth_order_no_model2;
                $relationship_model2_0 = $relationship_no_model2;
                $school_perf_model2_0 = $school_perf_no_model2;
                $no_siblings_model2_0 = $no_siblings_no_model2;
                $employment_status_model2_0 = $employment_status_no_model2;
                $children_model2_0 = $children_no_model2;
                $community_involvement_model2_0 = $community_involvement_no_model2;
                $employment_type_model2_0 = $employment_type_no_model2;
                $military_branch_model2_0 = $military_branch_no_model2;
                $part_1_crimes_model2_0 = $part_1_crimes_no_model2;
                $part_2_crimes_model2_0 = $part_2_crimes_no_model2;
                $domestic_abuse_spec_model2_0 = $domestic_abuse_spec_no_model2;
                $childhood_socioeconomic_model2_0 = $childhood_socioeconomic_no_model2;
                $timeframe_signs_crisis_model2_0 = $timeframe_signs_crisis_no_model2;
                $recent_stressor_triggering_event_model2_0 = $recent_stressor_triggering_event_no_model2;
                $known_prejudices_model2_0 = $known_prejudices_no_model2;
                $substance_use_and_abuse_model2_0 = $substance_use_and_abuse_no_model2;
                $leakage_how_model2_0 = $leakage_how_no_model2;
                $leakage_who_model2_0 = $leakage_who_no_model2;
                $leakage_specific_model2_0 = $leakage_specific_no_model2;
                $criminal_sentence_model2_0 = $criminal_sentence_model2;
            }

            if(mysqli_stmt_execute($stmt_model2_0)){
                echo "we are good";
            }else {
                echo "not working";
            };

            // Close statement
            mysqli_stmt_close($stmt_model2_0);
           ?>